package com.impact.pms.Scheduling.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.impact.pms.Scheduling.model.Appointment;
/**
 * 
 * @author 
 * Repository which can be used as a mechanism for encapsulating storage, retrieval,etc and for writing customized queries.
 *
 */
@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {

	@Query(value="select * from Consultation.Appointment c where c.appointment_status = '' or c.appointment_status isnull or c.appointment_status = 'P' and c.physician_id = :physicianId", nativeQuery = true )
	List<Appointment> fetchIncomingAppointmentforPhysician(Integer physicianId);
	
	@Query(value="select A from Appointment A where A.appointmentDate =:todaysDate And A.physicianId =:physicianId And A.appointmentStatus =:appointmentStatus")
	List<Appointment> fetchTodaysUpcomingAppointmentForPhysician(LocalDate todaysDate ,Integer physicianId ,String appointmentStatus);
	
	@Query(value="select count(*) from Appointment A where A.appointmentDate =:todaysDate  And  A.appointmentStatus =:appointmentStatus")
	Integer fetchTodaysCountOfAppointment(LocalDate todaysDate, String appointmentStatus);

	List<Appointment> findAllApointmentByPhysicianIdAndAppointmentDateGreaterThanEqualAndAppointmentDateLessThanEqualAndAppointmentStatus(
			Integer physicianId, LocalDate todaysDate, LocalDate dateAfterTwoMonths, String appointmentStatus);

	List<Appointment> findAllAppointmentsByPhysicianIdAndAppointmentStatusAndAppointmentDate(Integer physicianId,
			String meetingstatusApprove, LocalDate appointmentDate);

	@Query(value="select A from Appointment A  where A.patientId =:patientId AND A.appointmentStatus =:appointmentStatus AND A.appointmentDate>=:appointmentDate ORDER BY A.appointmentDate") 	 
	List<Appointment> fetchUpcomingAppointmentForPatientUser(Integer patientId, LocalDate appointmentDate ,String appointmentStatus);

	@Query(value="select count(*) from Appointment A where A.appointmentDate <=:todaysDate  And  A.appointmentStatus =:appointmentStatus")
	Integer getCountOfAppointmentsTillDate(LocalDate todaysDate, String appointmentStatus);

	@Query(value = "select count(*) from Appointment A where A.patientId = :patientId AND A.appointmentDate <=:todaysDate  AND  A.appointmentStatus =:meetingstatusApprove")
	Integer getCountOfAppointmentsTillDateForPatient(LocalDate todaysDate, String meetingstatusApprove, Integer patientId);

}
