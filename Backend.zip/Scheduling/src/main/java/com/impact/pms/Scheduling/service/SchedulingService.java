package com.impact.pms.Scheduling.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

import com.impact.pms.Scheduling.dto.AppointmentDto;
import com.impact.pms.Scheduling.model.Appointment;
/**
 * @author
 * This service interface is an abstract type that contains a collection of methods
 */
public interface SchedulingService {

	Map<Integer, String> getPhysicianBySpeciality(Integer id);
	public Appointment saveAppointment(Appointment appointment);
	List<Appointment> acceptAppointment(Integer id);
	List<Appointment> fetchIncomingAppointmentForPhysician(Integer physicianId);
	List<Appointment> rejectAppointment(Integer id);
	List<Appointment> fetchTodaysUpcomingAppointmentForPhysician(Integer physicianId);
	List<Appointment> fetchTwoMonthsUpcomingAppointmnetForPhysician(Integer physicianId);
	List<LocalTime> fetchAvaiableSlotsByPhysician(Integer physicianId, LocalDate appointmentDate);
	AppointmentDto fetchUpcomingAppointmentForPatientUser(Integer patientId);
	List<Appointment> fetchTodaysUpcomingAppointmentForNurse(Integer nurseId);
	Integer getCountOfAppointmentsToday();
	Integer getCountOfAppointmentsTillDate();

	//List<AppointmentDto> fetchTodaysUpcomingAppointmentForPhysician(Integer physicianId);

	Appointment getAppointment(Integer appointmentId);
	Integer getCountOfPatientAppointmentsTillDate(Integer patientId);
  

	
	
}
 