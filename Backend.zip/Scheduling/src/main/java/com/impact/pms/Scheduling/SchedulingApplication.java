package com.impact.pms.Scheduling;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * 
 * @author 
 *
 */
@SpringBootApplication
@EnableFeignClients
@EnableDiscoveryClient
public class SchedulingApplication {
	
	private final static Logger log = LoggerFactory.getLogger(SchedulingApplication.class);
		/**
		 * 
		 * Main method
		 *
		 */
		public static void main(String[] args) {
			log.info("Bootstrapping SchedulingApplication ,inside main method");
		SpringApplication.run(SchedulingApplication.class, args);
	}

}
