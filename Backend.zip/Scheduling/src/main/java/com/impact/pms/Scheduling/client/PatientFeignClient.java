package com.impact.pms.Scheduling.client;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.impact.pms.Scheduling.model.Patient;

@FeignClient("patient-ms")
public interface PatientFeignClient {
	
	
	
	@GetMapping("/patient/getall-name-of-patient")
	public Map<Integer, String> getNameOfPatient();
	
	
	}
