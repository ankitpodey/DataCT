package com.impact.pms.Scheduling.serviceImpl;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.pms.Scheduling.client.EmployeeFeignClient;
import com.impact.pms.Scheduling.client.PatientFeignClient;
import com.impact.pms.Scheduling.constants.ApplicationConstants;
import com.impact.pms.Scheduling.dao.AppointmentRepository;
import com.impact.pms.Scheduling.dao.EmployeeRepository;
import com.impact.pms.Scheduling.dao.PhysicianAvailabilityRepository;
import com.impact.pms.Scheduling.dto.AppointmentDto;
import com.impact.pms.Scheduling.model.Appointment;
import com.impact.pms.Scheduling.model.Employee;
import com.impact.pms.Scheduling.model.PhysicianAvailability;
import com.impact.pms.Scheduling.service.SchedulingService;

/**
 * 
 * @author This is implementation class of service interface where business
 *         logic is written
 *
 */
@Service
public class SchedulingServiceImpl implements SchedulingService {

	private final static Logger log = LoggerFactory.getLogger(SchedulingServiceImpl.class);

	@Autowired
	private EmployeeRepository repository;

	@Autowired
	private AppointmentRepository appointmentRepository;

	@Autowired
	private PhysicianAvailabilityRepository physicianAvailabilityRepository;

	@Autowired
	private EmployeeFeignClient employeeFeignClient;

	@Autowired
	private PatientFeignClient patientFeignClient;

	@Override
	public Map<Integer, String> getPhysicianBySpeciality(Integer specialityMasterId) {
		List<Employee> employeeList = repository.findBySpecialityMasterIdAndRoleIdAndDelFlag(specialityMasterId, 2,
				false);
		log.info("employeeList" + employeeList);
		Map<Integer, String> physicianMap = new HashMap<>();
		for (Employee emp : employeeList) // for Each loop
		{
			physicianMap.put(emp.getEmployeeId(), "Dr. " + emp.getFirstName() + " " + emp.getLastName());
		}
		return physicianMap;
	}

	@Override
	public List<Appointment> fetchIncomingAppointmentForPhysician(Integer physicianId) {

		List<Appointment> incomingAppointment = appointmentRepository.fetchIncomingAppointmentforPhysician(physicianId);
		log.info("incomingAppointment" + incomingAppointment);
		if (null != incomingAppointment && incomingAppointment.size() > 0) {
			Map<Integer, String> map = patientFeignClient.getNameOfPatient();
			log.info("map data: " + map.toString());
			for (Appointment appointmentDto : incomingAppointment) {
				String patientName = map.get(appointmentDto.getPatientId());
				appointmentDto.setPatientName(patientName);
			}
		}
		return incomingAppointment;
	}

	@Override
	public List<Appointment> acceptAppointment(Integer appointmentId) {
		// meeting id -> use this to fetch meeting row object
		Optional<Appointment> optionalAppointment = appointmentRepository.findById(appointmentId);
		log.info("optionalAppointment" + optionalAppointment);
		Appointment appointment = optionalAppointment.get();
		log.info("appointment" + appointment);
		// update, the appointment status(Application Constants APPROVE )
		appointment.setAppointmentStatus(ApplicationConstants.MeetingStatus_APPROVE);
		// save
		appointmentRepository.save(appointment);
		// object that is returned from save -> physicianId
		List<Appointment> appointmentList = fetchIncomingAppointmentForPhysician(appointment.getPhysicianId());
		// method to get list of unconfirmed appointments
		log.info("appointmentList" + appointmentList);
		return appointmentList;
	}

	@Override
	public List<Appointment> rejectAppointment(Integer appointmentId) {
		// meeting id -> use this to fetch meeting row object
		Optional<Appointment> optionalAppointment = appointmentRepository.findById(appointmentId);
		log.info("optionalAppointment" + optionalAppointment);
		Appointment appointment = optionalAppointment.get();
		// update, the appointment status(Application Constants REJECT)
		appointment.setAppointmentStatus(ApplicationConstants.MeetingStatus_REJECT);
		appointmentRepository.save(appointment);
		List<Appointment> appointmentList = fetchIncomingAppointmentForPhysician(appointment.getPhysicianId());
		// method to get list of unconfirmed appointments
		log.info("appointmentList" + appointmentList);
		return appointmentList;
	}

//	@Override
//	public List<Appointment> fetchTodaysUpcomingAppointmentForPhysician(Integer physicianId) {
//		
//		 List<Appointment> todaysAppointment=appointmentRepository.fetchTodaysUpcomingAppointmentForPhysician(LocalDate.now(), physicianId, ApplicationConstants.MeetingStatus_APPROVE);
//		 log.info("todaysAppointment" +todaysAppointment);
//		 
////		 if(null != todaysAppointment && todaysAppointment.size()>0)
////		 {
////			 	for(Appointment appointment : todaysAppointment )
////			 	{
////			 		Patient patient = patientFeignClient.getPatientById(appointment.getPatientId());
////			 		appointment.setPatientName(patient.getFirstName() + " " +patient.getLastName());
////			 	}
////		 }
//		 
//		 if(null != todaysAppointment && todaysAppointment.size()>0)
//			{
//				Map<Integer, String> map = patientFeignClient.getNameOfPatient();
//				for(Appointment  appointment : todaysAppointment)
//				{
//					String patientName =map.get(appointment.getAppointmentId());
//					appointment.setPatientName(patientName);
//				}
//			}
//		 
//		 return todaysAppointment;
////		 
//		 
//		
//	}

	@Override
	public Appointment saveAppointment(Appointment appointment) {
		Appointment saveAppointment = appointmentRepository.save(appointment);
		log.info("saveAppointment" + saveAppointment);
		return saveAppointment;
	}

	@Override
	public List<Appointment> fetchTwoMonthsUpcomingAppointmnetForPhysician(Integer physicianId) {
		LocalDate todaysDate = LocalDate.now();
		LocalDate dateAfterTwoMonths = todaysDate.plusMonths(2);
		List<Appointment> upcommingTwoMonthsAppointments = appointmentRepository
				.findAllApointmentByPhysicianIdAndAppointmentDateGreaterThanEqualAndAppointmentDateLessThanEqualAndAppointmentStatus(
						physicianId, todaysDate, dateAfterTwoMonths, ApplicationConstants.MeetingStatus_APPROVE);
		log.info("upcommingTwoMonthsAppointments" + upcommingTwoMonthsAppointments);
		return upcommingTwoMonthsAppointments;
	}

	@Override
	public List<LocalTime> fetchAvaiableSlotsByPhysician(Integer physicianId, LocalDate appointmentDate) {

		// get all slots from physicianAvailability based on days
		String s = appointmentDate.getDayOfWeek().toString();

		PhysicianAvailability physicianAvailability = physicianAvailabilityRepository
				.findAvailableTimeSlot(physicianId);
		// create list<String>(slots)
		LocalTime fromTime = null, tillTime = null;

		if (null != physicianAvailability) {
			if (s.equalsIgnoreCase("MONDAY")) {
				fromTime = physicianAvailability.getMondayFrom();
				tillTime = physicianAvailability.getMondayTo();
			}
			if (s.equalsIgnoreCase("TUESDAY")) {
				fromTime = physicianAvailability.getTuesdayFrom();
				tillTime = physicianAvailability.getTuesdayTo();
			}
			if (s.equalsIgnoreCase("WEDNESDAY")) {
				fromTime = physicianAvailability.getWednesdayFrom();
				tillTime = physicianAvailability.getWednesdayTo();
			}
			if (s.equalsIgnoreCase("THURSDAY")) {
				fromTime = physicianAvailability.getThursdayFrom();
				tillTime = physicianAvailability.getThursdayTo();
			}
			if (s.equalsIgnoreCase("FRIDAY")) {
				fromTime = physicianAvailability.getFridayFrom();
				tillTime = physicianAvailability.getFridayTo();
			}
			if (s.equalsIgnoreCase("SATURDAY")) {
				fromTime = physicianAvailability.getSaturdayFrom();
				tillTime = physicianAvailability.getSaturdayTo();
			} else {
				fromTime = physicianAvailability.getSundayFrom();
				tillTime = physicianAvailability.getSundayTo();
			}
		}
		// get booked slots from appointments

		int gapInMinutes = 60; // Define your span-of-time/slot duration
		
		//if checking availability for today
		if(appointmentDate.equals(LocalDate.now())){
			fromTime = LocalTime.now().plusHours(1).truncatedTo(ChronoUnit.HOURS);
		}

		System.out.println("difference" + fromTime.until(tillTime, ChronoUnit.MINUTES));
		int loops = ((int) (fromTime.until(tillTime, ChronoUnit.MINUTES))) / 60;

		List<LocalTime> availableSlots = new ArrayList<>(loops);
		for (int i = 1; i <= loops; i++) {
			availableSlots.add(fromTime);
			// Set up next loop.
			fromTime = fromTime.plusMinutes(gapInMinutes);
		}

		System.out.println(availableSlots);

		// exclude den.

		List<Appointment> appointmentList = appointmentRepository
				.findAllAppointmentsByPhysicianIdAndAppointmentStatusAndAppointmentDate(physicianId,
						ApplicationConstants.MeetingStatus_APPROVE, appointmentDate);

		if (null != appointmentList && appointmentList.size() > 0) {
			List<LocalTime> reservedSlot = new ArrayList<LocalTime>();
			for (Appointment appointment : appointmentList) {
				reservedSlot.add(appointment.getAppointmentTime());

			}

			availableSlots.removeAll(reservedSlot);
		}

		return availableSlots;

	}

	@Override
	public AppointmentDto fetchUpcomingAppointmentForPatientUser(Integer patientId) {

		List<Appointment> appointmentList = appointmentRepository.fetchUpcomingAppointmentForPatientUser(patientId,
				LocalDate.now(), ApplicationConstants.MeetingStatus_APPROVE);
		AppointmentDto appointmentDto = new AppointmentDto();
		if (null != appointmentList && appointmentList.size() > 0) {
			Appointment appointment = appointmentList.get(0);
			BeanUtils.copyProperties(appointment, appointmentDto);
			Employee employee = employeeFeignClient.getEmployee(appointment.getPhysicianId());
			appointmentDto.setPhysicianName(employee.getFirstName() + " " + employee.getLastName());
		}

		return appointmentDto;
	}

	@Override
	public List<Appointment> fetchTodaysUpcomingAppointmentForNurse(Integer nurseId) {
		Integer physicianId = employeeFeignClient.getReportingToPhysicianId(nurseId);

		log.info("nurse reports to physician (id): " + physicianId);
		List<Appointment> appointmentList = this.fetchTodaysUpcomingAppointmentForPhysician(physicianId);

		return appointmentList;
	}

	@Override
	public Integer getCountOfAppointmentsToday() {
		return appointmentRepository.fetchTodaysCountOfAppointment(LocalDate.now(),
				ApplicationConstants.MeetingStatus_APPROVE);

	}

	@Override
	public Integer getCountOfAppointmentsTillDate() {

		return appointmentRepository.getCountOfAppointmentsTillDate(LocalDate.now(),
				ApplicationConstants.MeetingStatus_APPROVE);

	}

	@Override
	public Appointment getAppointment(Integer appointmentId) {
		Optional<Appointment> optionalAppointment = appointmentRepository.findById(appointmentId);
		Appointment appointment = optionalAppointment.get();
		return appointment;
	}

	@Override
	public List<Appointment> fetchTodaysUpcomingAppointmentForPhysician(Integer physicianId) {
		List<Appointment> todaysAppointment = appointmentRepository.fetchTodaysUpcomingAppointmentForPhysician(
				LocalDate.now(), physicianId, ApplicationConstants.MeetingStatus_APPROVE);
		// AppointmentDto appointmentDto = new AppointmentDto();
		log.info("todaysAppointment" + todaysAppointment);
		if (null != todaysAppointment && todaysAppointment.size() > 0) {
			Map<Integer, String> map = patientFeignClient.getNameOfPatient();
			log.info("map data: " + map.toString());
			for (Appointment appointmentDto : todaysAppointment) {
				String patientName = map.get(appointmentDto.getPatientId());
				appointmentDto.setPatientName(patientName);
			}
		}

		return todaysAppointment;

	}

	@Override
	public Integer getCountOfPatientAppointmentsTillDate(Integer patientId) {
		return appointmentRepository.getCountOfAppointmentsTillDateForPatient(LocalDate.now(), ApplicationConstants.MeetingStatus_APPROVE, patientId); 
		
	}

}
