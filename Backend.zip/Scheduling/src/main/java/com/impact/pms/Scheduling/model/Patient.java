package com.impact.pms.Scheduling.model;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "Patient")
@ApiModel(description = "Details about the Patient")
public class Patient implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty(notes="The unique id of the Patient")
	private Integer patientId;

	private String title;

	private String firstName;

	private String lastName;

	private String emailId;

	private LocalDate dateOfBirth;

	private String contactNumber;

	private String gender;

	private String race;

	private String ethinicity;

	private String languagesKnown;

	private String addressLineOne;

	private String addressLineTwo;

	private String addressStreet;

	private String addressLandmark;

	private String addressCity;

	private String addressState;

	private String addressCountry;

	private String addressZipCode;
	
	@CreationTimestamp
	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private boolean delFlag;

	private Integer createdBy;

	private Integer updatedBy;

	private boolean verificationFlag;

	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Patient(Integer patientId, String title, String firstName, String lastName, String emailId,
			LocalDate dateOfBirth, String contactNumber, String gender, String race, String ethinicity,
			String languagesKnown, String addressLineOne, String addressLineTwo, String addressStreet,
			String addressLandmark, String addressCity, String addressState, String addressCountry,
			String addressZipCode, LocalDate dateCreated, LocalDate dateUpdated, boolean delFlag, Integer createdBy,
			Integer updatedBy, boolean verificationFlag) {
		super();
		this.patientId = patientId;
		this.title = title;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.dateOfBirth = dateOfBirth;
		this.contactNumber = contactNumber;
		this.gender = gender;
		this.race = race;
		this.ethinicity = ethinicity;
		this.languagesKnown = languagesKnown;
		this.addressLineOne = addressLineOne;
		this.addressLineTwo = addressLineTwo;
		this.addressStreet = addressStreet;
		this.addressLandmark = addressLandmark;
		this.addressCity = addressCity;
		this.addressState = addressState;
		this.addressCountry = addressCountry;
		this.addressZipCode = addressZipCode;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.delFlag = delFlag;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
		this.verificationFlag = verificationFlag;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	public String getEthinicity() {
		return ethinicity;
	}

	public void setEthinicity(String ethinicity) {
		this.ethinicity = ethinicity;
	}

	public String getLanguagesKnown() {
		return languagesKnown;
	}

	public void setLanguagesKnown(String languagesKnown) {
		this.languagesKnown = languagesKnown;
	}

	public String getAddressLineOne() {
		return addressLineOne;
	}

	public void setAddressLineOne(String addressLineOne) {
		this.addressLineOne = addressLineOne;
	}

	public String getAddressLineTwo() {
		return addressLineTwo;
	}

	public void setAddressLineTwo(String addressLineTwo) {
		this.addressLineTwo = addressLineTwo;
	}

	public String getAddressStreet() {
		return addressStreet;
	}

	public void setAddressStreet(String addressStreet) {
		this.addressStreet = addressStreet;
	}

	public String getAddressLandmark() {
		return addressLandmark;
	}

	public void setAddressLandmark(String addressLandmark) {
		this.addressLandmark = addressLandmark;
	}

	public String getAddressCity() {
		return addressCity;
	}

	public void setAddressCity(String addressCity) {
		this.addressCity = addressCity;
	}

	public String getAddressState() {
		return addressState;
	}

	public void setAddressState(String addressState) {
		this.addressState = addressState;
	}

	public String getAddressCountry() {
		return addressCountry;
	}

	public void setAddressCountry(String addressCountry) {
		this.addressCountry = addressCountry;
	}

	public String getAddressZipCode() {
		return addressZipCode;
	}

	public void setAddressZipCode(String addressZipCode) {
		this.addressZipCode = addressZipCode;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public boolean isVerificationFlag() {
		return verificationFlag;
	}

	public void setVerificationFlag(boolean verificationFlag) {
		this.verificationFlag = verificationFlag;
	}

	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", title=" + title + ", firstName=" + firstName + ", lastName="
				+ lastName + ", emailId=" + emailId + ", dateOfBirth=" + dateOfBirth + ", contactNumber="
				+ contactNumber + ", gender=" + gender + ", race=" + race + ", ethinicity=" + ethinicity
				+ ", languagesKnown=" + languagesKnown + ", addressLineOne=" + addressLineOne + ", addressLineTwo="
				+ addressLineTwo + ", addressStreet=" + addressStreet + ", addressLandmark=" + addressLandmark
				+ ", addressCity=" + addressCity + ", addressState=" + addressState + ", addressCountry="
				+ addressCountry + ", addressZipCode=" + addressZipCode + ", dateCreated=" + dateCreated
				+ ", dateUpdated=" + dateUpdated + ", delFlag=" + delFlag + ", createdBy=" + createdBy + ", updatedBy="
				+ updatedBy + ", verificationFlag=" + verificationFlag + "]";
	}

	
	
	
}
