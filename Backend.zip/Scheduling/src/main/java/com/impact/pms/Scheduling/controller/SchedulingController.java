package com.impact.pms.Scheduling.controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.impact.pms.Scheduling.constants.ApplicationConstants;
import com.impact.pms.Scheduling.dto.AppointmentDto;
import com.impact.pms.Scheduling.dto.ResponseMessageDto;
import com.impact.pms.Scheduling.model.Appointment;
import com.impact.pms.Scheduling.service.SchedulingService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * 
 * @author This is the controller class which is responsible for processing
 *         incoming REST API requests, preparing a model, and returning the view
 *         to be rendered as a response.
 *
 */
@RestController
@RequestMapping("/scheduling")
@PropertySource("classpath:response-message.properties")
public class SchedulingController {

	private final static Logger log = LoggerFactory.getLogger(SchedulingController.class);

	@Autowired
	private Environment env;
	@Autowired
	private SchedulingService service;

	@Autowired
	@Qualifier("AppointmentValidator")
	private Validator appointmentValidator;

	@InitBinder("appointment")
	public void schedulingInitBinder(WebDataBinder binder) {
		binder.setValidator(appointmentValidator);
	}

	/**
	 * For fetching Physician BySpeciality wise
	 * 
	 * @return
	 */

	@GetMapping("/physician-by-speciality/{specialityMasterId}")
	@ApiOperation(value = "Find physician by speciality MasterId", notes = "Provide an id to look up specific data")
	public ResponseEntity<Map<Integer, String>> getPhysicianBySpeciality(
			@ApiParam(value = "From Id we need to retrieve", required = true) @PathVariable Integer specialityMasterId) {
		log.info("for getting physician by speciality" + specialityMasterId);
		Map<Integer, String> physicianBySpeciality = service.getPhysicianBySpeciality(specialityMasterId);
		return ResponseEntity.ok(physicianBySpeciality);
	}

	/**
	 * For saving appointments
	 * 
	 * @param appointment
	 * @return
	 */
	@PostMapping("/save-appointment")
	@ApiOperation(value = "To Save Appointments", notes = "To Save Appointments by applying POST method")
	public ResponseEntity<ResponseMessageDto> saveAppointment(
			@ApiParam(value = "To save appointments by applying POST method", required = true) @Validated @RequestBody Appointment appointment) {
		log.info("Saving appointment : " + appointment);
		appointment.setAppointmentStatus(ApplicationConstants.MeetingStatus_PENDING);
		appointment.setAppointmentDate(appointment.getAppointmentDate().plusDays(1));
		Appointment saveAppointment = service.saveAppointment(appointment);
		if (saveAppointment != null)
			return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("appointment.success"), true));
		return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("appointment.fail"), false));
	}

	/**
	 * 
	 * For fetching accepted Appointments
	 * 
	 * @param appointmentId
	 * @return
	 */
	@GetMapping("/accept-appointment/{appointmentId}")
	@ApiOperation(value = "Find Accepted Appointments by passing appointment Id", notes = "Provide an id to look up specific data")
	public ResponseEntity<List<Appointment>> acceptAppointment(
			@ApiParam(value = "From Id we need to retrieve data", required = true) @PathVariable Integer appointmentId) {
		log.info("for getting accepted appointments by passing id" + appointmentId);
		List<Appointment> acceptAppointment = service.acceptAppointment(appointmentId);
		return ResponseEntity.ok(acceptAppointment);
	}

	/**
	 * 
	 * For fetching incoming Appointments for physician
	 * 
	 * @param physicianId
	 * @return
	 */

	@GetMapping("/fetch-incoming-appointment-for-physician/{physicianId}")
	@ApiOperation(value = "Find Incoming Appointments for Physician by passing Id", notes = "Provide an id to look up specific data")
	public ResponseEntity<List<Appointment>> fetchIncomingAppointmentForPhysician(
			@ApiParam(value = "From Id we need to retrieve data", required = true) @PathVariable Integer physicianId) {
		log.info("for getting incoming appointments for physician" + physicianId);
		List<Appointment> incomingAppointment = service.fetchIncomingAppointmentForPhysician(physicianId);
		return ResponseEntity.ok(incomingAppointment);

	}

	/**
	 * 
	 * For fetching rejected appointments
	 * 
	 * @param appointmentId
	 * @return ResponseEntity<List<Appointment>>
	 */
	@GetMapping("/reject-appointment/{appointmentId}")
	@ApiOperation(value = "Find Rejected Appointments by passing Id", notes = "Provide an id to look up specific data")
	public ResponseEntity<List<Appointment>> rejectAppointment(
			@ApiParam(value = "From Id we need to retrieve data", required = true) @PathVariable Integer appointmentId) {
		log.info("for getting rejected appointments for physician" + appointmentId);
		List<Appointment> rejectAppointment = service.rejectAppointment(appointmentId);
		return ResponseEntity.ok(rejectAppointment);
	}

	/**
	 * 
	 * For fetching Today's upcoming appointment for physician
	 * 
	 * @param doctorId
	 * @return
	 */
	@GetMapping("/physician/fetch-todays-upcoming-appointment-for-physician/{physicianId}")
	@ApiOperation(value = "Find Today's  Appointments by passing Id", notes = "Provide an id to look up specific data")
	public ResponseEntity<List<Appointment>> fetchTodaysUpcomingAppointmentForPhysician(
			@ApiParam(value = "From Id we need to retrieve data", required = true) @PathVariable Integer physicianId) {
		log.info("for getting todays appointments for physician" + physicianId);
		List<Appointment> todaysAppointment = service.fetchTodaysUpcomingAppointmentForPhysician(physicianId);
		return ResponseEntity.ok(todaysAppointment);
	}

	/**
	 * For fetching Available Slots By Physician
	 * 
	 * @param physicianId
	 * @param date
	 * @return
	 */
	@PostMapping("/patient/fetch-available-slots-by-physician/{physicianId}")
	public ResponseEntity<List<LocalTime>> fetchAvaiableSlotsByPhysician(@PathVariable Integer physicianId,
			@RequestBody Date date) {
		// LocalDate appointmentDate = LocalDate.parse(date);
		log.info("appointmentDate: " + date);
		LocalDate dateToLocaldate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		log.info("dateToLocaldate: " + dateToLocaldate);
		List<LocalTime> list = service.fetchAvaiableSlotsByPhysician(physicianId, dateToLocaldate);
		return ResponseEntity.ok(list);
	}

	/**
	 * 
	 * For fetching Two months upcoming appointment for physician
	 * 
	 * @param doctorId
	 * @return
	 */
	@GetMapping("/physician/fetch-two-months-upcoming-appointmnets-for-physician/{physicianId}")
	@ApiOperation(value = "Find Two months Appointments by passing Id", notes = "Provide an id to look up specific data")
	public ResponseEntity<List<Appointment>> fetchTwoMonthsUpcomingAppointmnetForPhysician(
			@ApiParam(value = "From Id we need to retrieve data", required = true) @PathVariable Integer physicianId) {
		log.info("for getting two months appointments for physician" + physicianId);
		List<Appointment> twoMonthsUpcomingAppointment = service
				.fetchTwoMonthsUpcomingAppointmnetForPhysician(physicianId);
		return ResponseEntity.ok(twoMonthsUpcomingAppointment);
	}

	/**
	 * For fetching Upcoming Appointment For Patient User
	 * 
	 * @param patientId
	 * @return
	 */
	@GetMapping("/fetch-upcoming-appointment-for-patient-user/{patientId}")
	public ResponseEntity<AppointmentDto> fetchUpcomingAppointmentForPatientUser(@PathVariable Integer patientId) {
		AppointmentDto appointmentDto = service.fetchUpcomingAppointmentForPatientUser(patientId);

		return ResponseEntity.ok(appointmentDto);
	}

	/**
	 * 
	 * For fetching Today's upcoming appointment for physician
	 * 
	 * @param doctorId
	 * @return
	 */
	@GetMapping("/nurse/fetch-todays-upcoming-appointment-for-nurse/{nurseId}")
	@ApiOperation(value = "Find Today's  Appointments by passing Id", notes = "Provide an id to look up specific data")
	public ResponseEntity<List<Appointment>> fetchTodaysUpcomingAppointmentForNurse(
			@ApiParam(value = "From Id we need to retrieve data", required = true) @PathVariable Integer nurseId) {
		log.info("for getting todays appointments for nurse" + nurseId);
		List<Appointment> todaysAppointment = service.fetchTodaysUpcomingAppointmentForNurse(nurseId);
		return ResponseEntity.ok(todaysAppointment);
	}

	/**
	 * 
	 * For getting count of appointments for today
	 * 
	 * @param
	 * @return
	 */
	@GetMapping("/fetch-appointment-count-today")
	@ApiOperation(value = "Find Today's  Appointments count")
	public ResponseEntity<Integer> getCountOfAppointmentsToday() {
		Integer apptCount = service.getCountOfAppointmentsToday();
		return ResponseEntity.ok(apptCount);
	}

	/**
	 * 
	 * For getting count of appointments till date
	 * 
	 * @param doctorId
	 * @return
	 */
	@GetMapping("/fetch-appointment-count-till-date")
	@ApiOperation(value = "Find count of  Appointments till date")
	public ResponseEntity<Integer> getCountOfAppointmentsTillDate() {
		Integer apptCount = service.getCountOfAppointmentsTillDate();
		return ResponseEntity.ok(apptCount);
	}

	@GetMapping("/get-appointment/{appointmentId}")
	public ResponseEntity<Appointment> getAppointment(@PathVariable Integer appointmentId) {
		Appointment result = service.getAppointment(appointmentId);
		return ResponseEntity.ok(result);
	}
	
	@GetMapping("/get-count-of-patient-appointment/{patientId}")
	public ResponseEntity<Integer> getCountOfPatientAppointmentsTillDate(@PathVariable Integer patientId){
		Integer result = service.getCountOfPatientAppointmentsTillDate(patientId);
		if(result == null) {
			result = 0;
		}
		return ResponseEntity.ok(result);
	}
}
