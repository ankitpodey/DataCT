package com.impact.pms.Scheduling.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.impact.pms.Scheduling.model.Employee;

@FeignClient("employee-ms")
public interface EmployeeFeignClient {
	
	 	@GetMapping("/employee/{employeeId}")
	  	Employee  getEmployee(@PathVariable Integer employeeId);
	 	
	 	@GetMapping("/employee/get-report-to-phyid/{empId}")
	 	Integer getReportingToPhysicianId(@PathVariable("empId")Integer employeeId);
	 	
	 	
	 	
}
