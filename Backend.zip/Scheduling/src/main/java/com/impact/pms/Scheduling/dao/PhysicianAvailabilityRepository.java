package com.impact.pms.Scheduling.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.impact.pms.Scheduling.model.PhysicianAvailability;

@Repository
public interface PhysicianAvailabilityRepository extends JpaRepository<PhysicianAvailability, Integer>{

	@Query(value = "SELECT p from PhysicianAvailability p where p.employeeId =:employeeId")
	PhysicianAvailability findAvailableTimeSlot(Integer employeeId);

}
//PhysicianAvailability
