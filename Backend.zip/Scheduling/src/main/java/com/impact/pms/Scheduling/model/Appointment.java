package com.impact.pms.Scheduling.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.CreationTimestamp;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@Entity
@Table(name="appointment" ,schema = "consultation")
@ApiModel(description = "Details about the Appointment")
public class Appointment  implements Serializable{

	
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty(notes="The unique id of the Appointment")
	private Integer  appointmentId;

	private Integer patientId;

	private Integer physicianId;

	private String appointmentTitle;

	private String appointmentDescription;

	private LocalDate appointmentDate;

	private LocalTime 	 appointmentTime;

	private String appointmentStatus;

	private String reasonOfEdit;

	private boolean delFlag;

	@CreationTimestamp
	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;
	@Transient
	private String patientName;

	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Appointment(Integer appointmentId, Integer patientId, Integer physicianId, String appointmentTitle,
			String appointmentDescription, LocalDate appointmentDate, LocalTime appointmentTime,
			String appointmentStatus, String reasonOfEdit, boolean delFlag, LocalDate dateCreated,
			LocalDate dateUpdated, Integer createdBy, Integer updatedBy) {
		super();
		this.appointmentId = appointmentId;
		this.patientId = patientId;
		this.physicianId = physicianId;
		this.appointmentTitle = appointmentTitle;
		this.appointmentDescription = appointmentDescription;
		this.appointmentDate = appointmentDate;
		this.appointmentTime = appointmentTime;
		this.appointmentStatus = appointmentStatus;
		this.reasonOfEdit = reasonOfEdit;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
		//this.patientName = patientName;
	}










	public Integer getAppointmentId() {
		return appointmentId;
	}


	public void setAppointmentId(Integer appointmentId) {
		this.appointmentId = appointmentId;
	}


	public Integer getPatientId() {
		return patientId;
	}


	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public Integer getPhysicianId() {
		return physicianId;
	}



	public void setPhysicianId(Integer physicianId) {
		this.physicianId = physicianId;
	}



	public String getAppointmentTitle() {
		return appointmentTitle;
	}


	public void setAppointmentTitle(String appointmentTitle) {
		this.appointmentTitle = appointmentTitle;
	}


	public LocalTime getAppointmentTime() {
		return appointmentTime;
	}



	public void setAppointmentTime(LocalTime appointmentTime) {
		this.appointmentTime = appointmentTime;
	}



	public String getAppointmentDescription() {
		return appointmentDescription;
	}


	public void setAppointmentDescription(String appointmentDescription) {
		this.appointmentDescription = appointmentDescription;
	}

	public LocalDate getAppointmentDate() {
		return appointmentDate;
	}


	public void setAppointmentDate(LocalDate appointmentDate) {
		this.appointmentDate = appointmentDate;
	}


	
	public String getAppointmentStatus() {
		return appointmentStatus;
	}


	public void setAppointmentStatus(String appointmentStatus) {
		this.appointmentStatus = appointmentStatus;
	}


	


	public String getReasonOfEdit() {
		return reasonOfEdit;
	}


	public void setReasonOfEdit(String reasonOfEdit) {
		this.reasonOfEdit = reasonOfEdit;
	}


	public boolean isDelFlag() {
		return delFlag;
	}


	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}


	public LocalDate getDateCreated() {
		return dateCreated;
	}


	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}


	public LocalDate getDateUpdated() {
		return dateUpdated;
	}


	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}


	public Integer getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}


	public Integer getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Transient
	public String getPatientName() {
		return patientName;
	}

	@Transient
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}


	@Override
	public String toString() {
		return "Appointment [appointmentId=" + appointmentId + ", patientId=" + patientId + ", physicianId="
				+ physicianId + ", appointmentTitle=" + appointmentTitle + ", appointmentDescription="
				+ appointmentDescription + ", appointmentDate=" + appointmentDate + ", appointmentTime="
				+ appointmentTime + ", appointmentStatus=" + appointmentStatus + ", reasonOfEdit=" + reasonOfEdit
				+ ", delFlag=" + delFlag + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated
				+ ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + " , patientName=" + patientName + "]";
	}



}


// 
	





	





	

	


	

	

	

	

