package com.impact.pms.Scheduling.validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.impact.pms.Scheduling.model.Appointment;
import com.impact.pms.Scheduling.util.ValidationUtil;
/**
 * 
 * @author 
 * 
 */
@Component
@Qualifier("AppointmentValidator")
public class AppointmentValidator implements Validator {
	
	private final static Logger log = LoggerFactory.getLogger(Appointment.class);

	@Override
	public boolean supports(Class<?> clazz) {
		//specify class to validate
		return Appointment.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		log.info("validating Appointment object "+ target);
			//cast target to Appointment
		Appointment appointment = (Appointment) target;

		  if(ValidationUtil.checkEmptyTime(appointment.getAppointmentTime())) {
		  errors.rejectValue("appointmentTime", "appointment.appointmentTime.invalid");
		  }
		  
		  if(ValidationUtil.checkEmptyDate(appointment.getAppointmentDate())) {
			  errors.rejectValue("appointmentDate", "appointment.appointmentDate.invalid");
		  }
		 		
	}
}
