package com.impact.pms.Scheduling.util;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * 
 * @author 
 * 
 */
public class ValidationUtil {
	public static boolean checkEmpty(String value) {
		if( value == null ||  value.trim().equalsIgnoreCase("NONE") || 
				value.trim().replaceAll("\\.", "")
				.replaceAll("\\s+", "").equalsIgnoreCase("NA") || value.trim()
				.equalsIgnoreCase("NA") || value.trim().contains("N.A") || value.trim()
				.contains("N.A.") || 
				value.trim().equalsIgnoreCase("NIL") || 
				value.trim().isEmpty()) {
				return true;
		}
		return false;
	}
	
	public static boolean isStringNullOrEmpty(String string) {
		return checkEmpty(string) ? true : false;
	}
	
	public static boolean checkEmptyTime(LocalTime value) {
		if( value == null ) {
				return true;
		}
		return false;
	}
	
	public static boolean checkEmptyDate(LocalDate value) {
		if( value == null ) {
				return true;
		}
		return false;
	}
	
}
