package com.impact.pms.Visit.validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.impact.pms.Visit.model.Visit;
import com.impact.pms.Visit.util.ValidationUtil;
/**
 * 
 * @author AnkitP4
 * 
 */
@Component
@Qualifier("VisitValidator")
public class VisitValidator  implements Validator {
	private final static Logger log = LoggerFactory.getLogger(Visit.class);

	@Override
	public boolean supports(Class<?> clazz) {
		//specify class to validate
		return Visit.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		log.info("validating Appointment object "+ target);

		//cast target to PatientRegistrationDto
		Visit visit = (Visit) target;

		//perform validation
		if(ValidationUtil.checkHeight(visit.getHeight())) {
			errors.rejectValue("height", "visit.height.invalid");
		}

		if(ValidationUtil.checkWeight(visit.getWeight())) {
			errors.rejectValue("weight", "visit.weight.invalid");
		}
		
		/*
		 * if(ValidationUtil.checkBloodPressure(visit.getBloodPressure())) {
		 * errors.rejectValue("bloodPressure", "visit.bloodPressure.invalid"); }
		 */		
		if(visit.getBloodPressure()==null)
		{
			errors.rejectValue("bloodPressure", "visit.bloodPressure.invalid");
		}
	
		if(ValidationUtil.checkBodyTemperature(visit.getBodyTemperature())) {
			errors.rejectValue("bodyTemperature", "visit.bodyTemperature.invalid");
		}
		
		if(ValidationUtil.checkRespirationRate(visit.getRespirationRate())) {
			errors.rejectValue("respirationRate", "visit.respirationRate.invalid");
		}
		
	}

}
