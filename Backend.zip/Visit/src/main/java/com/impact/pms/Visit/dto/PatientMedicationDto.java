package com.impact.pms.Visit.dto;

import com.impact.pms.Visit.model.Visit;

public class PatientMedicationDto {
	private Integer medicationMasterId;

	private String medicationId;

	private String medicationName;

	private String medicationGenericName;

	private String medicationManufacturerName;

	private String medicationForm;

	private String medicationStrength;
	
	private String dosage;
	

	
	public PatientMedicationDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getMedicationMasterId() {
		return medicationMasterId;
	}

	public void setMedicationMasterId(Integer medicationMasterId) {
		this.medicationMasterId = medicationMasterId;
	}

	public String getMedicationId() {
		return medicationId;
	}

	public void setMedicationId(String medicationId) {
		this.medicationId = medicationId;
	}

	public String getMedicationName() {
		return medicationName;
	}

	public void setMedicationName(String medicationName) {
		this.medicationName = medicationName;
	}

	public String getMedicationGenericName() {
		return medicationGenericName;
	}

	public void setMedicationGenericName(String medicationGenericName) {
		this.medicationGenericName = medicationGenericName;
	}

	public String getMedicationManufacturerName() {
		return medicationManufacturerName;
	}

	public void setMedicationManufacturerName(String medicationManufacturerName) {
		this.medicationManufacturerName = medicationManufacturerName;
	}

	public String getMedicationForm() {
		return medicationForm;
	}

	public void setMedicationForm(String medicationForm) {
		this.medicationForm = medicationForm;
	}

	
	public String getMedicationStrength() {
		return medicationStrength;
	}

	public void setMedicationStrength(String medicationStrength) {
		this.medicationStrength = medicationStrength;
	}
	
	

	public String getDosage() {
		return dosage;
	}

	public void setDosage(String dosage) {
		this.dosage = dosage;
	}

	@Override
	public String toString() {
		return "PatientMedicationDto [medicationMasterId=" + medicationMasterId + ", medicationId=" + medicationId
				+ ", medicationName=" + medicationName + ", medicationGenericName=" + medicationGenericName
				+ ", medicationManufacturerName=" + medicationManufacturerName + ", medicationForm=" + medicationForm
				+ ", medicationStrength=" + medicationStrength + ", dosage=" + dosage + "]";
	}

	

}
