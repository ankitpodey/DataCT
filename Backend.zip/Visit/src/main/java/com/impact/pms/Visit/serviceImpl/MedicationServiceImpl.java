package com.impact.pms.Visit.serviceImpl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.pms.Visit.dao.MedicationRepository;
import com.impact.pms.Visit.service.MedicationService;

@Service
public class MedicationServiceImpl implements MedicationService {

	@Autowired
	MedicationRepository mr;
	
	
	@Override
	@Transactional
	public Integer deleteMedicationByVisitId(Integer visitId) {
		return mr.deleteMedicationByVisitId(visitId);
	}

}
