package com.impact.pms.Visit.service;

import java.util.List;

import com.impact.pms.Visit.dto.PatientVisitDto;
import com.impact.pms.Visit.model.PatientDiagnosis;
import com.impact.pms.Visit.model.PatientMedication;
import com.impact.pms.Visit.model.PatientProcedure;
import com.impact.pms.Visit.model.Visit;
/**
 * @author AnkitP4
 * This service interface is an abstract type that contains a collection of methods
 */
public interface VisitService {

	Visit captureVitals(Visit visit);

	PatientDiagnosis captureDiagnosis(PatientDiagnosis diagnosis);

	PatientProcedure captureProcedure(PatientProcedure procedure);

	PatientMedication captureMedication(PatientMedication medication);

	Visit getVitals(Integer appointmentId);

	Visit getDiagnosis(Integer visitId);

	PatientDiagnosis getProcedure(Integer diagnosisId);

	PatientMedication getMedication(Integer visitId);

	List<PatientVisitDto> pastVisitDetails(Integer patientId);
	
	boolean saveVisitDetail(PatientVisitDto patientVisitDto);

	boolean insertVisitDetail(PatientVisitDto patientVisitDto);
	
	boolean updateVisitDetail(PatientVisitDto patientVisitDto);
	
	public Visit getVisitDetail(Integer appointmentId);

}
