package com.impact.pms.Visit.serviceImpl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.pms.Visit.dao.DiagnosisRepository;
import com.impact.pms.Visit.service.DiagnosisService;

@Service
public class DiagnosisServiceImpl implements DiagnosisService {

	@Autowired
	DiagnosisRepository dr;
	
	@Override
	@Transactional
	public Integer deleteDiagnosisByVisitId(Integer visitId) {
		return dr.deleteDiagnosisByVisitId(visitId);
	}

}
