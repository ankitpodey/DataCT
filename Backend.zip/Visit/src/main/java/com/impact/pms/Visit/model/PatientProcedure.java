package com.impact.pms.Visit.model;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "patientProcedure" ,schema = "consultation")
@ApiModel(description = "Details about the PatientProcedure")
public class PatientProcedure {
	
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@ApiModelProperty(notes="The unique id of the procedure")
	private Integer patientProcedureId;

	

	private Integer procedureMasterId;

	private boolean delFlag;
	@CreationTimestamp
	private LocalDate dateCreated;

	private LocalDate dateUpdated;
	
	@JsonBackReference
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "visit_id" ,nullable = false)
	private Visit visit;
	
	@Transient
	private String procedureCode;

	@Transient
	private String procedureDescription;

	@Transient
	private String procedureApproach;

	public PatientProcedure() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Visit getVisit() {
		return visit;
	}


	public void setVisit(Visit visit) {
		this.visit = visit;
	}


	public Integer getPatientProcedureId() {
		return patientProcedureId;
	}

	public void setPatientProcedureId(Integer patientProcedureId) {
		this.patientProcedureId = patientProcedureId;
	}

	

	public Integer getProcedureMasterId() {
		return procedureMasterId;
	}

	public void setProcedureMasterId(Integer procedureMasterId) {
		this.procedureMasterId = procedureMasterId;
	}

	

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	

	public String getProcedureCode() {
		return procedureCode;
	}


	public void setProcedureCode(String procedureCode) {
		this.procedureCode = procedureCode;
	}


	public String getProcedureDescription() {
		return procedureDescription;
	}


	public void setProcedureDescription(String procedureDescription) {
		this.procedureDescription = procedureDescription;
	}


	public String getProcedureApproach() {
		return procedureApproach;
	}


	public void setProcedureApproach(String procedureApproach) {
		this.procedureApproach = procedureApproach;
	}


	@Override
	public String toString() {
		return "PatientProcedure [patientProcedureId=" + patientProcedureId + ", procedureMasterId=" + procedureMasterId
				+ ", delFlag=" + delFlag + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated + ", visit="
				+ visit + "]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((procedureMasterId == null) ? 0 : procedureMasterId.hashCode());
		return result;
	}


	



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PatientProcedure other = (PatientProcedure) obj;
		if (procedureMasterId == null) {
			if (other.procedureMasterId != null)
				return false;
		} else if (!procedureMasterId.equals(other.procedureMasterId))
			return false;
		return true;
	}

	
	
	

	


}
