package com.impact.pms.Visit.service;

/**
 * @author AnupM2
 *
 */
public interface DiagnosisService {

	Integer deleteDiagnosisByVisitId(Integer visitId); 
}
