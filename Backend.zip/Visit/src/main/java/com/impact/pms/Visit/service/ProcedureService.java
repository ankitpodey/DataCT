package com.impact.pms.Visit.service;

public interface ProcedureService {

	Integer deleteProcedureByVisitId(Integer visitId);
}
