package com.impact.pms.Visit.dto;

public class PatientDiagnosisDto {

	
	private Integer diagnosisMasterId;

	private String diagnosisCode;

	private String diagnosisDescription;

	private String diagnosisType;
	
	public PatientDiagnosisDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getDiagnosisMasterId() {
		return diagnosisMasterId;
	}

	public void setDiagnosisMasterId(Integer diagnosisMasterId) {
		this.diagnosisMasterId = diagnosisMasterId;
	}

	public String getDiagnosisCode() {
		return diagnosisCode;
	}

	public void setDiagnosisCode(String diagnosisCode) {
		this.diagnosisCode = diagnosisCode;
	}

	public String getDiagnosisDescription() {
		return diagnosisDescription;
	}

	public void setDiagnosisDescription(String diagnosisDescription) {
		this.diagnosisDescription = diagnosisDescription;
	}

	public String getDiagnosisType() {
		return diagnosisType;
	}

	public void setDiagnosisType(String diagnosisType) {
		this.diagnosisType = diagnosisType;
	}

	@Override
	public String toString() {
		return "PatientDiagnosisDto [diagnosisMasterId=" + diagnosisMasterId + ", diagnosisCode=" + diagnosisCode
				+ ", diagnosisDescription=" + diagnosisDescription + ", diagnosisType=" + diagnosisType + "]";
	}

	

	
}
