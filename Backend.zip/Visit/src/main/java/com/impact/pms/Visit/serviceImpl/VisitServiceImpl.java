package com.impact.pms.Visit.serviceImpl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.pms.Visit.client.EmployeeFeignClient;
import com.impact.pms.Visit.client.MasterFeignClient;
import com.impact.pms.Visit.dao.DiagnosisRepository;
import com.impact.pms.Visit.dao.MedicationRepository;
import com.impact.pms.Visit.dao.ProcedureRepository;
import com.impact.pms.Visit.dao.VisitRepository;
import com.impact.pms.Visit.dto.PatientDiagnosisDto;
import com.impact.pms.Visit.dto.PatientMedicationDto;
import com.impact.pms.Visit.dto.PatientProcedureDto;
import com.impact.pms.Visit.dto.PatientVisitDto;
import com.impact.pms.Visit.exception.UserNotFoundException;
import com.impact.pms.Visit.model.PatientDiagnosis;
import com.impact.pms.Visit.model.PatientMedication;
import com.impact.pms.Visit.model.PatientProcedure;
import com.impact.pms.Visit.model.Visit;
import com.impact.pms.Visit.service.DiagnosisService;
import com.impact.pms.Visit.service.MedicationService;
import com.impact.pms.Visit.service.ProcedureService;
import com.impact.pms.Visit.service.VisitService;

/**
 * 
 * @author AnkitP4 This is implementation class of service interface where
 *         business logic is written
 *
 */

@Service
public class VisitServiceImpl implements VisitService {

	private final static Logger log = LoggerFactory.getLogger(VisitServiceImpl.class);

	@Autowired
	VisitRepository visitRepository;

	@Autowired
	DiagnosisRepository diagnosisRepository;

	@Autowired
	ProcedureRepository procedureRepository;

	@Autowired
	MedicationRepository medicationRepository;
	
	@Autowired
	DiagnosisService diagnosisService;
	
	@Autowired
	MedicationService medicationService;
	
	@Autowired
	ProcedureService procedureService;

	private Map<Integer, PatientDiagnosisDto> diagnosisMap = new HashMap<>();
	private Map<Integer, PatientProcedureDto> procedureMap = new HashMap<>();
	private Map<Integer, PatientMedicationDto> medicationMap = new HashMap<>();
	private Map<Integer, String> employeeNameMap = new HashMap<>();

	@Autowired
	MasterFeignClient masterFeignClient;

	@Autowired
	EmployeeFeignClient empClient;

	@Override
	public Visit captureVitals(Visit visit) {

		return visitRepository.save(visit);
	}

	@Override
	public PatientDiagnosis captureDiagnosis(PatientDiagnosis diagnosis) {
		log.info("diagnosis" + diagnosis);
		return diagnosisRepository.save(diagnosis);
	}

	@Override
	public PatientProcedure captureProcedure(PatientProcedure procedure) {
		log.info("procedure" + procedure);
		return procedureRepository.save(procedure);
	}

	@Override
	public PatientMedication captureMedication(PatientMedication medication) {
		log.info("medication" + medication);
		return medicationRepository.save(medication);
	}

	@Override
	public Visit getVitals(Integer appointmentId) {

		//Visit getVitals = visitRepository.findVisitByAppointmentIdAndDelFlag(appointmentId,false);
		Optional<Visit> optionalVitals =  visitRepository.findById(appointmentId);
		Visit getVitals = optionalVitals.get();
		log.info("appointmentId"+appointmentId);
		log.info("getVitals" + getVitals);
		return getVitals;

	}

	@Override
	public Visit getDiagnosis(Integer visitId) {
		Optional<Visit> optional = visitRepository.findById(visitId);
		log.info("optional" + optional);
		if (optional.isPresent()) {
			return optional.get();
		}

		throw new UserNotFoundException("id-" + visitId);

	}

	@Override
	public PatientDiagnosis getProcedure(Integer diagnosisId) {
		Optional<PatientDiagnosis> optional = diagnosisRepository.findById(diagnosisId);
		log.info("optional" + optional);
		if (optional.isPresent()) {
			return optional.get();
		}

		throw new UserNotFoundException("id-" + diagnosisId);
	}

	@Override
	public PatientMedication getMedication(Integer visitId) {

		//	Optional<PatientMedication> optional = medicationRepository.findPatientMedicationByVisitId(visitId);
		//log.info("optional" + optional);
		//	if (optional.isPresent()) {
		//return optional.get();
		//}
		return null;
		//	throw new UserNotFoundException("id-" + visitId);
	}

	@Override
	public List<PatientVisitDto> pastVisitDetails(Integer patientId) {


		// fetch list of patient visits
		List<Visit> visitList = visitRepository.findAllVisitsByPatientId(patientId);
		// for each visit get diagnosisDto ,medicationDto, procedureDto

		PatientVisitDto patientVisitDto = new PatientVisitDto();

		List<PatientVisitDto> patientVisitDtoList = new ArrayList<>();
		if (null != visitList && visitList.size() > 0) {


			diagnosisMap = masterFeignClient.fetchDiagnosisMasterTableMapDetails();
			procedureMap = masterFeignClient.fetchProcedureMasterTableMapDetails();
			medicationMap = masterFeignClient.fetchMedicationMasterTableMapDetails();
			employeeNameMap = empClient.getEmployeeNameMap();

			for (Visit visit : visitList) {
				// Populating
				patientVisitDto = copyVisitToPatientVisitDto(visit);

				//set physician and nurse name
				patientVisitDto.setPhysicianName(employeeNameMap.get(patientVisitDto.getPhysicianId()));
				patientVisitDto.setNurseName(employeeNameMap.get(patientVisitDto.getNurseId()));

				// add
				patientVisitDtoList.add(patientVisitDto);
			}
		}
		diagnosisMap = null;
		procedureMap = null;
		medicationMap = null;
		return patientVisitDtoList;
	}

	private PatientVisitDto copyVisitToPatientVisitDto(Visit visit) {
		PatientVisitDto patientVisitDto = new PatientVisitDto();

		if (null != visit.getPatientDiagnosis() && visit.getPatientDiagnosis().size() > 0) {
			Set<PatientDiagnosisDto> patientDiagnosisDtoSet = new HashSet<PatientDiagnosisDto>();
			PatientDiagnosisDto patientDiagnosisDto = new PatientDiagnosisDto();
			for (PatientDiagnosis patientDiagnosis : visit.getPatientDiagnosis()) {
				patientDiagnosisDto = diagnosisMap.get(patientDiagnosis.getDiagnosisMasterId());
				patientDiagnosisDtoSet.add(patientDiagnosisDto);
			}

			patientVisitDto.setDiagnosisdto(patientDiagnosisDtoSet);
		}

		if (null != visit.getPatientMedication() && visit.getPatientMedication().size() > 0) {
			Set<PatientMedicationDto> patientMedicationDtoSet = new HashSet<PatientMedicationDto>();
			PatientMedicationDto patientMedicationDto = new PatientMedicationDto();
			for (PatientMedication patientMedication : visit.getPatientMedication()) {
				patientMedicationDto = medicationMap.get(patientMedication.getMedicationMasterId());
				patientMedicationDto.setDosage(patientMedication.getDosage());
				patientMedicationDtoSet.add(patientMedicationDto);
			}

			patientVisitDto.setMedicationdto(patientMedicationDtoSet);
		}

		if (null != visit.getPatientProcedure() && visit.getPatientProcedure().size() > 0) {
			Set<PatientProcedureDto> patientProcedureDtoSet = new HashSet<>();
			PatientProcedureDto patientProcedureDto = new PatientProcedureDto();
			for (PatientProcedure patientProcedure : visit.getPatientProcedure()) {
				patientProcedureDto = procedureMap.get(patientProcedure.getProcedureMasterId());
				patientProcedureDtoSet.add(patientProcedureDto);
			}

			patientVisitDto.setProceduredto(patientProcedureDtoSet);

		}
		BeanUtils.copyProperties(visit, patientVisitDto);
		return patientVisitDto;
	}

	@Override
	public boolean saveVisitDetail(PatientVisitDto patientVisitDto) {
		//check whether to insert or update
		/*
		 * List<Visit> visitList =
		 * visitRepository.findAllVisitByAppointmentIdAndDelFlag(patientVisitDto.
		 * getAppointmentId(), ApplicationConstants.DEL_FLAG_FALSE);
		 * 
		 * if(null!=visitList) { return updateVisitDetail(patientVisitDto); } return
		 * insertVisitDetail(patientVisitDto);
		 */
		patientVisitDto.setDateCreated(LocalDate.now());
		patientVisitDto.setDateUpdated(LocalDate.now());
		if(null!=patientVisitDto.getVisitId()) {
			return updateVisitDetail(patientVisitDto);
		}
		return insertVisitDetail(patientVisitDto);
	}

	@Override
	public boolean insertVisitDetail(PatientVisitDto patientVisitDto) {


		boolean result = false;
		try {
			Visit visit = new Visit();

			//copy from patient visit DTO to patient visit
			BeanUtils.copyProperties(patientVisitDto, visit);

			//set visit in patient diagnosis
			if(null != visit.getPatientDiagnosis() && visit.getPatientDiagnosis().size()>0) {
				Set<PatientDiagnosis> patientDiagnosis = visit.getPatientDiagnosis();
				for(PatientDiagnosis pd:patientDiagnosis) {
					pd.setVisit(visit);
				}
				visit.setPatientDiagnosis(patientDiagnosis);
			}

			//set visit in patient procedure
			if(null != visit.getPatientProcedure() && visit.getPatientProcedure().size()>0) {
				Set<PatientProcedure> patientProcedure = visit.getPatientProcedure();
				for(PatientProcedure pp : patientProcedure) {
					pp.setVisit(visit);
				}
				visit.setPatientProcedure(patientProcedure);
			}

			//set visit in patient medication
			if(null != visit.getPatientMedication() && visit.getPatientMedication().size()>0) {
				Set<PatientMedication> patientMedication = visit.getPatientMedication();
				for(PatientMedication pm : patientMedication) {
					pm.setVisit(visit);
				}
				visit.setPatientMedication(patientMedication);
			}

			//insert
			visitRepository.save(visit);
			result = true;
		}catch (Exception e) {
			e.printStackTrace();

		}
		return result;
	}

	@Override
	@Transactional
	public boolean updateVisitDetail(PatientVisitDto patientVisitDto) {
		boolean result = false;
		try{
			System.err.println("visit dto reveived"+patientVisitDto);
			
			//copy from dto to model
			Visit visit = new Visit();
			BeanUtils.copyProperties(patientVisitDto, visit);
			
			diagnosisService.deleteDiagnosisByVisitId(visit.getVisitId());
			medicationService.deleteMedicationByVisitId(visit.getVisitId());
			procedureService.deleteProcedureByVisitId(visit.getVisitId());
			
			
			if(null!=patientVisitDto.getDiagnosisdto() && patientVisitDto.getDiagnosisdto().size()>0) {
				Set<PatientDiagnosis> patientDiagnosisSet = new HashSet<PatientDiagnosis>();
				for(PatientDiagnosisDto pdd : patientVisitDto.getDiagnosisdto()) {
					PatientDiagnosis pd = new PatientDiagnosis();
					BeanUtils.copyProperties(pdd, pd);
					pd.setVisit(visit);
					patientDiagnosisSet.add(pd);
				}
				visit.setPatientDiagnosis(patientDiagnosisSet);
			}
			
			if(null!=patientVisitDto.getMedicationdto() && patientVisitDto.getMedicationdto().size()>0) {
				Set<PatientMedication> patientMedicationSet = new HashSet<PatientMedication>();
				for(PatientMedicationDto pmd : patientVisitDto.getMedicationdto()) {
					PatientMedication pm = new PatientMedication();
					BeanUtils.copyProperties(pmd, pm);
					pm.setVisit(visit);
					patientMedicationSet.add(pm);
				}
				visit.setPatientMedication(patientMedicationSet);
			}
			
			if(null!=patientVisitDto.getProceduredto() && patientVisitDto.getProceduredto().size()>0) {
				Set<PatientProcedure> patientProcedureSet = new HashSet<PatientProcedure>();
				for(PatientProcedureDto ppd : patientVisitDto.getProceduredto()) {
					PatientProcedure pd = new PatientProcedure();
					BeanUtils.copyProperties(ppd, pd);
					pd.setVisit(visit);
					patientProcedureSet.add(pd);
				}
				visit.setPatientProcedure(patientProcedureSet);
			}
			
			//remove prev diagnosis, medication and procedure
			//oldVisitData.setPatientDiagnosis(new HashSet<PatientDiagnosis>());



			//copy old data to visit
			//BeanUtils.copyProperties(oldVisitData, visit);
			//System.err.println("visit model "+visit);

			visitRepository.save(visit);
			result = true;
		}catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}



	public Visit getVisitDetail(Integer appointmentId) { 
		Visit visit = visitRepository.findVisitByAppointmentId(appointmentId);
		if(null != visit) {

		//fetch diagnosis data
		if(null!=visit.getPatientDiagnosis() && visit.getPatientDiagnosis().size()>0) {
			Map<Integer, PatientDiagnosisDto> diagnosisMap = masterFeignClient.fetchDiagnosisMasterTableMapDetails();
			for(PatientDiagnosis pd : visit.getPatientDiagnosis()){
				PatientDiagnosisDto obj = diagnosisMap.get(pd.getDiagnosisMasterId());
				pd.setDiagnosisCode(obj.getDiagnosisCode());
				pd.setDiagnosisDescription(obj.getDiagnosisDescription());
			}
		}

		//fetch procedure
		if(null!=visit.getPatientProcedure() && visit.getPatientProcedure().size()>0) {
			Map<Integer, PatientProcedureDto> procedureMap = masterFeignClient.fetchProcedureMasterTableMapDetails();
			for(PatientProcedure pp : visit.getPatientProcedure()){
				PatientProcedureDto obj = procedureMap.get(pp.getProcedureMasterId());
				pp.setProcedureApproach(obj.getProcedureApproach());
				pp.setProcedureDescription(obj.getProcedureDescription());
				pp.setProcedureCode(obj.getProcedureCode());
			}
		}

		//fetch medication
		if(null!=visit.getPatientMedication() && visit.getPatientMedication().size()>0) {
			Map<Integer, PatientMedicationDto> medicationMap = masterFeignClient.fetchMedicationMasterTableMapDetails();
			for(PatientMedication pm : visit.getPatientMedication()) {
				PatientMedicationDto obj = medicationMap.get(pm.getMedicationMasterId());
				pm.setMedicationName(obj.getMedicationName());
				pm.setMedicationGenericName(obj.getMedicationGenericName());
				pm.setMedicationManufacturerName(obj.getMedicationManufacturerName());
				pm.setMedicationStrength(obj.getMedicationStrength());
				pm.setMedicationForm(obj.getMedicationForm());
			}
		}
		}
		return visit;
	}


}
