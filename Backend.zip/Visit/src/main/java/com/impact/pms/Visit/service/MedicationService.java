package com.impact.pms.Visit.service;

public interface MedicationService {

	Integer deleteMedicationByVisitId(Integer visitId);
}
