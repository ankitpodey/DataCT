package com.impact.pms.Visit.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.impact.pms.Visit.model.PatientMedication;
/**
 * 
 * @author AnkitP4
 * Repository which can be used as a mechanism for encapsulating storage, retrieval,etc and for writing customized queries.
 *
 */
@Repository
public interface MedicationRepository extends JpaRepository<PatientMedication, Integer> {

	@Modifying
	@Query(value = "DELETE FROM consultation.patient_medication p " + 
			"WHERE " +
			"p.visit_id = :visitId", nativeQuery = true)
	Integer deleteMedicationByVisitId(Integer visitId);

//	Optional<PatientMedication> findPatientMedicationByVisitId(Integer visitId);

}
