package com.impact.pms.Visit.config;

//@Component
public class MasterDataFetch {
	
	
	//  MasterFeignClient feignClient;
	  
//	  @Autowired 
//	  public MasterDataFetch( MasterFeignClient feignClient)
//	  {
//		  this.feignClient=feignClient;
//	  }
//	  
//	 @PostConstruct
//	  public Map<Integer, PatientDiagnosisDto> fetchDiagnosisMasterTableMapDetails() 
//	  {
//	  
//	  System.out.println("master data fetch......");
//	  
//	  Map<Integer, PatientDiagnosisDto> map= new HashMap<>();
//	  map=feignClient.fetchDiagnosisMasterTableMapDetails();
//	  System.out.println(map.get(1)); return map; 
//	  }
//	 
	
	
}
