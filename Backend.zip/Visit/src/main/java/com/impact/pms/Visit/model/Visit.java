package com.impact.pms.Visit.model;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@Entity
@Table(name = "visit" ,schema = "consultation")
@ApiModel(description = "Details about the Visit")
public class Visit {
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@ApiModelProperty(notes="The unique id of the visit")
	private Integer visitId;

	private Integer patientId;

	private Integer appointmentId;

	private Integer physicianId;

	private Integer nurseId;

	private Double height;

	private Double weight;

	private String bloodPressure;

	private Double bodyTemperature;

	private Integer respirationRate;

	private boolean delFlag;
	
	@CreationTimestamp
	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;
	
	@JsonManagedReference
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "visit")
	private Set<PatientDiagnosis> patientDiagnosis;

	@JsonManagedReference
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "visit")
	private Set<PatientMedication> patientMedication;

	@JsonManagedReference
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "visit")
	private Set<PatientProcedure> patientProcedure;

	
	public Visit() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public Visit(Integer visitId, Integer patientId, Integer appointmentId, Integer physicianId, Integer nurseId,
			Double height, Double weight, String bloodPressure, Double bodyTemperature, Integer respirationRate,
			boolean delFlag, LocalDate dateCreated, LocalDate dateUpdated, Integer createdBy, Integer updatedBy,
			Set<PatientDiagnosis> patientDiagnosis, Set<PatientMedication> patientMedication,
			Set<PatientProcedure> patientProcedure) {
		super();
		this.visitId = visitId;
		this.patientId = patientId;
		this.appointmentId = appointmentId;
		this.physicianId = physicianId;
		this.nurseId = nurseId;
		this.height = height;
		this.weight = weight;
		this.bloodPressure = bloodPressure;
		this.bodyTemperature = bodyTemperature;
		this.respirationRate = respirationRate;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
		this.patientDiagnosis = patientDiagnosis;
		this.patientMedication = patientMedication;
		this.patientProcedure = patientProcedure;
	}



	public Set<PatientDiagnosis> getPatientDiagnosis() {
		return patientDiagnosis;
	}

	public void setPatientDiagnosis(Set<PatientDiagnosis> patientDiagnosis) {
		this.patientDiagnosis = patientDiagnosis;
	}

	public Set<PatientMedication> getPatientMedication() {
		return patientMedication;
	}

	public void setPatientMedication(Set<PatientMedication> patientMedication) {
		this.patientMedication = patientMedication;
	}

	public Set<PatientProcedure> getPatientProcedure() {
		return patientProcedure;
	}

	public void setPatientProcedure(Set<PatientProcedure> patientProcedure) {
		this.patientProcedure = patientProcedure;
	}

	public Integer getVisitId() {
		return visitId;
	}

	public void setVisitId(Integer visitId) {
		this.visitId = visitId;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public Integer getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(Integer appointmentId) {
		this.appointmentId = appointmentId;
	}

	public Integer getPhysicianId() {
		return physicianId;
	}

	public void setPhysicianId(Integer physicianId) {
		this.physicianId = physicianId;
	}

	public Integer getNurseId() {
		return nurseId;
	}

	public void setNurseId(Integer nurseId) {
		this.nurseId = nurseId;
	}

	public Double getHeight() {
		return height;
	}

	public void setHeight(Double height) {
		this.height = height;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getBloodPressure() {
		return bloodPressure;
	}

	public void setBloodPressure(String bloodPressure) {
		this.bloodPressure = bloodPressure;
	}

	public Double getBodyTemperature() {
		return bodyTemperature;
	}

	public void setBodyTemperature(Double bodyTemperature) {
		this.bodyTemperature = bodyTemperature;
	}

	public Integer getRespirationRate() {
		return respirationRate;
	}

	public void setRespirationRate(Integer respirationRate) {
		this.respirationRate = respirationRate;
	}

	

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((appointmentId == null) ? 0 : appointmentId.hashCode());
		result = prime * result + ((visitId == null) ? 0 : visitId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Visit other = (Visit) obj;
		if (appointmentId == null) {
			if (other.appointmentId != null)
				return false;
		} else if (!appointmentId.equals(other.appointmentId))
			return false;
		if (visitId == null) {
			if (other.visitId != null)
				return false;
		} else if (!visitId.equals(other.visitId))
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "Visit [visitId=" + visitId + ", patientId=" + patientId + ", appointmentId=" + appointmentId
				+ ", physicianId=" + physicianId + ", nurseId=" + nurseId + ", height=" + height + ", weight=" + weight
				+ ", bloodPressure=" + bloodPressure + ", bodyTemperature=" + bodyTemperature + ", respirationRate="
				+ respirationRate + ", delFlag=" + delFlag + ", dateCreated=" + dateCreated + ", dateUpdated="
				+ dateUpdated + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + ", patientDiagnosis="
				+ patientDiagnosis + ", patientMedication=" + patientMedication + ", patientProcedure="
				+ patientProcedure + "]";
	}

	
	
	
	
	
}
