package com.impact.pms.Visit.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.impact.pms.Visit.model.PatientDiagnosis;
/**
 * 
 * @author AnkitP4
 * Repository which can be used as a mechanism for encapsulating storage, retrieval,etc and for writing customized queries.
 *
 */
@Repository
public interface DiagnosisRepository extends JpaRepository<PatientDiagnosis, Integer> {

	@Modifying
	@Query(value = "DELETE FROM consultation.patient_diagnosis p " + 
			"WHERE " +
			"p.visit_id = :visitId", nativeQuery = true) 
	Integer deleteDiagnosisByVisitId(Integer visitId);


}
