package com.impact.pms.Visit.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.impact.pms.Visit.model.Visit;
/**
 * 
 * @author AnkitP4
 * Repository which can be used as a mechanism for encapsulating storage, retrieval,etc and for writing customized queries.
 *
 */
@Repository
public interface VisitRepository extends JpaRepository<Visit, Integer>{

	//@Query(value = "select v  from Visit v where v.appointmentId=:appointmentId and v.delFlag=:delFlag")
	//Visit findVisitByAppointmentIdAndDelFlag(Integer appointmentId,boolean delFlag);

	//@Query(value = "select v  from Visit v where v.appointmentId=:appointmentId")
	//	Visit findVisitByAppointmentIdAndDelFlag(Integer appointmentId,boolean delflag);


	List<Visit> findAllVisitsByPatientId(Integer patientId);

	List<Visit> findAllVisitByAppointmentIdAndDelFlag(Integer appointmentId, boolean delFlag);

	Visit findVisitByAppointmentId(Integer appointmentId);


}
