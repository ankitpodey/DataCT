package com.impact.pms.Visit.client;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;

import org.springframework.web.bind.annotation.GetMapping;

import com.impact.pms.Visit.dto.PatientDiagnosisDto;
import com.impact.pms.Visit.dto.PatientMedicationDto;
import com.impact.pms.Visit.dto.PatientProcedureDto;

@FeignClient("masterapp-ms")
public interface MasterFeignClient {
	
	@GetMapping("/master/diagnosis/fetch-diagnosis-master-table-map-details")
	public Map<Integer, PatientDiagnosisDto> fetchDiagnosisMasterTableMapDetails();
	
	@GetMapping("/master/medication/fetch-medication-master-table-map-details")
	public Map<Integer, PatientMedicationDto> fetchMedicationMasterTableMapDetails();
	
	@GetMapping("/master/procedure/fetch-procedure-master-table-map-details")
	public Map<Integer, PatientProcedureDto> fetchProcedureMasterTableMapDetails();

}
