package com.impact.pms.Visit.client;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient("employee-ms")
public interface EmployeeFeignClient {

	@GetMapping("/employee/getall-phy-nurse-map")
	public Map<Integer, String> getEmployeeNameMap();
	
}
