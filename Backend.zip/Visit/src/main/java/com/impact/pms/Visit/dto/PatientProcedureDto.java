package com.impact.pms.Visit.dto;

public class PatientProcedureDto {
	
	private Integer procedureMasterId;

	private String procedureCode;

	private String procedureDescription;

	private String procedureApproach;

	private boolean procedureDepricatedFlag;

	public PatientProcedureDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getProcedureMasterId() {
		return procedureMasterId;
	}

	public void setProcedureMasterId(Integer procedureMasterId) {
		this.procedureMasterId = procedureMasterId;
	}

	public String getProcedureCode() {
		return procedureCode;
	}

	public void setProcedureCode(String procedureCode) {
		this.procedureCode = procedureCode;
	}

	public String getProcedureDescription() {
		return procedureDescription;
	}

	public void setProcedureDescription(String procedureDescription) {
		this.procedureDescription = procedureDescription;
	}

	public String getProcedureApproach() {
		return procedureApproach;
	}

	public void setProcedureApproach(String procedureApproach) {
		this.procedureApproach = procedureApproach;
	}

	public boolean isProcedureDepricatedFlag() {
		return procedureDepricatedFlag;
	}

	public void setProcedureDepricatedFlag(boolean procedureDepricatedFlag) {
		this.procedureDepricatedFlag = procedureDepricatedFlag;
	}

	@Override
	public String toString() {
		return "PAtientProcedureDto [procedureMasterId=" + procedureMasterId + ", procedureCode=" + procedureCode
				+ ", procedureDescription=" + procedureDescription + ", procedureApproach=" + procedureApproach
				+ ", procedureDepricatedFlag=" + procedureDepricatedFlag + "]";
	}
	
	
}
