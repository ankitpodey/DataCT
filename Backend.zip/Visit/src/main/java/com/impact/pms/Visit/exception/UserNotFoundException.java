package com.impact.pms.Visit.exception;
/**
 * @author AnkitP4
 * This is the customized exception class.
 */
public class UserNotFoundException extends RuntimeException 
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserNotFoundException(String message) 
	{
		super(message);
	}
}
