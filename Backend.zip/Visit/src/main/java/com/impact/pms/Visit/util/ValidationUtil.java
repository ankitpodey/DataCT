package com.impact.pms.Visit.util;
/**
 * 
 * @author AnkitP4
 * 
 */
public class ValidationUtil {
	public static boolean checkEmpty(String value) {
		if( value == null ||  value.trim().equalsIgnoreCase("NONE") || 
				value.trim().replaceAll("\\.", "")
				.replaceAll("\\s+", "").equalsIgnoreCase("NA") || value.trim()
				.equalsIgnoreCase("NA") || value.trim().contains("N.A") || value.trim()
				.contains("N.A.") || 
				value.trim().equalsIgnoreCase("NIL") || 
				value.trim().isEmpty()) {
				return true;
		}
		return false;
	}
	
	public static boolean isStringNullOrEmpty(String string) {
		return checkEmpty(string) ? true : false;
	}
	
	@SuppressWarnings("static-access")
	public static boolean checkHeight(Double value) {
		if(value == null ||value.MIN_VALUE==1 || value.intValue()==2 ) {
			return true;
		}
		return false;
		
	}
	
	@SuppressWarnings("static-access")
	public static boolean checkWeight(Double value)
	{
		if(value == null ||value.MIN_VALUE==10 || value.MAX_VALUE==100|| value.intValue()==2)
		{
			return true;
		}
		return false;
	}

	public static boolean checkBloodPressure(String value) {
		
		if( value == null ||  value.trim().equalsIgnoreCase("NONE") || 
				value.trim().replaceAll("\\.", "")
				.replaceAll("\\s+", "").equalsIgnoreCase("NA") || value.trim()
				.equalsIgnoreCase("NA") || value.trim().contains("N.A") || value.trim()
				.contains("N.A.") || 
				value.trim().equalsIgnoreCase("NIL") || 
				value.trim().isEmpty()) {
				return true;
		}
		return false;
	}

	public static boolean checkBodyTemperature(Double bodyTemperature) {
		// TODO Auto-generated method stub
		return false;
	}

	public static boolean checkRespirationRate(Integer respirationRate) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
