package com.impact.pms.Visit.dto;

import java.time.LocalDate;
import java.util.Set;

public class PatientVisitDto {
	
	private Integer visitId;

	private Integer patientId;

	private Integer appointmentId;

	private Integer physicianId;
	
	private Integer nurseId;

	private Double height;

	private Double weight;

	private String bloodPressure;

	private Double bodyTemperature;

	private Integer respirationRate;
	
	private String physicianName;
	
	private String nurseName;
	
	private LocalDate dateCreated;
	
	private LocalDate dateUpdated;
	
	private Set<PatientDiagnosisDto> diagnosisdto;
	private Set<PatientMedicationDto> medicationdto;
	private Set<PatientProcedureDto> proceduredto;
	
	public Integer getVisitId() {
		return visitId;
	}
	public void setVisitId(Integer visitId) {
		this.visitId = visitId;
	}
	public Integer getPatientId() {
		return patientId;
	}
	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}
	public Integer getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(Integer appointmentId) {
		this.appointmentId = appointmentId;
	}
	
	public Integer getNurseId() {
		return nurseId;
	}
	public void setNurseId(Integer nurseId) {
		this.nurseId = nurseId;
	}
	public Double getHeight() {
		return height;
	}
	public void setHeight(Double height) {
		this.height = height;
	}
	public Double getWeight() {
		return weight;
	}
	public void setWeight(Double weight) {
		this.weight = weight;
	}
	public String getBloodPressure() {
		return bloodPressure;
	}
	public void setBloodPressure(String bloodPressure) {
		this.bloodPressure = bloodPressure;
	}
	public Double getBodyTemperature() {
		return bodyTemperature;
	}
	public void setBodyTemperature(Double bodyTemperature) {
		this.bodyTemperature = bodyTemperature;
	}
	public Integer getRespirationRate() {
		return respirationRate;
	}
	public void setRespirationRate(Integer respirationRate) {
		this.respirationRate = respirationRate;
	}
	public Set<PatientDiagnosisDto> getDiagnosisdto() {
		return diagnosisdto;
	}
	public void setDiagnosisdto(Set<PatientDiagnosisDto> diagnosisdto) {
		this.diagnosisdto = diagnosisdto;
	}
	public Set<PatientMedicationDto> getMedicationdto() {
		return medicationdto;
	}
	public void setMedicationdto(Set<PatientMedicationDto> medicationdto) {
		this.medicationdto = medicationdto;
	}
	public Set<PatientProcedureDto> getProceduredto() {
		return proceduredto;
	}
	public void setProceduredto(Set<PatientProcedureDto> proceduredto) {
		this.proceduredto = proceduredto;
	}
	public Integer getPhysicianId() {
		return physicianId;
	}
	public void setPhysicianId(Integer physicianId) {
		this.physicianId = physicianId;
	}
	
	public String getPhysicianName() {
		return physicianName;
	}
	public void setPhysicianName(String physicianName) {
		this.physicianName = physicianName;
	}
	public String getNurseName() {
		return nurseName;
	}
	public void setNurseName(String nurseName) {
		this.nurseName = nurseName;
	}
	public LocalDate getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}
	public LocalDate getDateUpdated() {
		return dateUpdated;
	}
	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}
	@Override
	public String toString() {
		return "PatientVisitDto [visitId=" + visitId + ", patientId=" + patientId + ", appointmentId=" + appointmentId
				+ ", physicianId=" + physicianId + ", nurseId=" + nurseId + ", height=" + height + ", weight=" + weight
				+ ", bloodPressure=" + bloodPressure + ", bodyTemperature=" + bodyTemperature + ", respirationRate="
				+ respirationRate + ", physicianName=" + physicianName + ", nurseName=" + nurseName + ", dateCreated="
				+ dateCreated + ", dateUpdated=" + dateUpdated + ", diagnosisdto=" + diagnosisdto + ", medicationdto="
				+ medicationdto + ", proceduredto=" + proceduredto + "]";
	}
	
}
