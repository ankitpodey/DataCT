package com.impact.pms.Visit.serviceImpl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.pms.Visit.dao.ProcedureRepository;
import com.impact.pms.Visit.service.ProcedureService;

@Service
public class ProcedureServiceImpl implements ProcedureService {

	@Autowired
	ProcedureRepository pr;
	
	@Transactional
	@Override
	public Integer deleteProcedureByVisitId(Integer visitId) {
		return pr.deleteProcedureByVisitId(visitId);
	}

}
