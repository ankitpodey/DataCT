package com.impact.pms.Visit.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;


/**
 * @author AnkitP4
 * This class can register bean in container for  custom Messages .
 */
@Configuration
public class CustomMessageSourceConfiguration {
	
	private final static Logger log = LoggerFactory.getLogger(CustomMessageSourceConfiguration.class);
	  
	  @Bean
	  public MessageSource messageSource() {
	  ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
	  log.info("data received" +messageSource);
	  messageSource.setBasenames("classpath:response-message",  "classpath:validation-error-message");
	  messageSource.setDefaultEncoding("UTF-8"); return messageSource;
	  }
	  
	  @Bean
	  public LocalValidatorFactoryBean getValidator() 
	  {
	  LocalValidatorFactoryBean bean = new LocalValidatorFactoryBean();
	  log.info("data received" +bean);
	  bean.setValidationMessageSource(messageSource());
	  return bean; 
	  }
	 
}
