package com.impact.pms.Visit.controller;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.impact.pms.Visit.client.MasterFeignClient;
import com.impact.pms.Visit.dto.PatientVisitDto;
import com.impact.pms.Visit.dto.ResponseMessageDto;
import com.impact.pms.Visit.model.PatientDiagnosis;
import com.impact.pms.Visit.model.PatientMedication;
import com.impact.pms.Visit.model.PatientProcedure;
import com.impact.pms.Visit.model.Visit;
import com.impact.pms.Visit.service.VisitService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
@RestController
@RequestMapping("/visit")
@PropertySource("classpath:response-message.properties")
public class VisitController {

	private final static Logger log = LoggerFactory.getLogger(VisitController.class);

	@Autowired
	VisitService visitService;

	@Autowired
	private Environment env;

	@Autowired
	MasterFeignClient masterFeignClient;

	@Autowired
	@Qualifier("VisitValidator")
	private Validator visitValidator;
	

	/*
	 * @InitBinder("visit") public void visitInitBinder(WebDataBinder binder) {
	 * binder.setValidator(visitValidator); }
	 */

	/**
	 * For capturing vitals
	 * @param visit
	 * @return
	 */
	  @PostMapping("/capture-vitals") 
	  @ApiOperation(value = "To Capture Vitals",notes = "To capture vitals by applying POST method")
	  public ResponseEntity<String>  captureVitals(  @ApiParam(value = "To capture vitals by applying POST method",required = true)
			  @RequestBody Visit visit) 
	  { 
			log.info("Capturing vitals "+ visit);
		  Visit captureVitals =visitService.captureVitals(visit); 
		  if(captureVitals!=null)
				return ResponseEntity.ok(env.getProperty("capturevitals.success"));
			return ResponseEntity.ok(env.getProperty("capturevitals.fail"));
		  }
	  /**
		 * For capturing Diagnosis
		 * @param visit
		 * @return
		 */
	  @PostMapping("/capture-diagnosis")
	  @ApiOperation(value = "To Capture Diagnosis",notes = "To capture diagnosis by applying POST method")
	  public ResponseEntity<String>  captureDiagnosis(  @ApiParam(value = "To capture diagnosis by applying POST method",required = true)
			  @RequestBody PatientDiagnosis diagnosis) 
	  { 
		  log.info("Capturing Diagnosis "+ diagnosis);
		  PatientDiagnosis captureDiagnosis=visitService.captureDiagnosis(diagnosis);
		  if(captureDiagnosis!=null)
				return ResponseEntity.ok(env.getProperty("capturediagnosis.success"));
			return ResponseEntity.ok(env.getProperty("capturediagnosis.fail"));
		  }
	
	  /**
		 * For capturing Procedure
		 * @param visit
		 * @return
		 */
	  @PostMapping("/capture-procedure")
	  @ApiOperation(value = "To Capture Procedure",notes = "To capture procedure by applying POST method")
	  public ResponseEntity<String>  captureProcedure( @ApiParam(value = "To capture procedure by applying POST method",required = true)
			  @RequestBody PatientProcedure procedure) 
	  { 
		  log.info("Capturing procedure "+ procedure);
		  PatientProcedure captureProcedure=visitService.captureProcedure(procedure);
		  if(captureProcedure!=null)
				return ResponseEntity.ok(env.getProperty("captureprocedure.success"));
			return ResponseEntity.ok(env.getProperty("captureprocedure.fail"));
		  }
	
	  /**
		 * For capturing Medications
		 * @param visit
		 * @return
		 */
	  @PostMapping("/capture-medication")
	  @ApiOperation(value = "To Capture Medications",notes = "To capture medications by applying POST method")
	  public ResponseEntity<String>  captureProcedure( @ApiParam(value = "To capture medications by applying POST method",required = true)
			  @RequestBody PatientMedication medication) 
	  { 
		  log.info("Capturing medication "+ medication);
		  PatientMedication captureMedication=visitService.captureMedication(medication);
		  if(captureMedication!=null)
				return ResponseEntity.ok(env.getProperty("capturemedication.success"));
			return ResponseEntity.ok(env.getProperty("capturemedication.fail"));
	  }
		/**
		 * Finds vitals by Appointment id
		 * @param appointmentId
		 * @return
		 */
	  @GetMapping("/get-visit-detail/{appointmentId}")
	  @ApiOperation(value = "Find vitals by id",notes = "Provide an id to look up vitals")
	  public ResponseEntity<Visit> getVitals( @ApiParam(value = "ID value for the vitals we need to retrieve",required = true)
			  @ PathVariable Integer appointmentId)
	  {
		  log.info("Finds vitals by id "+ appointmentId);
		 //Visit visit=visitService.getVitals(appointmentId);
		  Visit visit = visitService.getVisitDetail(appointmentId);
			return ResponseEntity.ok(visit);	
	  }
	
	  /**
	   * Finds Diagnosis by Visit id
	   * @param visitId
	   * @return
	   */
	  @GetMapping("/get-diagnosis/{visitId}")
	  @ApiOperation(value = "Finds Diagnosis by id",notes = "Provide an id to look up specific visit from the visits")
	  public ResponseEntity<Visit> getDiagnosis(@ApiParam(value = "ID value for the visit we need to retrieve",required = true)
			  @ PathVariable Integer visitId)
	  {
		  log.info("Finds Diagnosis by id "+ visitId);
		 Visit visit=visitService.getDiagnosis(visitId);
			return ResponseEntity.ok(visit);	
	  }
	 
	  /**
	   * Finds procedure by Diagnosis id
	   * @param visitId
	   * @return
	   */
	  @GetMapping("/get-procedure/{diagnosisId}")//(visit id)
	  @ApiOperation(value = "Finds procedure by id",notes = "Provide an id to look up specific procedure from the PatientDiagnosis")
	  public ResponseEntity<PatientDiagnosis> getProcedure(@ApiParam(value = "ID value for the procedure we need to retrieve",required = true)
			  @ PathVariable Integer diagnosisId)
	  {
		  log.info("Finds procedure by id "+ diagnosisId);
		 PatientDiagnosis patientDiagnosis=visitService.getProcedure(diagnosisId);
			return ResponseEntity.ok(patientDiagnosis);	
	  }
	  /**
	   * Finds Medications by Diagnosis id
	   * @param visitId
	   * @return
	   */
	  @GetMapping("/get-medication/{visitId}")//(visit id)
	  @ApiOperation(value = "Finds Medications by id",notes = "Provide an id to look up specific medication from the PatientMedication")
	  public ResponseEntity<PatientMedication> getMedication(@ApiParam(value = "ID value for the medication we need to retrieve",required = true)
			  @ PathVariable Integer visitId)
	  {
		  log.info("Finds Medications by id "+ visitId);
		  PatientMedication patientMedication=visitService.getMedication(visitId);
			return ResponseEntity.ok(patientMedication);	
	  }
	  
		
	  /**
	   * Finds past Visit Details by Patient id
	   * @param patientId
	   * @return
	   */	
	  @GetMapping("/past-visit-details/{patientId}")
	  @ApiOperation(value = "Finds past Visit Details by Patient id",notes = "To find past Visit Details by Patient id")
	  public ResponseEntity<List<PatientVisitDto>>pastVisitDetails(@PathVariable Integer patientId)
	  {
		  List<PatientVisitDto> patientVisitDto  =visitService.pastVisitDetails(patientId);
		   return ResponseEntity.ok(patientVisitDto);
	 }
		 
	  @PostMapping("/capture-visit")
	  public ResponseEntity<ResponseMessageDto> addVisitDetail(@RequestBody PatientVisitDto patientVisitDto){
		  boolean result = visitService.saveVisitDetail(patientVisitDto);
		  if(result)
			  return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("addvisit.success"), result));
		  return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("addvisit.fail"), result));
	  }
		 
	 
	

}
