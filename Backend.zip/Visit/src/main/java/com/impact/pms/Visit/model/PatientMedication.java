package com.impact.pms.Visit.model;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Entity
@Table(name = "patientMedication" ,schema = "consultation")
@ApiModel(description = "Details about the PatientMedication")
public class PatientMedication {
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@ApiModelProperty(notes="The unique id of the medication")
	private Integer patientMedicationId;

	
	private Integer medicationMasterId;

	private String dosage;

	private boolean delFlag;
	@CreationTimestamp
	private LocalDate dateCreated;

	private LocalDate dateUpdated;
	
	@JsonBackReference
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "visit_id" ,nullable = false)
	private Visit visit;
	
	@Transient
	private String medicationForm;

	@Transient
	private String medicationStrength;
	
	@Transient
	private String medicationId;

	@Transient
	private String medicationName;

	@Transient
	private String medicationGenericName;

	@Transient
	private String medicationManufacturerName;

	public PatientMedication() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PatientMedication(Integer patientMedicationId,  Integer medicationMasterId, String dosage,
			boolean delFlag, LocalDate dateCreated, LocalDate dateUpdated, Visit visit) {
		super();
		this.patientMedicationId = patientMedicationId;
		
		this.medicationMasterId = medicationMasterId;
		this.dosage = dosage;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.visit = visit;
	}




	public Integer getPatientMedicationId() {
		return patientMedicationId;
	}

	public void setPatientMedicationId(Integer patientMedicationId) {
		this.patientMedicationId = patientMedicationId;
	}

	
	
	public Integer getMedicationMasterId() {
		return medicationMasterId;
	}

	public void setMedicationMasterId(Integer medicationMasterId) {
		this.medicationMasterId = medicationMasterId;
	}

	public String getDosage() {
		return dosage;
	}

	public void setDosage(String dosage) {
		this.dosage = dosage;
	}

	public Visit getVisit() {
		return visit;
	}

	public void setVisit(Visit visit) {
		this.visit = visit;
	}


	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}
	
	

	public String getMedicationForm() {
		return medicationForm;
	}

	public void setMedicationForm(String medicationForm) {
		this.medicationForm = medicationForm;
	}

	public String getMedicationStrength() {
		return medicationStrength;
	}

	public void setMedicationStrength(String medicationStrength) {
		this.medicationStrength = medicationStrength;
	}

	public String getMedicationId() {
		return medicationId;
	}

	public void setMedicationId(String medicationId) {
		this.medicationId = medicationId;
	}

	public String getMedicationName() {
		return medicationName;
	}

	public void setMedicationName(String medicationName) {
		this.medicationName = medicationName;
	}

	public String getMedicationGenericName() {
		return medicationGenericName;
	}

	public void setMedicationGenericName(String medicationGenericName) {
		this.medicationGenericName = medicationGenericName;
	}

	public String getMedicationManufacturerName() {
		return medicationManufacturerName;
	}

	public void setMedicationManufacturerName(String medicationManufacturerName) {
		this.medicationManufacturerName = medicationManufacturerName;
	}

	@Override
	public String toString() {
		return "PatientMedication [patientMedicationId=" + patientMedicationId + 
				 ", medicationMasterId=" + medicationMasterId + ", dosage=" + dosage
				+ ", delFlag=" + delFlag + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated + "]";
	}




	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((medicationMasterId == null) ? 0 : medicationMasterId.hashCode());
		return result;
	}




	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PatientMedication other = (PatientMedication) obj;
		if (medicationMasterId == null) {
			if (other.medicationMasterId != null)
				return false;
		} else if (!medicationMasterId.equals(other.medicationMasterId))
			return false;
		return true;
	}

	
	
}
