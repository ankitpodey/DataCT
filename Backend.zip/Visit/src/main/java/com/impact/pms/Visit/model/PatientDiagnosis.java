package com.impact.pms.Visit.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonBackReference;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @author AnkitP4
 *
 */
@Entity
@Table(name = "patientDiagnosis" ,schema = "consultation")
@ApiModel(description = "Details about the PatientDiagnosis")
public class PatientDiagnosis {
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@ApiModelProperty(notes="The unique id of the diagnosis")
	private Integer patientDiagnosisId;

	
	private Integer diagnosisMasterId;

	private boolean delFlag;
	@CreationTimestamp
	private LocalDate dateCreated;

	private LocalDate dateUpdated;
	
	@JsonBackReference
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "visit_id" ,nullable = false)
	private Visit visit;
	
	//just to send data
	@Transient
	private String diagnosisCode;

	@Transient
	private String diagnosisDescription;
	
	public PatientDiagnosis() {
		super();
		// TODO Auto-generated constructor stub
	}


	public PatientDiagnosis(Integer patientDiagnosisId, Integer diagnosisMasterId, boolean delFlag,
			LocalDate dateCreated, LocalDate dateUpdated, Visit visit, String diagnosisCode,
			String diagnosisDescription) {
		super();
		this.patientDiagnosisId = patientDiagnosisId;
		this.diagnosisMasterId = diagnosisMasterId;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.visit = visit;
		this.diagnosisCode = diagnosisCode;
		this.diagnosisDescription = diagnosisDescription;
	}

	public Visit getVisit() {
		return visit;
	}

	public void setVisit(Visit visit) {
		this.visit = visit;
	}



	public Integer getPatientDiagnosisId() {
		return patientDiagnosisId;
	}

	public void setPatientDiagnosisId(Integer patientDiagnosisId) {
		this.patientDiagnosisId = patientDiagnosisId;
	}

	

	public Integer getDiagnosisMasterId() {
		return diagnosisMasterId;
	}

	public void setDiagnosisMasterId(Integer diagnosisMasterId) {
		this.diagnosisMasterId = diagnosisMasterId;
	}

	

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	


	public String getDiagnosisCode() {
		return diagnosisCode;
	}



	public void setDiagnosisCode(String diagnosisCode) {
		this.diagnosisCode = diagnosisCode;
	}



	public String getDiagnosisDescription() {
		return diagnosisDescription;
	}



	public void setDiagnosisDescription(String diagnosisDescription) {
		this.diagnosisDescription = diagnosisDescription;
	}



	@Override
	public String toString() {
		return "PatientDiagnosis [patientDiagnosisId=" + patientDiagnosisId + ", diagnosisMasterId=" + diagnosisMasterId
				+ ", delFlag=" + delFlag + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated + ", visit="
				+ visit + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((diagnosisMasterId == null) ? 0 : diagnosisMasterId.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PatientDiagnosis other = (PatientDiagnosis) obj;
		if (diagnosisMasterId == null) {
			if (other.diagnosisMasterId != null)
				return false;
		} else if (!diagnosisMasterId.equals(other.diagnosisMasterId))
			return false;
		return true;
	}

	
	
}
