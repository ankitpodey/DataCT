package com.impact.pms.Visit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VisitApplicationTests {

	@Test
	void contextLoads() {
	}

}
