package com.impact.pms.patient.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.impact.pms.patient.dto.PatientDto;
import com.impact.pms.patient.dto.PatientRegistrationDto;
import com.impact.pms.patient.dto.ResponseMessageDto;
import com.impact.pms.patient.model.Patient;
import com.impact.pms.patient.service.PatientService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/patient")
@PropertySource("classpath:response-message.properties")
public class PatientController {
	
	private final static Logger log = LoggerFactory.getLogger(PatientController.class);
	
	
	@Autowired
	private Environment env;
	
	@Autowired
	private PatientService service;
	
	@Autowired
	@Qualifier("PatientRegistrationDtoValidator")
	private Validator patientRegistrationDtoValidator;
	
	@InitBinder("patientRegistrationDto")
	public void patientRegistrationDtoInitBinder(WebDataBinder binder) {
		binder.setValidator(patientRegistrationDtoValidator);
	}
	
	/**
	 * Endpoint for fetching list of All patients
	 * @return
	 */
	@ApiOperation(value = "get all patients", notes = "get all registered patient details using GET method")
	@GetMapping("/fetch-all")
	public ResponseEntity<List<Patient>> getAllPatients(){
		
		List<Patient> patientList = service.getAllPatients();
		return ResponseEntity.ok(patientList); 
		
	}
	
	
	/**
	 * Endpoint for adding a patient(patient registration)
	 * @param patient
	 * @return
	 */
	@ApiOperation(value = "add patient", notes = "To capture patient registration data using post method")
	@PostMapping
	public ResponseEntity<ResponseMessageDto> addPatient(@ApiParam(value = "Patient registration details", required = true)
	@Validated @RequestBody PatientRegistrationDto patientRegistrationDto) {
		log.info("data received : " + patientRegistrationDto);
		Patient patientResult = service.addPatient(patientRegistrationDto);
		if(patientResult!=null)
			return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("patient.registration.success"), true));
		return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("patient.registration.fail"), false));
	}
	
	
	/**
	 * Endpoint for updating Patient(patient update profile)
	 * @param patient
	 * @return
	 */
	//add validation, and check allergies insertion
	@ApiOperation(value = "update patient", notes = "To update patient profile data using put method")
	@PutMapping
	public ResponseEntity<ResponseMessageDto> updatePatient(@ApiParam(value = "updated patient profile data", required = true)
	@RequestBody PatientDto patient) {
		log.info("in PatientController, updatePatient() ");
		PatientDto patientResult = service.updatePatient(patient);
		if(patientResult!=null) {
			return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("patient.profile.update.success"), true));
		}
		return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("patient.profile.update.fail"), false));
	}
	
	/**
	 * Endpoint for fetching patient profile by patientId
	 * @param patientId
	 * @return
	 */
	@ApiOperation(value = "get patient", notes = "get Patient data using get method and providing the patient id")
	@GetMapping("/{patientId}")
	public ResponseEntity<PatientDto> getPatientById(@ApiParam(value = "Patient identifier", required = true)
	@PathVariable Integer patientId) {
		PatientDto result = service.getPatientById(patientId);
		return ResponseEntity.ok(result);
		
	}
	
	/**
	 * Endpoint for fetching count of active patients
	 * @return
	 */
	@ApiOperation(value = "get patient user count", notes = "get registered patient user count using get method")
	@GetMapping("/patient-user-count")
	public ResponseEntity<Integer> getPatientUserCount() {
		Integer result = service.getPatientUserCount();
		return ResponseEntity.ok(result);
	}
	
	/**
	 * Endpoint to fetch patient info using userId
	 * @param userId
	 * @return
	 */
	@ApiOperation(value = "get patient info", notes = "get patient info, name and employeeId using get method")
	@GetMapping("/get-patient-info-map/{userId}")
	public ResponseEntity<Map<String, Object>> getPatietInfoMap(@ApiParam(value = "userId of the employee", required = true)
	@PathVariable Integer userId){
		Map<String,Object> patientInfoMap = service.getPatietInfoMap(userId); 
		return ResponseEntity.ok(patientInfoMap);
	}
	
	@GetMapping("/getall-name-of-patient")
	public ResponseEntity<Map<Integer, String>> getNameOfPatient(){
		log.info("in Patient Controller -> getNameOfPatient()");
		Map<Integer, String> patientMap = service.getMapOfNameOfPatient();
		return ResponseEntity.ok(patientMap);
	}
	
	
}
