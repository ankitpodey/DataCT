package com.impact.pms.patient.service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.impact.pms.patient.client.AllergyMasterFeignClient;
import com.impact.pms.patient.constants.ApplicationConstants;
import com.impact.pms.patient.constants.ApplicationConstants.Roles;
import com.impact.pms.patient.dao.PatientRepository;
import com.impact.pms.patient.dto.PatientDto;
import com.impact.pms.patient.dto.PatientRegistrationDto;
import com.impact.pms.patient.exception.UserNotFoundException;
import com.impact.pms.patient.model.Patient;
import com.impact.pms.patient.model.PatientAllergy;
import com.impact.pms.patient.model.User;

/**
 * @author AnupM2
 * 
 *
 */
@Service
public class PatientServiceImpl implements PatientService {

	private final static Logger log = LoggerFactory.getLogger(PatientServiceImpl.class);
	
	@Autowired
	private PatientRepository repository;

	@Autowired
	private AllergyMasterFeignClient allergyMasterFeignClient;
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private PatientAllergyService patientAllergyService;

	@Override
	public List<Patient> getAllPatients() {
		// TODO Auto-generated method stub
		return repository.findAll();

	}

	@Override
	public Patient addPatient(PatientRegistrationDto patientDto) {
		Patient patient = new Patient();
		//populate user obj
		User user = new User();
		BeanUtils.copyProperties(patientDto, user); 
		user.setActive(true);
		user.setRoleId(Roles.ROLE_ID_OF_PATIENT);
		//encrypt password
		String encPassword = bCryptPasswordEncoder.encode(user.getPassword());
		//log.info("encPassword " + encPassword);
		user.setPassword(encPassword);

		//populate patient obj
		BeanUtils.copyProperties(patientDto, patient);
		patient.setUser(user);
		return repository.save(patient);
	}

	@Transactional
	@Override
	public PatientDto updatePatient(PatientDto patientDto) {
		Patient patient = new Patient();
		log.info("updatepatient serviceImpl" +patientDto);
		BeanUtils.copyProperties(patientDto, patient);
		log.info("updatepatient serviceImpl" +patient);
		//added this as PatientDto is not having user attribute so the corresponding relationship will be lost when updated by SPring JPA
		//fetching old patient data, and setting in the update patient object
		Optional<Patient> currPatient = repository.findById(patientDto.getPatientId());
		//log.info(" currPatient update serviceImpl" +currPatient.get());
		patient.setUser(currPatient.get().getUser());

		//setting patient in patient allergy
		Set<PatientAllergy> patientAllergies =  patient.getPatientAllergies();
		if(null!= patientAllergies && patientAllergies.size()>0) {
			for(PatientAllergy pa : patientAllergies) {
				pa.setPatient(patient);
				pa.setDateCreated(LocalDate.now());
			}
		}
		
		patient.setPatientAllergies(patientAllergies);

		//delete previous patient allergies
		if(patient.getPatientId()!=null) {
			patientAllergyService.deleteAllergyByPatientId(patient.getPatientId());
		}
		
		
		
		//saving the patient
		patient.setDateUpdated(LocalDate.now());
		patient.setDateCreated(currPatient.get().getDateCreated());
		Patient updatedPatient = repository.save(patient);

		//log.info(" updatedPatient update serviceImpl" +updatedPatient);

		BeanUtils.copyProperties(updatedPatient, patientDto);
		//log.info(" updatedPatient patientDto update serviceImpl" +patientDto);
		return patientDto;
	}

	@Override
	
	public PatientDto getPatientById(Integer patientId) {
		PatientDto patientDto = new PatientDto();
		Optional<Patient> optionalPatient = repository.findById(patientId);
		
		
		
		if(optionalPatient.isPresent())
		{
			BeanUtils.copyProperties(optionalPatient.get(), patientDto);
			if(null != patientDto.getPatientAllergies() && patientDto.getPatientAllergies().size()> 0)
			{
				Map<Integer, String> map = allergyMasterFeignClient.fetchAllergyMasterMapTableDetails();
				for(PatientAllergy  allergy : patientDto.getPatientAllergies())
				{
					String allergyName =map.get(allergy.getAllergyMasterId());
					allergy.setAllergyName(allergyName);
				}
			}
		}
		
		else
			throw new UserNotFoundException("Patient not found");
		return patientDto;
	}

	@Override
	public Integer getPatientUserCount() {
		return repository.fetchPatientUserCount();
	}

	@Override
	public Map<String, Object> getPatietInfoMap(Integer userId) {
		Patient patient = new Patient();
		Optional<Patient> optionalPatent = repository.findPatientByUserId(userId);
		patient = optionalPatent.get();
		Map<String, Object> patientInfoMap = new HashMap<String, Object>();
		patientInfoMap.put("name", patient.getFirstName()+ " " + patient.getLastName());
		patientInfoMap.put("patientId", patient.getPatientId());
		return patientInfoMap;
	}


	@Override
	public Map<Integer, String> getMapOfNameOfPatient() {
		List<Patient> patientList = repository.getMapOfNameOfPatient(ApplicationConstants.DEL_FLAG_FALSE);
		Map<Integer, String> patientMap = new HashMap<Integer, String>();
		if(patientList.size()!=0) {
			for(Patient patient: patientList) {
				patientMap.put(patient.getPatientId(), patient.getFirstName() + " " + patient.getLastName());
			}
		}
		return patientMap;
		
	}
	

}
