package com.impact.pms.patient.client;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient("masterapp-ms")
public interface AllergyMasterFeignClient {
	
	
	@GetMapping("/master/allergy/fetch-allergy-master-map-details")
	 public Map<Integer, String> fetchAllergyMasterMapTableDetails();
}
