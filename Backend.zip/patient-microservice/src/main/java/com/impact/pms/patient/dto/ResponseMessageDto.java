package com.impact.pms.patient.dto;

public class ResponseMessageDto {

	
	private String msg;
	private boolean successFlag;
	
	
	
	public ResponseMessageDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ResponseMessageDto(String msg, boolean successFlag) {
		super();
		this.msg = msg;
		this.successFlag = successFlag;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public boolean isSuccessFlag() {
		return successFlag;
	}
	public void setSuccessFlag(boolean successFlag) {
		this.successFlag = successFlag;
	}
	
	
	
	
}
