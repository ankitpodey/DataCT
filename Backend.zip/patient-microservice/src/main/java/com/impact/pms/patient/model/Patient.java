package com.impact.pms.patient.model;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@Entity
@Table(name = "patient", schema = "useradministration")
@ApiModel(description = "details about Patient entity")
public class Patient {

	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty(notes = "Identifier for Patient Entity")
	private Integer patientId;

	private String title;

	private String firstName;

	private String lastName;

	private String emailId;

	private LocalDate dateOfBirth;

	private String contactNumber;

	private String gender;

	private String race;

	private String ethinicity;

	private String languagesKnown;

	private String addressLineOne;

	private String addressLineTwo;

	private String addressStreet;

	private String addressLandmark;

	private String addressCity;

	private String addressState;

	private String addressCountry;

	private String addressZipCode;

	@CreationTimestamp
	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private boolean delFlag;

	private Integer createdBy;

	private Integer updatedBy;

	private boolean verificationFlag;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id")
	private User user;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "patient_emergency_contact_id")
	private PatientEmergencyContact patientEmergencyContact;
	
	@JsonManagedReference
	@OneToMany(mappedBy = "patient", cascade = CascadeType.ALL)
	private Set<PatientAllergy> patientAllergies;

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	public String getEthinicity() {
		return ethinicity;
	}

	public void setEthinicity(String ethinicity) {
		this.ethinicity = ethinicity;
	}

	public String getLanguagesKnown() {
		return languagesKnown;
	}

	public void setLanguagesKnown(String languagesKnown) {
		this.languagesKnown = languagesKnown;
	}

	public String getAddressLineOne() {
		return addressLineOne;
	}

	public void setAddressLineOne(String addressLineOne) {
		this.addressLineOne = addressLineOne;
	}

	public String getAddressLineTwo() {
		return addressLineTwo;
	}

	public void setAddressLineTwo(String addressLineTwo) {
		this.addressLineTwo = addressLineTwo;
	}

	public String getAddressStreet() {
		return addressStreet;
	}

	public void setAddressStreet(String addressStreet) {
		this.addressStreet = addressStreet;
	}

	public String getAddressLandmark() {
		return addressLandmark;
	}

	public void setAddressLandmark(String addressLandmark) {
		this.addressLandmark = addressLandmark;
	}

	public String getAddressCity() {
		return addressCity;
	}

	public void setAddressCity(String addressCity) {
		this.addressCity = addressCity;
	}

	public String getAddressState() {
		return addressState;
	}

	public void setAddressState(String addressState) {
		this.addressState = addressState;
	}

	public String getAddressCountry() {
		return addressCountry;
	}

	public void setAddressCountry(String addressCountry) {
		this.addressCountry = addressCountry;
	}

	public String getAddressZipCode() {
		return addressZipCode;
	}

	public void setAddressZipCode(String addressZipCode) {
		this.addressZipCode = addressZipCode;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public boolean isVerificationFlag() {
		return verificationFlag;
	}

	public void setVerificationFlag(boolean verificationFlag) {
		this.verificationFlag = verificationFlag;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public PatientEmergencyContact getPatientEmergencyContact() {
		return patientEmergencyContact;
	}

	public void setPatientEmergencyContact(PatientEmergencyContact patientEmergencyContact) {
		this.patientEmergencyContact = patientEmergencyContact;
	}

	public Set<PatientAllergy> getPatientAllergies() {
		return patientAllergies;
	}

	public void setPatientAllergies(Set<PatientAllergy> patientAllergies) {
		this.patientAllergies = patientAllergies;
	}

	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", title=" + title + ", firstName=" + firstName + ", lastName="
				+ lastName + ", emailId=" + emailId + ", dateOfBirth=" + dateOfBirth + ", contactNumber="
				+ contactNumber + ", gender=" + gender + ", race=" + race + ", ethinicity=" + ethinicity
				+ ", languagesKnown=" + languagesKnown + ", addressLineOne=" + addressLineOne + ", addressLineTwo="
				+ addressLineTwo + ", addressStreet=" + addressStreet + ", addressLandmark=" + addressLandmark
				+ ", addressCity=" + addressCity + ", addressState=" + addressState + ", addressCountry="
				+ addressCountry + ", addressZipCode=" + addressZipCode + ", dateCreated=" + dateCreated
				+ ", dateUpdated=" + dateUpdated + ", delFlag=" + delFlag + ", createdBy=" + createdBy + ", updatedBy="
				+ updatedBy + ", verificationFlag=" + verificationFlag + ", user=" + user + ", patientEmergencyContact="
				+ patientEmergencyContact + ", patientAllergies=" + patientAllergies + "]";
	}

	
}
