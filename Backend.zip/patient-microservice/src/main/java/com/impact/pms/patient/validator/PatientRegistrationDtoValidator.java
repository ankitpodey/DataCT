package com.impact.pms.patient.validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.impact.pms.patient.dto.PatientRegistrationDto;
import com.impact.pms.patient.util.ValidationUtil;

@Component
@Qualifier("PatientRegistrationDtoValidator")
public class PatientRegistrationDtoValidator implements Validator{

	private final static Logger log = LoggerFactory.getLogger(PatientRegistrationDto.class);

	@Override
	public boolean supports(Class<?> clazz) {
		//specify class to validate
		return PatientRegistrationDto.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		log.info("validating PatientRegistrationDto object "+ target);

		//cast target to PatientRegistrationDto
		PatientRegistrationDto patientDto = (PatientRegistrationDto) target;

		//perform validation
		if(ValidationUtil.isStringNullOrEmpty(patientDto.getFirstName())) {
			errors.rejectValue("firstName", "patientRegistrationDto.firstName.invalid");
		}
		
		if(!isNameLengthValid(patientDto.getFirstName())) {
			errors.rejectValue("firstName", "patientRegistrationDto.firstName.length.invalid");
		}
		
		

		if(ValidationUtil.isStringNullOrEmpty(patientDto.getLastName())) {
			errors.rejectValue("lastName", "patientRegistrationDto.lastName.invalid");
		}
		
		if(!isNameLengthValid(patientDto.getLastName())) {
			errors.rejectValue("lastName", "patientRegistrationDto.lastName.length.invalid");
		}
		
		
		if(!ValidationUtil.isPreviousDate(patientDto.getDateOfBirth())) {
			errors.rejectValue("dateOfBirth", "patientRegistrationDto.dateOfBirth.invalid");
		}
		
		
		if(!ValidationUtil.isEmailValid(patientDto.getEmailId())) {
			errors.rejectValue("emailId", "patientRegistrationDto.emailId.invalid");
		}
		
		if(!ValidationUtil.isMobNumValid(patientDto.getContactNumber())) {
			errors.rejectValue("contactNumber", "patientRegistrationDto.contactNumber.invalid");
		}
		
		if(!patientDto.getPassword().equals(patientDto.getConfirmPassword())) {
			errors.rejectValue("password", "patientRegistrationDto.password.mismatch");
		}
		
		




	}
	
	private boolean isNameLengthValid(String name) {
		if(name.length()>2 && name.length()<21) {
			return true;
		}
		return false;
	}

}
