package com.impact.pms.patient.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedDate;

import com.fasterxml.jackson.annotation.JsonBackReference;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "patient_allergy", schema = "useradministration")
@ApiModel(description = "details about PatientAllergy entity")
public class PatientAllergy {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty(notes = "ideitifier for PatientAllergy entity")
	private Integer patientAllergyId;
	//private String patientId;
	private Integer allergyMasterId;
	private String allergyClinicalInformation;
	private boolean allergyFatal;
	private boolean delFlag;
	@CreatedDate
	private LocalDate dateCreated;
	@UpdateTimestamp
	private LocalDate dateUpdated;
	private Integer createdBy;
	private Integer updatedBy;
	@Transient
	private String allergyName;

	@JsonBackReference
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "patient_id", nullable = false)
	private Patient patient;
	
	
	public Integer getPatientAllergyId() {
		return patientAllergyId;
	}
	public void setPatientAllergyId(Integer patientAllergyId) {
		this.patientAllergyId = patientAllergyId;
	}

	/*
	 * public Integer getPatientId() { return patientId; } public void
	 * setPatientId(Integer patientId) { this.patientId = patientId; }
	 */
	public String getAllergyName() {
		return allergyName;
	}

	public void setAllergyName(String allergyName) {
		this.allergyName = allergyName;
	}
	public Integer getAllergyMasterId() {
		return allergyMasterId;
	}
	public void setAllergyMasterId(Integer allergyMasterId) {
		this.allergyMasterId = allergyMasterId;
	}
	public String getAllergyClinicalInformation() {
		return allergyClinicalInformation;
	}
	public void setAllergyClinicalInformation(String allergyClinicalInformation) {
		this.allergyClinicalInformation = allergyClinicalInformation;
	}
	public boolean isAllergyFatal() {
		return allergyFatal;
	}
	public void setAllergyFatal(boolean allergyFatal) {
		this.allergyFatal = allergyFatal;
	}
	public boolean isDelFlag() {
		return delFlag;
	}
	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}
	public LocalDate getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}
	public LocalDate getDateUpdated() {
		return dateUpdated;
	}
	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((allergyMasterId == null) ? 0 : allergyMasterId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PatientAllergy other = (PatientAllergy) obj;
		if (allergyMasterId == null) {
			if (other.allergyMasterId != null)
				return false;
		} else if (!allergyMasterId.equals(other.allergyMasterId))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "PatientAllergy [patientAllergyId=" + patientAllergyId + ", allergyMasterId=" + allergyMasterId
				+ ", allergyClinicalInformation=" + allergyClinicalInformation + ", allergyFatal=" + allergyFatal
				+ ", delFlag=" + delFlag + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated
				+ ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + ", allergyName=" + allergyName
				+ ", patient=" + patient + "]";
	}
	public PatientAllergy(Integer patientAllergyId, Integer allergyMasterId, String allergyClinicalInformation,
			boolean allergyFatal, boolean delFlag, LocalDate dateCreated, LocalDate dateUpdated, Integer createdBy,
			Integer updatedBy, String allergyName, Patient patient) {
		super();
		this.patientAllergyId = patientAllergyId;
		this.allergyMasterId = allergyMasterId;
		this.allergyClinicalInformation = allergyClinicalInformation;
		this.allergyFatal = allergyFatal;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
		this.allergyName = allergyName;
		this.patient = patient;
	}
	public PatientAllergy() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
