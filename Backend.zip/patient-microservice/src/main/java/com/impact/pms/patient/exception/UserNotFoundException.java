package com.impact.pms.patient.exception;

public class UserNotFoundException extends RuntimeException 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3031269662099970376L;

	public UserNotFoundException(String message) 
	{
		super(message);
	}
}
