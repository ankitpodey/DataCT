package com.impact.pms.patient.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.impact.pms.patient.dto.PatientDto;
import com.impact.pms.patient.model.Patient;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Integer>{

	@Query(value = "SELECT COUNT(*) "
			+ "FROM "
			+ "useradministration.patient p "
			+ "WHERE "
			+ "p.del_flag = false"
			, nativeQuery = true)
	public Integer fetchPatientUserCount();

	@Query(value = "SELECT * "
			+ "FROM "
			+ "useradministration.patient e "
			+ "WHERE "
			+ "e.user_id = :userId", nativeQuery = true)

	public Optional<Patient> findPatientByUserId(Integer userId);
	
	
	@Query(value = "SELECT p  FROM Patient p WHERE p.delFlag=:delFlag")
	public List<Patient> getMapOfNameOfPatient(boolean delFlag);


			
}
