package com.impact.pms.patient.service;

import java.util.List;
import java.util.Map;

import com.impact.pms.patient.dto.PatientDto;
import com.impact.pms.patient.dto.PatientRegistrationDto;
import com.impact.pms.patient.model.Patient;

public interface PatientService {

	List<Patient> getAllPatients();

	Patient addPatient(PatientRegistrationDto patient);

	PatientDto updatePatient(PatientDto patient);

	PatientDto getPatientById(Integer patientId);

	Integer getPatientUserCount();

	Map<String, Object> getPatietInfoMap(Integer userId);

	Map<Integer, String> getMapOfNameOfPatient();

}
