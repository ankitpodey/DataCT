package com.impact.pms.patient.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.pms.patient.dao.PatientAllergyRespository;

@Service
public class PatientAllergyServiceImpl implements PatientAllergyService {

	@Autowired
	PatientAllergyRespository par;
	
	
	@Transactional
	@Override
	public Integer deleteAllergyByPatientId(Integer patientId) {
		return par.deleteAllergyByPatientId(patientId);
	}

}
