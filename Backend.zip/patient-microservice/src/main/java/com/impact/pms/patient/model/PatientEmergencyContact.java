package com.impact.pms.patient.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "patient_emergency_contact", schema = "useradministration")
@ApiModel(description = "details about PatientEmergencyContact entity")
public class PatientEmergencyContact {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty(notes = "identifier for PatientEmergencyContact entity")
	private Integer patientEmergencyContactId;
	private String firstName;
	private String lastName;
	private String relationship;
	private String emailId;
	private String contactNumber;
	private String addressLineOne;
	private String addressLineTwo;
	private String addressStreet;
	private String addressLandmark;
	private String addressCity;
	private String addressState;
	private String addressCountry;
	private String addressZipCode;
	private boolean portalAccessFlag;
	@CreationTimestamp
	private LocalDate dateCreated;
	private LocalDate dateUpdated;
	private boolean delFlag;
	private Integer createdBy;
	private Integer updatedBy;
	
	
	public PatientEmergencyContact() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PatientEmergencyContact(Integer patientEmergencyContactId, String firstName, String lastName,
			String relationship, String emailId, String contactNumber, String addressLineOne, String addressLineTwo,
			String addressStreet, String addressLandmark, String addressCity, String addressState,
			String addressCountry, String addressZipCode, boolean portalAccessFlag, LocalDate dateCreated,
			LocalDate dateUpdated, boolean delFlag, Integer createdBy, Integer updatedBy) {
		super();
		this.patientEmergencyContactId = patientEmergencyContactId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.relationship = relationship;
		this.emailId = emailId;
		this.contactNumber = contactNumber;
		this.addressLineOne = addressLineOne;
		this.addressLineTwo = addressLineTwo;
		this.addressStreet = addressStreet;
		this.addressLandmark = addressLandmark;
		this.addressCity = addressCity;
		this.addressState = addressState;
		this.addressCountry = addressCountry;
		this.addressZipCode = addressZipCode;
		this.portalAccessFlag = portalAccessFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.delFlag = delFlag;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}



	public Integer getPatientEmergencyContactId() {
		return patientEmergencyContactId;
	}


	public void setPatientEmergencyContactId(Integer patientEmergencyContactId) {
		this.patientEmergencyContactId = patientEmergencyContactId;
	}


	


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getRelationship() {
		return relationship;
	}


	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public String getContactNumber() {
		return contactNumber;
	}


	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}


	public String getAddressLineOne() {
		return addressLineOne;
	}


	public void setAddressLineOne(String addressLineOne) {
		this.addressLineOne = addressLineOne;
	}


	public String getAddressLineTwo() {
		return addressLineTwo;
	}


	public void setAddressLineTwo(String addressLineTwo) {
		this.addressLineTwo = addressLineTwo;
	}


	public String getAddressStreet() {
		return addressStreet;
	}


	public void setAddressStreet(String addressStreet) {
		this.addressStreet = addressStreet;
	}


	public String getAddressLandmark() {
		return addressLandmark;
	}


	public void setAddressLandmark(String addressLandmark) {
		this.addressLandmark = addressLandmark;
	}


	public String getAddressCity() {
		return addressCity;
	}


	public void setAddressCity(String addressCity) {
		this.addressCity = addressCity;
	}


	public String getAddressState() {
		return addressState;
	}


	public void setAddressState(String addressState) {
		this.addressState = addressState;
	}


	public String getAddressCountry() {
		return addressCountry;
	}


	public void setAddressCountry(String addressCountry) {
		this.addressCountry = addressCountry;
	}


	public String getAddressZipCode() {
		return addressZipCode;
	}


	public void setAddressZipCode(String addressZipCode) {
		this.addressZipCode = addressZipCode;
	}


	public boolean isPortalAccessFlag() {
		return portalAccessFlag;
	}


	public void setPortalAccessFlag(boolean portalAccessFlag) {
		this.portalAccessFlag = portalAccessFlag;
	}


	public LocalDate getDateCreated() {
		return dateCreated;
	}


	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}


	public LocalDate getDateUpdated() {
		return dateUpdated;
	}


	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}


	public boolean isDelFlag() {
		return delFlag;
	}


	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}


	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "PatientEmergencyContact [patientEmergencyContactId=" + patientEmergencyContactId + 
				", firstName=" + firstName + ", lastName=" + lastName + ", relationship=" + relationship
				+ ", emailId=" + emailId + ", contactNumber=" + contactNumber + ", addressLineOne=" + addressLineOne
				+ ", addressLineTwo=" + addressLineTwo + ", addressStreet=" + addressStreet + ", addressLandmark="
				+ addressLandmark + ", addressCity=" + addressCity + ", addressState=" + addressState
				+ ", addressCountry=" + addressCountry + ", addressZipCode=" + addressZipCode + ", portalAccessFlag="
				+ portalAccessFlag + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated + ", delFlag="
				+ delFlag + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + "]";
	}
	
	
	
	
}
