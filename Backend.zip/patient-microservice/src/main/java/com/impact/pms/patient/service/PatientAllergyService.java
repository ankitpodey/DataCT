package com.impact.pms.patient.service;

public interface PatientAllergyService {

	Integer deleteAllergyByPatientId(Integer patientId);
}
