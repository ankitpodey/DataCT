package com.impact.pms.patient.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.impact.pms.patient.model.PatientAllergy;

@Repository
public interface PatientAllergyRespository extends JpaRepository<PatientAllergy, Integer> {


	@Modifying
	@Query(value = "DELETE FROM useradministration.patient_allergy p " + 
			"WHERE " +
			"p.patient_id = :patientId", nativeQuery = true)
	Integer deleteAllergyByPatientId(Integer patientId);
}
