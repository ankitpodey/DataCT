package com.training.Zuulapigateway;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@Configuration
@EnableWebSecurity
public class WebSecurity extends WebSecurityConfigurerAdapter {

	private final Environment env;

	@Autowired
	public WebSecurity(Environment env) {
		this.env = env;
	}

	@Bean
	public CorsFilter corsFilter() {

		final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();

		final CorsConfiguration config = new CorsConfiguration();

		config.setAllowCredentials(true);

		config.addAllowedOrigin("*");

		config.addAllowedHeader("*");

		config.addAllowedMethod("OPTIONS");

		config.addAllowedMethod("HEAD");

		config.addAllowedMethod("GET");

		config.addAllowedMethod("PUT");

		config.addAllowedMethod("POST");

		config.addAllowedMethod("DELETE");

		config.addAllowedMethod("PATCH");

		config.addExposedHeader("*");

		source.registerCorsConfiguration("/**", config);

		return new CorsFilter(source);

	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable().cors();
		http.headers().frameOptions().disable();
		http.authorizeRequests().antMatchers(HttpMethod.OPTIONS, "/**").permitAll()
				.antMatchers(HttpMethod.POST, env.getProperty("api.login.uri.path")).permitAll()
				.antMatchers(HttpMethod.GET, env.getProperty("api.master.uri.path")).permitAll()
				.antMatchers(HttpMethod.POST, env.getProperty("api.master.uri.path")).permitAll()
				.antMatchers(HttpMethod.GET, env.getProperty("api.patient.uri.path")).permitAll()
				.antMatchers(HttpMethod.POST, env.getProperty("api.patient.uri.path")).permitAll()
				.antMatchers(HttpMethod.PUT, env.getProperty("api.patient.uri.path")).permitAll()
				.antMatchers(HttpMethod.GET, env.getProperty("api.employee.uri.path")).permitAll()
				.antMatchers(HttpMethod.POST, env.getProperty("api.employee.uri.path")).permitAll()
				.antMatchers(HttpMethod.PUT, env.getProperty("api.employee.uri.path")).permitAll()
				.antMatchers(HttpMethod.GET, env.getProperty("api.user.uri.path")).permitAll()
				.antMatchers(HttpMethod.POST, env.getProperty("api.user.uri.path")).permitAll()
				.antMatchers(HttpMethod.GET, env.getProperty("api.visit.uri.path")).permitAll()
				.antMatchers(HttpMethod.POST, env.getProperty("api.visit.uri.path")).permitAll()
				.antMatchers(HttpMethod.GET, env.getProperty("api.scheduling.uri.path")).permitAll()
				.antMatchers(HttpMethod.POST, env.getProperty("api.scheduling.uri.path")).permitAll()
				.antMatchers(HttpMethod.GET, env.getProperty("api.messaging.uri.path")).permitAll()
				.antMatchers(HttpMethod.PUT, env.getProperty("api.messaging.uri.path")).permitAll()
				.antMatchers(HttpMethod.POST, env.getProperty("api.messaging.uri.path")).permitAll().anyRequest()
				.authenticated().and().addFilter(new AuthorizationFilter(authenticationManager(), env));

		// Disable creating session for user on the server
		http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

	}

}
