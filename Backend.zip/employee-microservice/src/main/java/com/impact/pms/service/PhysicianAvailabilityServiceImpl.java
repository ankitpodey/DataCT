package com.impact.pms.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.pms.dao.PhysicianAvailabilityRepository;
import com.impact.pms.model.PhysicianAvailability;

@Service
public class PhysicianAvailabilityServiceImpl implements PhysicianAvailabilityService {

	@Autowired
	private PhysicianAvailabilityRepository repository;
	
	@Override
	public boolean addPhysicianAvailability(PhysicianAvailability physicianAvailability) {
		boolean result = false;
		try {
			PhysicianAvailability resultPhysicianAvailablity = repository.save(physicianAvailability);
			if(resultPhysicianAvailablity!=null) {
				result = true;
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return result;
	}

	@Override
	public PhysicianAvailability getPhysicianAvailibility(Integer employeeId) {
		Optional<PhysicianAvailability> optionalPhysicianAvailability = repository.findById(employeeId);
		if(optionalPhysicianAvailability.isPresent()) {
			return optionalPhysicianAvailability.get();
		}
		return new PhysicianAvailability();
	}

}
