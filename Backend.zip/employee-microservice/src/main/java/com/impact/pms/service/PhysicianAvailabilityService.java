package com.impact.pms.service;

import com.impact.pms.model.PhysicianAvailability;

public interface PhysicianAvailabilityService {

	boolean addPhysicianAvailability(PhysicianAvailability physicianAvailability);

	PhysicianAvailability getPhysicianAvailibility(Integer employeeId);

}
