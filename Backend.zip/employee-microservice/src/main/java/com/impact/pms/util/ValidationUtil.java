package com.impact.pms.util;

import java.time.LocalDate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationUtil {

	private static boolean checkEmpty(String value) {
		if( value == null ||  value.trim().equalsIgnoreCase("NONE") || 
				value.trim().replaceAll("\\.", "").replaceAll("\\s+", "").equalsIgnoreCase("NA") || value.trim().equalsIgnoreCase("NA") || value.trim().contains("N.A") || value.trim().contains("N.A.") || 
				value.trim().equalsIgnoreCase("NIL") || 
				value.trim().isEmpty()) {
				return true;
		}
		return false;
	}
	
	public static boolean isStringNullOrEmpty(String string) {
		return checkEmpty(string) ? true : false;
	}
	
	public static boolean isPreviousDate(LocalDate date) {
		LocalDate today = LocalDate.now();
		if(date.isBefore(today)) {
			return true;
		}
		return false;
	}
	
	public static boolean isFutureDate(LocalDate date) {
		LocalDate today = LocalDate.now();
		if(date.isAfter(today)) {
			return true;
		}
		return false;
	}
	
	public static boolean isMobNumValid(String s) 
    { 
       Pattern p = Pattern.compile("^[7-9][0-9]{9}$"); 
        Matcher m = p.matcher(s); 
        return (m.find() && m.group().equals(s)); 
    } 
	
	public static boolean isEmailValid(String s) 
    { 
        Pattern p = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$"); 
        Matcher m = p.matcher(s); 
        return (m.find() && m.group().equals(s)); 
    }
	
}
