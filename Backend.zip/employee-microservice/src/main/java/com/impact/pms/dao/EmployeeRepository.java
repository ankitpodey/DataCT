package com.impact.pms.dao;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.impact.pms.model.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

	@Query(value = "SELECT COUNT(*) "
			+ "FROM "
			+ "useradministration.employee e "
			+ "WHERE "
			+ "e.del_flag = false",
			nativeQuery = true)
	public Integer fetchEmployeeUerCount();

	@Query(value = "SELECT e "
			+ "FROM "
			+ "Employee e "
			+ "WHERE "
			+ "e.roleId = :physicianRoleId "
			+ "OR "
			+ "e.roleId = :nurseRoleId "
			+ "AND "
			+ "e.delFlag = :delFlag")
	public List<Employee> fetchAllActivePhysicianAndNurse(Integer physicianRoleId, Integer nurseRoleId, boolean delFlag);

	@Query(value = "SELECT e.reportsTo "
			+ "FROM "
			+ "Employee e "
			+ "WHERE "
			+ "e.employeeId = :employeeId")
	public Integer fetchReportingToPhysicianId(Integer employeeId);


	@Query(value = "SELECT * "
			+ "FROM "
			+ "useradministration.employee e "
			+ "WHERE "
			+ "e.user_id = :userId", nativeQuery = true)
	public Optional<Employee> findEmployeeByUserId(@Param("userId") Integer userId);

	public List<Employee> findAllEmployeesByRoleIdAndDelFlag(Integer roleIdOfPhysician, boolean delFlagFalse);

	@Query(value = "SELECT e "
			+ "FROM "
			+ "Employee e "
			+ "WHERE "
			+ "e.roleId = :roleIdOfNurse "
			+ "OR "
			+ "e.roleId = :roleIdOfPhysician")
	public List<Employee> findAllEmployeesByRoleId(Integer roleIdOfNurse, Integer roleIdOfPhysician);

}
