package com.impact.pms.service;

import java.util.List;
import java.util.Map;

import com.impact.pms.dto.EmployeeDto;
import com.impact.pms.model.Employee;

public interface EmployeeService {

	List<Employee> getAllEmployees();

	EmployeeDto addEmployeeByAdmin(EmployeeDto employee);
	
	EmployeeDto updateEmployeeByAdmin(EmployeeDto employee);
	
	EmployeeDto getEmployeeByAdmin(Integer employeeId);
	
	Integer getEmployeeUserCount();
	
	EmployeeDto updateEmployee(EmployeeDto employee);

	Employee getEmployee(Integer employeeId);
	
	Map<Integer, String> getMapOfPhyAndNurseForChat();

	Integer getReportingToPhysicianId(Integer employeeId);

	Map<String, Object> getEmployeeInfoMap(Integer userId);

	Map<Integer, String> getPhysicianMap();

}
