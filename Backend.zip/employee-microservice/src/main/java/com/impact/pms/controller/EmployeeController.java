package com.impact.pms.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.impact.pms.dto.EmployeeDto;
import com.impact.pms.dto.ResponseMessageDto;
import com.impact.pms.model.Employee;
import com.impact.pms.service.EmployeeService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/employee")
@PropertySource("classpath:response-message.properties")
public class EmployeeController {
	
	private static final Logger log = LoggerFactory.getLogger(EmployeeController.class);

	@Autowired
	private EmployeeService service;
	
	@Autowired
	private Environment env;
	
	/**
	 * Endpoint to fetch list of all Employees
	 * @return
	 */
	@GetMapping("/fetch-all")
	 @ApiOperation(value = "To Fetch List of all Employees",notes = "To Fetch List of all Employees")
	public ResponseEntity<List<Employee>> getAllEmployees()
	{
		List<Employee> employeeList = service.getAllEmployees();
		return ResponseEntity.ok(employeeList);
		
	}
	
	
	/**
	 * Endpoint to Add/Register Employee
	 * Endpoint will be accessible only to Admin
	 * @param employee
	 * @return
	 */
	//check if we need to add the availability time slot also using this endpoint
	@PostMapping("/admin")
	 @ApiOperation(value = "Add/Register Employee",notes = "To Add/Register Employee ,will be accessible only to Admin")
	public ResponseEntity<ResponseMessageDto> addEmployeeByAdmin( @ApiParam(value = "To Add/Register Employee ,will be accessible only to Admin by applying POST method",required = true)
			@RequestBody EmployeeDto employee) {
		System.err.println(employee.getReportsTo());	
		EmployeeDto resultEmployeeDto = service.addEmployeeByAdmin(employee);
		if(null!=resultEmployeeDto) 
			return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("employee.registration.success"), true));
		return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("employee.registration.fail"), false));
		
	}
	
	@PutMapping("/admin")
	 @ApiOperation(value = "To Update Employee By Admin",notes = "To  Update Employee By Admin by applying PUT method")
	public ResponseEntity<EmployeeDto> updateEmployeeByAdmin( @ApiParam(value = "To  Update Employee By Admin by applying PUT method",required = true)
			@RequestBody EmployeeDto employee) {
		EmployeeDto resultEmployeeDto = service.updateEmployeeByAdmin(employee);
		return ResponseEntity.ok(resultEmployeeDto);
	}
	
	@GetMapping("/admin/{empId}")
	 @ApiOperation(value = "To fetch Employee By Admin ",notes = "To fetch Employee By Admin GET method")
	public ResponseEntity<EmployeeDto> getEmployeeByAdmin( @ApiParam(value = "To fetch Employee By Admin GET method",required = true)
			@PathVariable("empId") Integer employeeId) {
		EmployeeDto resultEmployeeDto = service.getEmployeeByAdmin(employeeId);
		return ResponseEntity.ok(resultEmployeeDto);
	}
	
	
	
	
	
	/**
	 * Endpoint to get active employee user count
	 * Endpoint to show active Employees in Admin dashboard
	 * @return
	 */
	@GetMapping("/employee-user-count")
	 @ApiOperation(value = "To Fetch active employee user count ",notes = "To show active Employees in Admin dashboard by applying GET method")
	public ResponseEntity<Integer> getEmployeeUserCount() {
		Integer empUserCount = service.getEmployeeUserCount();
		return ResponseEntity.ok(empUserCount);
	}
	
	/**
	 * Endpoint to update employee profile
	 * Endpoint will be accessible to physician and nurse
	 * @param employee
	 * @return
	 */
	@PutMapping("/")
	 @ApiOperation(value = "To  update employee profile",notes = " will be accessible to physician and nurse")
	public EmployeeDto updateEmployee( @ApiParam(value = "To update employee profile by applying PUT method",required = true)
			@RequestBody EmployeeDto employee) {
		return service.updateEmployee(employee);
	}
	
	/**
	 * Endpoint to get Employee details using employee id
	 * Endpoint will be accessible to physician and nurse
	 * @param employeeId
	 * @return
	 */
	@GetMapping("/{employeeId}")
	 @ApiOperation(value = "To get Employee details using employee id",notes = "Will be accessible to physician and nurse by applying GET method")
	public Employee getEmployee( @ApiParam(value = "To get Employee details using employee id by applying GET method",required = true)
			@PathVariable Integer employeeId) {
		return service.getEmployee(employeeId);
	}
	
	/**
	 * Endpoint to get list of all Employees(Physician and Nurse), for purpose of sending message
	 * @return
	 */
	@GetMapping("/getall-phy-nurse-map")
	 @ApiOperation(value = "To get list of all Employees",notes = "To get list of all Employees by applying GET method")
	public ResponseEntity<Map<Integer, String>> getMapOfPhyAndNurseForChat(){
		log.info("in Employee Controller -> getMapOfPhyAndNurseForChat()");
		Map<Integer, String> phyNurseMap = service.getMapOfPhyAndNurseForChat();
		return ResponseEntity.ok(phyNurseMap);
	}
	
	/**
	 * Endpoint to get the emmployeeId of physician to whom the nurse is reporting to
	 * @param employeeId
	 * @return
	 */
	@GetMapping("/get-report-to-phyid/{empId}")
	 @ApiOperation(value = "To  get the emmployeeId of physician to whom the nurse is reporting to",notes = "To get the emmployeeId of physician to whom the nurse is reporting to by applying GET method")
	public ResponseEntity<Integer> getReportingToPhysicianId( @ApiParam(value = "To get the emmployeeId of physician to whom the nurse is reporting to by applying GET method",required = true)
			@PathVariable("empId") Integer employeeId){
		log.info("in Employee Controller -> getReportingToPhysicianId() -> "+employeeId);
		Integer phyEmpId = service.getReportingToPhysicianId(employeeId);
		return ResponseEntity.ok(phyEmpId);
	}
	
	/**
	 * Endpoint to get the Employee Info Map
	 * @param userId
	 * @return
	 */
	@GetMapping("/get-employee-info-map/{userId}")
	 @ApiOperation(value = "To get Employee Info",notes = "To get Employee Info by applying GET method")
	public ResponseEntity<Map<String, Object>> getEmployeeInfoMap( @ApiParam(value = "To get Employee Info by applying GET method",required = true)
			@PathVariable Integer userId){
		Map<String,Object> employeeInfoMap = service.getEmployeeInfoMap(userId); 
		return ResponseEntity.ok(employeeInfoMap);
	}
	
	/**
	 * Endpoint to fetch Map of all active physician
	 * @return
	 */
	@GetMapping("/get-physician-map")
	@ApiOperation(value = "To get Physician map", notes = "to get active physician map by applying for get method")
	public ResponseEntity<Map<Integer, String>> getPhysicianMap(){
		Map<Integer, String> phyMap = service .getPhysicianMap();
		return ResponseEntity.ok(phyMap);
	}
}
