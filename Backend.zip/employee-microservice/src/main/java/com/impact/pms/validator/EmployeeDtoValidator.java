package com.impact.pms.validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.impact.pms.constants.ApplicationConstants.Roles;
import com.impact.pms.dto.EmployeeDto;
import com.impact.pms.util.ValidationUtil;


@Qualifier("employeeDtoValidator")
@Component
public class EmployeeDtoValidator implements Validator {

	private final static Logger log = LoggerFactory.getLogger(EmployeeDtoValidator.class);
	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return EmployeeDtoValidator.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {

		log.info("Validating EmployeeDto object "+ target);

		EmployeeDto employee = (EmployeeDto) target;
		
		//mandatory fields
		
		if(ValidationUtil.isStringNullOrEmpty(employee.getTitle())) {
			errors.rejectValue("title", "EmployeeDtoValidator.title.invalid");
		}

		if(ValidationUtil.isStringNullOrEmpty(employee.getFirstName())) {
			errors.rejectValue("firstName", "EmployeeDtoValidator.firstName.empty");
		} 

		if(!isNameLengthValid(employee.getFirstName())) {
			errors.rejectValue("firstName", "EmployeeDtoValidator.firstName.length.invalid");
		}

		if(ValidationUtil.isStringNullOrEmpty(employee.getLastName())) {
			errors.rejectValue("lastName", "EmployeeDtoValidator.lastName.empty");
		} 

		if(!isNameLengthValid(employee.getLastName())) {
			errors.rejectValue("lastName", "EmployeeDtoValidator.lastName.length.invalid");
		}
		
		if(!ValidationUtil.isEmailValid(employee.getEmailId())) {
			errors.rejectValue("emailId", "EmployeeDtoValidator.emailId.invalid");
		}
		
		//application constants
		if(employee.getRoleId()!=Roles.ROLE_ID_OF_NURSE && employee.getRoleId()!=Roles.ROLE_ID_OF_PHYSICIAN) {
			errors.rejectValue("roleId", "EmployeeDtoValidator.roleId.invalid");
		}
		
		if(employee.getRoleId()==Roles.ROLE_ID_OF_NURSE) {
			if(employee.getReportsTo()==null) {
				errors.rejectValue("roleId", "EmployeeDtoValidator.reportsTo.empty");
			}
		}


		//optional fields
		if(employee.getDateOfBirth()!=null) {
			if(!ValidationUtil.isPreviousDate(employee.getDateOfBirth())) {
				errors.rejectValue("dateOfBirth", "EmployeeDtoValidator.dateOfBirth.invalid");
			}
		}
		
		if(employee.getContactNumber()!=null || !employee.getContactNumber().equals("")) {
			if(!ValidationUtil.isMobNumValid(employee.getContactNumber())) {
				errors.rejectValue("contactNumber", "EmployeeDtoValidator.contactNumber.invalid");
			}
		}
		
	


	}

	private boolean isNameLengthValid(String name) {
		if(name.length()>2 && name.length()<21) {
			return true;
		}
		return false;
	}

}
