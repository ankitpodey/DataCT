package com.impact.pms.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.impact.pms.client.MessagingFeignClient;
import com.impact.pms.constants.ApplicationConstants;
import com.impact.pms.constants.ApplicationConstants.Roles;
import com.impact.pms.dao.EmployeeRepository;
import com.impact.pms.dto.EmailDto;
import com.impact.pms.dto.EmployeeDto;
import com.impact.pms.exception.UserNotFoundException;
import com.impact.pms.model.Employee;
import com.impact.pms.model.PhysicianAvailability;
import com.impact.pms.model.User;
import com.impact.pms.util.GeneratePassword;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepository repository;

	@Autowired
	private PhysicianAvailabilityService phyAvailabilityService;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private MessagingFeignClient msgClient;

	@Override
	public List<Employee> getAllEmployees() {
		return repository.findAllEmployeesByRoleId(Roles.ROLE_ID_OF_NURSE, Roles.ROLE_ID_OF_PHYSICIAN);
	}

	/**
	 * Method to add employee, by admin
	 */
	@Override
	public EmployeeDto addEmployeeByAdmin(EmployeeDto employeeDto) {
		EmployeeDto resultEmployeeDto = new EmployeeDto();
		//populate user entity
		User user = new User();
		BeanUtils.copyProperties(employeeDto, user);
		String defaultPassword = GeneratePassword.generateDefaultPassword(8);
		String encPassword = bCryptPasswordEncoder.encode(defaultPassword);
		user.setPassword(encPassword);
		user.setActive(true);

		//populate employee entity
		Employee employee = new Employee();
		BeanUtils.copyProperties(employeeDto, employee);
		employee.setUser(user);

		System.err.println("employrr --->  "+employee);
		//persist employee
		Employee employeeRes = repository.save(employee);
		if(employeeRes!=null) {
			//send mail to employee with default password
			EmailDto emailDto = new EmailDto();
			emailDto.setReciverEmailId(user.getEmailId());
			emailDto.setMessageBody("Your password is: " + defaultPassword + " .Please login using this password.");
			emailDto.setMessageBody("Employee registration successful");
			msgClient.send(emailDto);
			
		}

		//persist employee availability slots if emp role is physician
		if(employeeRes.getRoleId()==Roles.ROLE_ID_OF_PHYSICIAN) {
			//populate physician availability entity
			PhysicianAvailability physicianAvailability = new PhysicianAvailability();
			BeanUtils.copyProperties(employeeDto.getPhysicianAvailability(), physicianAvailability);
			//set generated Employee Id
			physicianAvailability.setEmployeeId(employeeRes.getEmployeeId());

			//persist data
			phyAvailabilityService.addPhysicianAvailability(physicianAvailability);

			//set the saved time slot back in return object
			resultEmployeeDto.setPhysicianAvailability(physicianAvailability);
		}

		//copy back the persisted data to emp dto
		BeanUtils.copyProperties(employeeRes, resultEmployeeDto);
		return resultEmployeeDto;
	}

	/**
	 *Method to update employee by admin
	 */
	@Override
	public EmployeeDto updateEmployeeByAdmin(EmployeeDto empDto) {
		EmployeeDto resultEmployeeDto = new EmployeeDto();
		Employee emp = new Employee();
		//populate data in to Employee object
		BeanUtils.copyProperties(empDto, emp);
		//fetch and set employee data
		Optional<Employee> optionalEmp = repository.findById(empDto.getEmployeeId());
		Employee existingEmp = optionalEmp.get();

		BeanUtils.copyProperties(existingEmp, emp);
		//persist
		emp = repository.save(emp);

		//update physician availability, if role is physician
		if(emp.getRoleId()==Roles.ROLE_ID_OF_PHYSICIAN) {
			//populate physician availability entity
			PhysicianAvailability physicianAvailability = new PhysicianAvailability();
			BeanUtils.copyProperties(empDto.getPhysicianAvailability(), physicianAvailability);
			
			//persist data
			phyAvailabilityService.addPhysicianAvailability(physicianAvailability);

			//set the saved time slot back in return object
			resultEmployeeDto.setPhysicianAvailability(physicianAvailability);
		}
		BeanUtils.copyProperties(emp, resultEmployeeDto);
		return resultEmployeeDto;
	}

	/**
	 *Method to fetch employee details for Admin
	 */
	@Override
	public EmployeeDto getEmployeeByAdmin(Integer employeeId) {
		EmployeeDto empDto = new EmployeeDto();
		Optional<Employee> optionalEmpDto = repository.findById(employeeId);
		if(optionalEmpDto.isPresent()) {
			BeanUtils.copyProperties(optionalEmpDto.get(), empDto);
		}

		//fetch physician availability if role is physician
		if(empDto.getRoleId()==Roles.ROLE_ID_OF_PHYSICIAN) {
			PhysicianAvailability physicianAvailability = new PhysicianAvailability();
			physicianAvailability = phyAvailabilityService.getPhysicianAvailibility(employeeId);

			//set in EMP DTO
			empDto.setPhysicianAvailability(physicianAvailability);
		}

		return empDto;
	}



	@Override
	public Integer getEmployeeUserCount() {
		return repository.fetchEmployeeUerCount();
	}

	@Override
	public EmployeeDto updateEmployee(EmployeeDto employeeDto) {
		Employee employee = new Employee();
		BeanUtils.copyProperties(employeeDto, employee);
		
		 Optional<Employee> currEmployee = repository.findById(employeeDto.getEmployeeId());
		 employee.setUser(currEmployee.get().getUser());
		 employee.setRoleId(currEmployee.get().getRoleId());
		 employee.setSpecialityMasterId(currEmployee.get().getSpecialityMasterId());

		Employee employeeRes = repository.save(employee);
		BeanUtils.copyProperties(employeeRes, employeeDto);
		return employeeDto;
	}

	@Override
	public Employee getEmployee(Integer employeeId) {
		Optional<Employee> employee = repository.findById(employeeId);
		if(employee.isPresent()) {
			return employee.get();
		}
		throw new UserNotFoundException("Employee not found");
	}
	
	@Override
	public Map<Integer, String> getMapOfPhyAndNurseForChat() {
		List<Employee> employeeList = repository.fetchAllActivePhysicianAndNurse(Roles.ROLE_ID_OF_NURSE, Roles.ROLE_ID_OF_PHYSICIAN, ApplicationConstants.DEL_FLAG_FALSE);
		Map<Integer, String> empMap = new HashMap<Integer, String>();
		if(employeeList.size()!=0) {
			for(Employee emp : employeeList) {
				empMap.put(emp.getEmployeeId(), emp.getFirstName() + " " + emp.getLastName());
			}
		}
		return empMap;
	}

	@Override
	public Integer getReportingToPhysicianId(Integer employeeId) {
		Integer physicianEmpId =  repository.fetchReportingToPhysicianId(employeeId);
		return physicianEmpId;
	}

	@Override
	public Map<String, Object> getEmployeeInfoMap(Integer userId) {
		Employee employee = new Employee();
		Optional<Employee> optionalEmployee = repository.findEmployeeByUserId(userId);
		employee = optionalEmployee.get();
		Map<String, Object> employeeInfoMap = new HashMap<String, Object>();
		employeeInfoMap.put("name", employee.getFirstName()+ " "+ employee.getLastName());
		employeeInfoMap.put("employeeId", employee.getEmployeeId());
		return employeeInfoMap;
	}

	@Override
	public Map<Integer, String> getPhysicianMap() {
		Map<Integer, String> phyMap = new HashMap<Integer, String>();
		List<Employee> phyList = repository.findAllEmployeesByRoleIdAndDelFlag(Roles.ROLE_ID_OF_PHYSICIAN, ApplicationConstants.DEL_FLAG_FALSE);
		for(Employee phy : phyList) {
			phyMap.put(phy.getEmployeeId(), phy.getFirstName() + " " + phy.getLastName());
		}
		
		return phyMap;
	}


}
