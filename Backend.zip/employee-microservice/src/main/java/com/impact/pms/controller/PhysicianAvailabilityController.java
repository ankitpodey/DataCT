package com.impact.pms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.impact.pms.model.PhysicianAvailability;
import com.impact.pms.service.PhysicianAvailabilityService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("physician-availability")
public class PhysicianAvailabilityController {

	@Autowired
	private PhysicianAvailabilityService service;

	@PostMapping
	 @ApiOperation(value = "To add Physician Availability",notes = "To add Physician Availability by applying POST method")
	public ResponseEntity<Boolean> addPhysicianAvailability( @ApiParam(value = "To add Physician Availability by applying POST method",required = true)
			@RequestBody PhysicianAvailability physicianAvailability) {
		boolean result = service.addPhysicianAvailability(physicianAvailability);
		return ResponseEntity.ok(result);
	}

	@GetMapping("/{empId}")
	 @ApiOperation(value = "To get Physician Availability",notes = "To get Physician Availability by applying GET method")
	public ResponseEntity<PhysicianAvailability> getPhysicianAvailability( @ApiParam(value = "To get Physician Availability by applying GET method",required = true)
			@PathVariable("empId") Integer employeeId){
		PhysicianAvailability physicianAvailability = service.getPhysicianAvailibility(employeeId);
		return ResponseEntity.ok(physicianAvailability);
	}

}
