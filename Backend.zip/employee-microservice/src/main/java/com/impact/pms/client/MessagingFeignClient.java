package com.impact.pms.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.impact.pms.dto.EmailDto;


@FeignClient("messaging-ms")
public interface MessagingFeignClient {

	@PostMapping(value = "/messaging/sendemail")
	public ResponseEntity<Boolean> send(@RequestBody EmailDto emailDto);
}
