package com.impact.pms.model;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(schema = "useradministration", name = "physician_availability")
@ApiModel(description = "Details about the PhysicianAvailability")
public class PhysicianAvailability {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty(notes="The unique id of the PhysicianAvailability")
	private Integer physicianAvailabilityId;
	private Integer employeeId;
	private LocalTime mondayFrom;
	private LocalTime mondayTo;
	private LocalTime tuesdayFrom;
	private LocalTime tuesdayTo;
	private LocalTime wednesdayFrom;
	private LocalTime wednesdayTo;
	private LocalTime thursdayFrom;
	private LocalTime thursdayTo;
	private LocalTime fridayFrom;
	private LocalTime fridayTo;
	private LocalTime saturdayFrom;
	private LocalTime saturdayTo;
	private LocalTime sundayFrom;
	private LocalTime sundayTo;
	private boolean delFlag;
	@CreationTimestamp
	private LocalDate dateCreated;
	@UpdateTimestamp
	private LocalDate dateUpdated;
	private Integer createdBy;
	private Integer updatedBy;

	public PhysicianAvailability() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public PhysicianAvailability(Integer physicianAvailabilityId, Integer employeeId, LocalTime mondayFrom,
			LocalTime mondayTo, LocalTime tuesdayFrom, LocalTime tuesdayTo, LocalTime wednesdayFrom,
			LocalTime wednesdayTo, LocalTime thursdayFrom, LocalTime thursdayTo, LocalTime fridayFrom,
			LocalTime fridayTo, LocalTime saturdayFrom, LocalTime saturdayTo, LocalTime sundayFrom, LocalTime sundayTo,
			boolean delFlag, LocalDate dateCreated, LocalDate dateUpdated, Integer createdBy, Integer updatedBy) {
		super();
		this.physicianAvailabilityId = physicianAvailabilityId;
		this.employeeId = employeeId;
		this.mondayFrom = mondayFrom;
		this.mondayTo = mondayTo;
		this.tuesdayFrom = tuesdayFrom;
		this.tuesdayTo = tuesdayTo;
		this.wednesdayFrom = wednesdayFrom;
		this.wednesdayTo = wednesdayTo;
		this.thursdayFrom = thursdayFrom;
		this.thursdayTo = thursdayTo;
		this.fridayFrom = fridayFrom;
		this.fridayTo = fridayTo;
		this.saturdayFrom = saturdayFrom;
		this.saturdayTo = saturdayTo;
		this.sundayFrom = sundayFrom;
		this.sundayTo = sundayTo;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}
	
	

	public Integer getPhysicianAvailabilityId() {
		return physicianAvailabilityId;
	}

	public void setPhysicianAvailabilityId(Integer physicianAvailabilityId) {
		this.physicianAvailabilityId = physicianAvailabilityId;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public LocalTime getMondayFrom() {
		return mondayFrom;
	}

	public void setMondayFrom(LocalTime mondayFrom) {
		this.mondayFrom = mondayFrom;
	}

	public LocalTime getMondayTo() {
		return mondayTo;
	}

	public void setMondayTo(LocalTime mondayTo) {
		this.mondayTo = mondayTo;
	}

	public LocalTime getTuesdayFrom() {
		return tuesdayFrom;
	}

	public void setTuesdayFrom(LocalTime tuesdayFrom) {
		this.tuesdayFrom = tuesdayFrom;
	}

	public LocalTime getTuesdayTo() {
		return tuesdayTo;
	}

	public void setTuesdayTo(LocalTime tuesdayTo) {
		this.tuesdayTo = tuesdayTo;
	}

	public LocalTime getWednesdayFrom() {
		return wednesdayFrom;
	}

	public void setWednesdayFrom(LocalTime wednesdayFrom) {
		this.wednesdayFrom = wednesdayFrom;
	}

	public LocalTime getWednesdayTo() {
		return wednesdayTo;
	}

	public void setWednesdayTo(LocalTime wednesdayTo) {
		this.wednesdayTo = wednesdayTo;
	}

	public LocalTime getThursdayFrom() {
		return thursdayFrom;
	}

	public void setThursdayFrom(LocalTime thursdayFrom) {
		this.thursdayFrom = thursdayFrom;
	}

	public LocalTime getThursdayTo() {
		return thursdayTo;
	}

	public void setThursdayTo(LocalTime thursdayTo) {
		this.thursdayTo = thursdayTo;
	}

	public LocalTime getFridayFrom() {
		return fridayFrom;
	}

	public void setFridayFrom(LocalTime fridayFrom) {
		this.fridayFrom = fridayFrom;
	}

	public LocalTime getFridayTo() {
		return fridayTo;
	}

	public void setFridayTo(LocalTime fridayTo) {
		this.fridayTo = fridayTo;
	}

	public LocalTime getSaturdayFrom() {
		return saturdayFrom;
	}

	public void setSaturdayFrom(LocalTime saturdayFrom) {
		this.saturdayFrom = saturdayFrom;
	}

	public LocalTime getSaturdayTo() {
		return saturdayTo;
	}

	public void setSaturdayTo(LocalTime saturdayTo) {
		this.saturdayTo = saturdayTo;
	}

	public LocalTime getSundayFrom() {
		return sundayFrom;
	}

	public void setSundayFrom(LocalTime sundayFrom) {
		this.sundayFrom = sundayFrom;
	}

	public LocalTime getSundayTo() {
		return sundayTo;
	}

	public void setSundayTo(LocalTime sundayTo) {
		this.sundayTo = sundayTo;
	}

	public boolean isDelFlag() {
		return delFlag;
	}
	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}
	public LocalDate getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}
	public LocalDate getDateUpdated() {
		return dateUpdated;
	}
	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}
	@Override
	public String toString() {
		return "PhysicianAvailability [physicianAvailabilityId=" + physicianAvailabilityId + ", employeeId="
				+ employeeId + ", mondayFrom=" + mondayFrom + ", mondayTo=" + mondayTo + ", tuesdayFrom=" + tuesdayFrom
				+ ", tuesdayTo=" + tuesdayTo + ", wednesdayFrom=" + wednesdayFrom + ", wednesdayTo=" + wednesdayTo
				+ ", thursdayFrom=" + thursdayFrom + ", thursdayTo=" + thursdayTo + ", fridayFrom=" + fridayFrom
				+ ", fridayTo=" + fridayTo + ", saturdayFrom=" + saturdayFrom + ", saturdayTo=" + saturdayTo
				+ ", sundayFrom=" + sundayFrom + ", sundayTo=" + sundayTo + ", delFlag=" + delFlag + ", dateCreated="
				+ dateCreated + ", dateUpdated=" + dateUpdated + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy
				+ "]";
	}


}
