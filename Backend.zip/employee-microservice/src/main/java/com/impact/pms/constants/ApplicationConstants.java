package com.impact.pms.constants;

public class ApplicationConstants {

	
	//ROLE CONSTANTS	
	public static class Roles
	{
		public Roles() {
			
		}
	public static final Integer ROLE_ID_OF_ADMIN=1;
	public static final Integer ROLE_ID_OF_PHYSICIAN=2;
	public static final Integer ROLE_ID_OF_NURSE=3;
	public static final Integer ROLE_ID_OF_PATIENT=4;
	}
	
	public static final boolean DEL_FLAG_FALSE = false;
	public static final boolean DEL_FLAG_TRUE = true;
}
