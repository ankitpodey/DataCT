package com.impact.pms.master.MasterData.service;

import java.util.List;
import java.util.Map;

import com.impact.pms.master.MasterData.dto.DiagnosisMasterDto;

/**
 * @author LaveenaS
 * Service class to define methods of DiagnosisMaster service layer.
 *
 */
public interface DiagnosisMasterService {

	List<DiagnosisMasterDto> fetchDiagnosisMasterTableDetails();

	Map<Integer, DiagnosisMasterDto> fetchDiagnosisMasterTableMapDetails();

}
