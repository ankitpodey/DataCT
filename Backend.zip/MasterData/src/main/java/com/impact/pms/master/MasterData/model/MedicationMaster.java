package com.impact.pms.master.MasterData.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Model class for Medication_Master Table
 */
@Entity
@Table(name = "medication_master")
@ApiModel
public class MedicationMaster implements Serializable {
	
	/**
	 * Added generated serial version ID
	 */
	private static final long serialVersionUID = 2740235195071185491L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty
	private Integer medicationMasterId;

	private String medicationId;

	private String medicationName;

	private String medicationGenericName;

	private String medicationManufacturerName;

	private String medicationForm;

	private String medicationStrength;

	private boolean delFlag;

	@CreationTimestamp
	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;

	public MedicationMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MedicationMaster(Integer medicationMasterId, String medicationId, String medicationName,
			String medicationGenericName, String medicationManufacturerName, String medicationForm,
			String medicationStrength, boolean delFlag, LocalDate dateCreated, LocalDate dateUpdated,
			Integer createdBy, Integer updatedBy) {
		super();
		this.medicationMasterId = medicationMasterId;
		this.medicationId = medicationId;
		this.medicationName = medicationName;
		this.medicationGenericName = medicationGenericName;
		this.medicationManufacturerName = medicationManufacturerName;
		this.medicationForm = medicationForm;
		this.medicationStrength = medicationStrength;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "MedicationMaster [medicationMasterId=" + medicationMasterId + ", medicationId=" + medicationId
				+ ", medicationName=" + medicationName + ", medicationGenericName=" + medicationGenericName
				+ ", medicationManufacturerName=" + medicationManufacturerName + ", medicationForm=" + medicationForm
				+ ", medicationStrength=" + medicationStrength + ", delFlag=" + delFlag + ", dateCreated=" + dateCreated
				+ ", dateUpdated=" + dateUpdated + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + "]";
	}

	/**
	 * @return the medicationMasterId
	 */
	public Integer getMedicationMasterId() {
		return medicationMasterId;
	}

	/**
	 * @param medicationMasterId the medicationMasterId to set
	 */
	public void setMedicationMasterId(Integer medicationMasterId) {
		this.medicationMasterId = medicationMasterId;
	}

	/**
	 * @return the medicationId
	 */
	public String getMedicationId() {
		return medicationId;
	}

	/**
	 * @param medicationId the medicationId to set
	 */
	public void setMedicationId(String medicationId) {
		this.medicationId = medicationId;
	}

	/**
	 * @return the medicationName
	 */
	public String getMedicationName() {
		return medicationName;
	}

	/**
	 * @param medicationName the medicationName to set
	 */
	public void setMedicationName(String medicationName) {
		this.medicationName = medicationName;
	}

	/**
	 * @return the medicationGenericName
	 */
	public String getMedicationGenericName() {
		return medicationGenericName;
	}

	/**
	 * @param medicationGenericName the medicationGenericName to set
	 */
	public void setMedicationGenericName(String medicationGenericName) {
		this.medicationGenericName = medicationGenericName;
	}

	/**
	 * @return the medicationManufacturerName
	 */
	public String getMedicationManufacturerName() {
		return medicationManufacturerName;
	}

	/**
	 * @param medicationManufacturerName the medicationManufacturerName to set
	 */
	public void setMedicationManufacturerName(String medicationManufacturerName) {
		this.medicationManufacturerName = medicationManufacturerName;
	}

	/**
	 * @return the medicationForm
	 */
	public String getMedicationForm() {
		return medicationForm;
	}

	/**
	 * @param medicationForm the medicationForm to set
	 */
	public void setMedicationForm(String medicationForm) {
		this.medicationForm = medicationForm;
	}

	/**
	 * @return the medicationStrength
	 */
	public String getMedicationStrength() {
		return medicationStrength;
	}

	/**
	 * @param medicationStrength the medicationStrength to set
	 */
	public void setMedicationStrength(String medicationStrength) {
		this.medicationStrength = medicationStrength;
	}

	/**
	 * @return the delFlag
	 */
	public boolean isDelFlag() {
		return delFlag;
	}

	/**
	 * @param delFlag the delFlag to set
	 */
	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	/**
	 * @return the dateCreated
	 */
	public LocalDate getDateCreated() {
		return dateCreated;
	}

	/**
	 * @param dateCreated the dateCreated to set
	 */
	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	/**
	 * @return the dateUpdated
	 */
	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	/**
	 * @param dateUpdated the dateUpdated to set
	 */
	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	/**
	 * @return the createdBy
	 */
	public Integer getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedBy
	 */
	public Integer getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}
	
}
