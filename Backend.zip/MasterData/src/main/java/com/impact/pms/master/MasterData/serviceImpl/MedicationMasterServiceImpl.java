package com.impact.pms.master.MasterData.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.pms.master.MasterData.dto.MedicationMasterDto;
import com.impact.pms.master.MasterData.model.MedicationMaster;
import com.impact.pms.master.MasterData.repository.MedicationMasterRepository;
import com.impact.pms.master.MasterData.service.MedicationMasterService;

/**
 * @author LaveenaS
 * 
 *         Service class to call repository method to read medication master
 *         table contents
 *
 */
@Service
public class MedicationMasterServiceImpl  implements MedicationMasterService {

	private final static Logger logger = LoggerFactory.getLogger(MedicationMasterServiceImpl.class);

	@Autowired
	private MedicationMasterRepository medicationMasterRepository;

	/**
	 * @return MedicationMasterDto that contains data sent to front-end for
	 *         displaying in data table. This method calls repository method
	 *         (findAll) for reading all contents and filters records that are
	 *         active in the table.
	 *
	 */
	@Override
	public List<MedicationMasterDto> fetchMedicationMasterTableDetails() {

		logger.info("Inside MedicationMasterServiceImpl fetchMedicationMasterTableDetails method");

		List<MedicationMasterDto> medicationMasterDtoList = new ArrayList<>();
		List<MedicationMaster> filteredMedicationMasterList = new ArrayList<>();
		List<MedicationMaster> medicationMasterList = medicationMasterRepository.findAll();

		// Stream API + filter method to get only active records from table
		filteredMedicationMasterList = medicationMasterList.stream()
				.filter(medicationMasterRecord -> medicationMasterRecord.isDelFlag() == false)
				.collect(Collectors.toList());

		// Copying properties from filtered records to Dto object
		filteredMedicationMasterList.forEach(medicationMasterRecord -> {
			MedicationMasterDto medicationMasterDto = new MedicationMasterDto();
			BeanUtils.copyProperties(medicationMasterRecord, medicationMasterDto);
			medicationMasterDtoList.add(medicationMasterDto);
		});

		logger.info("Total number of active records in Medication_Master table : " + medicationMasterDtoList.size());
		return medicationMasterDtoList;
	}

	/**
	 * @return Map<Integer, MedicationMasterDto> that contains data sent to visit-ms
	 * for patient past visit endpoint
	 * 
	 *
	 */
	@Override
	public Map<Integer, MedicationMasterDto> fetchMedicationMasterTableMapDetails() {
		
		logger.info("Inside MedicationMasterServiceImpl fetcMedicationMasterTableMapDetails method");
		
		Map<Integer, MedicationMasterDto> medicationMasterMap = new HashMap<>();
		List<MedicationMasterDto> medicationMasterDtoList = new ArrayList<>();
		
		medicationMasterDtoList = fetchMedicationMasterTableDetails();
		for (MedicationMasterDto medicationMasterDto : medicationMasterDtoList) {
			medicationMasterMap.put(medicationMasterDto.getMedicationMasterId(), medicationMasterDto);
		}
		
		logger.info("Total number of active records in Medication_Master table : " + medicationMasterMap.size());
		
		return medicationMasterMap;
	}

}