package com.impact.pms.master.MasterData.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.impact.pms.master.MasterData.dto.RoleMasterDto;
import com.impact.pms.master.MasterData.service.RoleMasterService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * @author LaveenaS
 * 
 *         This is a controller class that makes a call to service. URLs are
 *         mapped as /master as this is a master application and makes call to
 *         master schema tables through service layer.
 *
 */
@RestController
@RequestMapping("/master/role")
public class RoleMasterController {
	
	@Autowired
	private RoleMasterService roleMasterService;

	private final static Logger logger = LoggerFactory.getLogger(RoleMasterController.class);

	/**
	 * @author LaveenaS 
	 * 
	 * This method makes a get request to service layer to fetch only required
	 *         speciality master table columns.
	 * @return ResponseEntity<Map<Integer, String>>  returns response status as
	 *         OK if all goes well.
	 *
	 */
	@GetMapping("/fetch-role-master-map-details")
	@ApiOperation(value = "to fetch only required role master table details")
	public ResponseEntity<Map<Integer, String>> fetchRoleMasterMapTableDetails() {

		Map<Integer, String> roleMasterMap = new HashMap<>();

		logger.info("Inside fetchRoleMasterMapTableDetails method ");

		roleMasterMap = roleMasterService.fetchRoleMasterMapTableDetails();

		return ResponseEntity.ok(roleMasterMap);

	}
	
	/**
	 * @author LaveenaS 
	 * 
	 * This method makes a get request to service layer to fetch
	 *         Role master table details.
	 * @return ResponseEntity<List<RoleMasterDto>> returns response status as
	 *         OK if all goes well.
	 *
	 */
	@GetMapping("/fetch-role-master-table-details")
	@ApiOperation(value = "to fetch all role master table details")
	public ResponseEntity<List<RoleMasterDto>> fetchRoleMasterTableDetails() {

		List<RoleMasterDto> roleMasterDtoList = new ArrayList<>();

		logger.info("Inside fetchRoleMasterTableDetails method ");

		roleMasterDtoList = roleMasterService.fetchRoleMasterTableDetails();

		return ResponseEntity.ok(roleMasterDtoList);

	}
	
	/**
	 * @author LaveenaS 
	 * 
	 * This method makes a get request to service layer to fetch
	 *         Role names against provided role master id
	 * @return ResponseEntity<String> returns response status as
	 *         OK if all goes well.
	 *
	 */
	@GetMapping("/fetch-role-name/{roleMasterId}")
	@ApiOperation(value = "to fetch role name against provided role id")
	public ResponseEntity<String> fetchRoleName(@ApiParam(value = "Role Id", required = true) @PathVariable Integer roleMasterId) {

		String roleName;

		logger.info("Inside fetchRoleName method ");

		roleName = roleMasterService.fetchRoleName(roleMasterId);
//		logger.info("roleName : "+ roleName);
//		logger.info("ResponseEntity.ok(roleName) : "+ ResponseEntity.ok(roleName));

		return ResponseEntity.ok(roleName);

	}

}
