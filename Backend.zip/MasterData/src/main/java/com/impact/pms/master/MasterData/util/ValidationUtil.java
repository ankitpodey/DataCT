package com.impact.pms.master.MasterData.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author LaveenaS
 * 
 * This class contains methods that check general validations on objects like null and empty checks.
 *
 */
public class ValidationUtil {
	
	private final static Logger logger = LoggerFactory.getLogger(ValidationUtil.class);

	/**
	 * 
	 * This method is to perform empty/NIL/NONE/NA content validation on the object
	 *
	 */
	public static boolean checkEmpty(String value) {
		
		logger.info("Inside ValidationUtil class, checkEmpty method ");
		
		if( value == null ||  value.trim().equalsIgnoreCase("NONE") || 
				value.trim().replaceAll("\\.", "").replaceAll("\\s+", "").equalsIgnoreCase("NA") || value.trim().equalsIgnoreCase("NA") || value.trim().contains("N.A") || value.trim().contains("N.A.") || 
				value.trim().equalsIgnoreCase("NIL") || 
				value.trim().equalsIgnoreCase("NULL") ||
				value.trim().isEmpty()) {
				return true;
		}
		
		return false;
	}
	
	/**
	 * 
	 * This method is to perform empty/NULL validation on the object
	 *
	 */
	public static boolean isStringNullOrEmpty(String string) {
		
		logger.info("Inside ValidationUtil class, isStringNullOrEmpty method ");
		
		return checkEmpty(string) ? true : false;
	}
	
	
}
