package com.impact.pms.master.MasterData.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Model class for Procedure_Master Table
 */
@Entity
@Table(name = "procedure_master")
@ApiModel
public class ProcedureMaster implements Serializable {
	
	/**
	 * Added generated serial version ID
	 */
	private static final long serialVersionUID = -2220209556519403786L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty
	private Integer procedureMasterId;

	private String procedureCode;

	private String procedureDescription;

	private String procedureApproach;

	private boolean procedureDepricatedFlag;

	private boolean delFlag;

	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;

	public ProcedureMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProcedureMaster(Integer procedureMasterId, String procedureCode, String procedureDescription,
			String procedureApproach, boolean procedureDepricatedFlag, boolean delFlag, LocalDate dateCreated,
			LocalDate dateUpdated, Integer createdBy, Integer updatedBy) {
		super();
		this.procedureMasterId = procedureMasterId;
		this.procedureCode = procedureCode;
		this.procedureDescription = procedureDescription;
		this.procedureApproach = procedureApproach;
		this.procedureDepricatedFlag = procedureDepricatedFlag;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "ProcedureMaster [procedureMasterId=" + procedureMasterId + ", procedureCode=" + procedureCode
				+ ", procedureDescription=" + procedureDescription + ", procedureApproach=" + procedureApproach
				+ ", procedureDepricatedFlag=" + procedureDepricatedFlag + ", delFlag=" + delFlag + ", dateCreated="
				+ dateCreated + ", dateUpdated=" + dateUpdated + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy
				+ "]";
	}

	/**
	 * @return the procedureMasterId
	 */
	public Integer getProcedureMasterId() {
		return procedureMasterId;
	}

	/**
	 * @param procedureMasterId the procedureMasterId to set
	 */
	public void setProcedureMasterId(Integer procedureMasterId) {
		this.procedureMasterId = procedureMasterId;
	}

	/**
	 * @return the procedureCode
	 */
	public String getProcedureCode() {
		return procedureCode;
	}

	/**
	 * @param procedureCode the procedureCode to set
	 */
	public void setProcedureCode(String procedureCode) {
		this.procedureCode = procedureCode;
	}

	/**
	 * @return the procedureDescription
	 */
	public String getProcedureDescription() {
		return procedureDescription;
	}

	/**
	 * @param procedureDescription the procedureDescription to set
	 */
	public void setProcedureDescription(String procedureDescription) {
		this.procedureDescription = procedureDescription;
	}

	/**
	 * @return the procedureApproach
	 */
	public String getProcedureApproach() {
		return procedureApproach;
	}

	/**
	 * @param procedureApproach the procedureApproach to set
	 */
	public void setProcedureApproach(String procedureApproach) {
		this.procedureApproach = procedureApproach;
	}

	/**
	 * @return the procedureDepricatedFlag
	 */
	public boolean isProcedureDepricatedFlag() {
		return procedureDepricatedFlag;
	}

	/**
	 * @param procedureDepricatedFlag the procedureDepricatedFlag to set
	 */
	public void setProcedureDepricatedFlag(boolean procedureDepricatedFlag) {
		this.procedureDepricatedFlag = procedureDepricatedFlag;
	}

	/**
	 * @return the delFlag
	 */
	public boolean isDelFlag() {
		return delFlag;
	}

	/**
	 * @param delFlag the delFlag to set
	 */
	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	/**
	 * @return the dateCreated
	 */
	public LocalDate getDateCreated() {
		return dateCreated;
	}

	/**
	 * @param dateCreated the dateCreated to set
	 */
	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	/**
	 * @return the dateUpdated
	 */
	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	/**
	 * @param dateUpdated the dateUpdated to set
	 */
	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	/**
	 * @return the createdBy
	 */
	public Integer getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedBy
	 */
	public Integer getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

}
