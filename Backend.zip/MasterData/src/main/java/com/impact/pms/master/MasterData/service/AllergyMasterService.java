package com.impact.pms.master.MasterData.service;

import java.util.List;
import java.util.Map;

import com.impact.pms.master.MasterData.dto.AllergyMasterDto;
import com.impact.pms.master.MasterData.model.AllergyMaster;

/**
 * @author LaveenaS
 * Service class to define methods of AllergyMaster service layer.
 *
 */
public interface AllergyMasterService {

	Map<Integer, String> fetchAllergyMasterMapTableDetails();

	List<AllergyMasterDto> fetchAllergyMasterTableDetails();

	AllergyMaster addAllergy(AllergyMasterDto allergyMasterDto);

}
