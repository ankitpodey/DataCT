package com.impact.pms.master.MasterData.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.pms.master.MasterData.dto.RoleMasterDto;
import com.impact.pms.master.MasterData.dto.RoleMasterMapDto;
import com.impact.pms.master.MasterData.model.RoleMaster;
import com.impact.pms.master.MasterData.repository.RoleMasterRepository;
import com.impact.pms.master.MasterData.service.RoleMasterService;

/**
 * @author LaveenaS
 * 
 *         Service class to call repository method to read role master
 *         table contents
 *
 */
@Service
public class RoleMasterServiceImpl implements RoleMasterService {

	private final static Logger logger = LoggerFactory.getLogger(RoleMasterServiceImpl.class);

	@Autowired
	private RoleMasterRepository roleMasterRepository;

	/**
	 * @return RoleMasterMapDto that contains data sent to front-end for
	 *         displaying in data table. This method calls repository method
	 *         (findAll) for reading Role_master table details
	 *
	 */
	@Override
	public Map<Integer, String> fetchRoleMasterMapTableDetails() {

		logger.info("Inside RoleMasterServiceImpl fetchRoleMasterMapTableDetails method");

		Map<Integer, String> roleMasterResultMap = new HashMap<>();

		List<RoleMaster> roleMasterList = roleMasterRepository.findAll();

		for (RoleMaster roleMasterListRecord : roleMasterList) {
			RoleMasterMapDto roleMasterMapDto = new RoleMasterMapDto();
			BeanUtils.copyProperties(roleMasterListRecord,roleMasterMapDto);
			roleMasterResultMap.put(roleMasterMapDto.getRoleId(),
					roleMasterMapDto.getRoleType());
		}

		logger.info("Total number of active records in Role_Master table : " + roleMasterResultMap.size());
		return roleMasterResultMap;
	}

	/**
	 * @return List<RoleMasterDto> that contains data sent to front-end for
	 *         displaying in data table. This method calls repository method
	 *         (findAll) for reading Role_master table details and filters active records
	 *
	 */
	@Override
	public List<RoleMasterDto> fetchRoleMasterTableDetails() {
		
		logger.info("Inside RoleMasterServiceImpl fetchRoleMasterTableDetails method");

		List<RoleMasterDto> roleMasterDtoList = new ArrayList<>();

		List<RoleMaster> roleMasterList = roleMasterRepository.findAll();

		// Copying properties from filtered records to Dto object
		roleMasterList.forEach(roleMasterRecord -> {
			RoleMasterDto roleMasterDto = new RoleMasterDto();
			BeanUtils.copyProperties(roleMasterRecord, roleMasterDto);
			roleMasterDtoList.add(roleMasterDto);
		});

		logger.info("Total number of active records in Role_Master table : " + roleMasterDtoList.size());
		return roleMasterDtoList;
	}

	/**
	 * @return String (RoleName) for provided roleMasterId
	 *
	 */
	@Override
	public String fetchRoleName(Integer roleMasterId) {
		logger.info("Inside RoleMasterServiceImpl fetchRoleMasterTableDetails method");

		Optional<RoleMaster> roleMasterRecord = roleMasterRepository.findById(roleMasterId);

		RoleMaster roleMaster = roleMasterRecord.get();

		String roleName = roleMaster.getRoleType();
		
		logger.info("Role name is fethed from DB ");
		
		return roleName;
	}

}
