package com.impact.pms.master.MasterData.dto;


/**
 * @author LaveenaS
 * This is a DTO class that is used to fetch only required contents of Diagnosis Master table.
 *
 */
public class DiagnosisMasterDto {
	
	private Integer diagnosisMasterId;

	private String diagnosisCode;

	private String diagnosisDescription;

	private String diagnosisType;

	private boolean diagnosisDepricatedFlag;

	public DiagnosisMasterDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DiagnosisMasterDto(Integer diagnosisMasterId, String diagnosisCode, String diagnosisDescription,
			String diagnosisType, boolean diagnosisDepricatedFlag) {
		super();
		this.diagnosisMasterId = diagnosisMasterId;
		this.diagnosisCode = diagnosisCode;
		this.diagnosisDescription = diagnosisDescription;
		this.diagnosisType = diagnosisType;
		this.diagnosisDepricatedFlag = diagnosisDepricatedFlag;
	}

	/**
	 * @return the diagnosisMasterId
	 */
	public Integer getDiagnosisMasterId() {
		return diagnosisMasterId;
	}

	/**
	 * @param diagnosisMasterId the diagnosisMasterId to set
	 */
	public void setDiagnosisMasterId(Integer diagnosisMasterId) {
		this.diagnosisMasterId = diagnosisMasterId;
	}

	/**
	 * @return the diagnosisCode
	 */
	public String getDiagnosisCode() {
		return diagnosisCode;
	}

	/**
	 * @param diagnosisCode the diagnosisCode to set
	 */
	public void setDiagnosisCode(String diagnosisCode) {
		this.diagnosisCode = diagnosisCode;
	}

	/**
	 * @return the diagnosisDescription
	 */
	public String getDiagnosisDescription() {
		return diagnosisDescription;
	}

	/**
	 * @param diagnosisDescription the diagnosisDescription to set
	 */
	public void setDiagnosisDescription(String diagnosisDescription) {
		this.diagnosisDescription = diagnosisDescription;
	}

	/**
	 * @return the diagnosisType
	 */
	public String getDiagnosisType() {
		return diagnosisType;
	}

	/**
	 * @param diagnosisType the diagnosisType to set
	 */
	public void setDiagnosisType(String diagnosisType) {
		this.diagnosisType = diagnosisType;
	}

	/**
	 * @return the diagnosisDepricatedFlag
	 */
	public boolean isDiagnosisDepricatedFlag() {
		return diagnosisDepricatedFlag;
	}

	/**
	 * @param diagnosisDepricatedFlag the diagnosisDepricatedFlag to set
	 */
	public void setDiagnosisDepricatedFlag(boolean diagnosisDepricatedFlag) {
		this.diagnosisDepricatedFlag = diagnosisDepricatedFlag;
	}

}
