package com.impact.pms.master.MasterData.dto;

/**
 * @author LaveenaS
 * This is a DTO class that is used to fetch only required contents of Medication Master table.
 *
 */
public class MedicationMasterDto {

	private Integer medicationMasterId;

	private String medicationId;

	private String medicationName;

	private String medicationGenericName;

	private String medicationManufacturerName;

	private String medicationForm;

	private String medicationStrength;

	/**
	 * @return the medicationMasterId
	 */
	public Integer getMedicationMasterId() {
		return medicationMasterId;
	}

	/**
	 * @param medicationMasterId the medicationMasterId to set
	 */
	public void setMedicationMasterId(Integer medicationMasterId) {
		this.medicationMasterId = medicationMasterId;
	}

	/**
	 * @return the medicationId
	 */
	public String getMedicationId() {
		return medicationId;
	}

	/**
	 * @param medicationId the medicationId to set
	 */
	public void setMedicationId(String medicationId) {
		this.medicationId = medicationId;
	}

	/**
	 * @return the medicationName
	 */
	public String getMedicationName() {
		return medicationName;
	}

	/**
	 * @param medicationName the medicationName to set
	 */
	public void setMedicationName(String medicationName) {
		this.medicationName = medicationName;
	}

	/**
	 * @return the medicationGenericName
	 */
	public String getMedicationGenericName() {
		return medicationGenericName;
	}

	/**
	 * @param medicationGenericName the medicationGenericName to set
	 */
	public void setMedicationGenericName(String medicationGenericName) {
		this.medicationGenericName = medicationGenericName;
	}

	/**
	 * @return the medicationManufacturerName
	 */
	public String getMedicationManufacturerName() {
		return medicationManufacturerName;
	}

	/**
	 * @param medicationManufacturerName the medicationManufacturerName to set
	 */
	public void setMedicationManufacturerName(String medicationManufacturerName) {
		this.medicationManufacturerName = medicationManufacturerName;
	}

	/**
	 * @return the medicationForm
	 */
	public String getMedicationForm() {
		return medicationForm;
	}

	/**
	 * @param medicationForm the medicationForm to set
	 */
	public void setMedicationForm(String medicationForm) {
		this.medicationForm = medicationForm;
	}

	/**
	 * @return the medicationStrength
	 */
	public String getMedicationStrength() {
		return medicationStrength;
	}

	/**
	 * @param medicationStrength the medicationStrength to set
	 */
	public void setMedicationStrength(String medicationStrength) {
		this.medicationStrength = medicationStrength;
	}

	@Override
	public String toString() {
		return "MedicationMasterDto [medicationMasterId=" + medicationMasterId + ", medicationId=" + medicationId
				+ ", medicationName=" + medicationName + ", medicationGenericName=" + medicationGenericName
				+ ", medicationManufacturerName=" + medicationManufacturerName + ", medicationForm=" + medicationForm
				+ ", medicationStrength=" + medicationStrength + "]";
	}
}
