package com.impact.pms.master.MasterData.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.impact.pms.master.MasterData.dto.SpecialityMasterDto;
import com.impact.pms.master.MasterData.service.SpecialityMasterService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * @author LaveenaS
 * 
 *         This is a controller class that makes a call to service. URLs are
 *         mapped as /master as this is a master application and makes call to
 *         master schema tables through service layer.
 *
 */
@RestController
@RequestMapping("/master/speciality")
public class SpecialityMasterController {
	
	@Autowired
	private SpecialityMasterService specialityMasterService;

	private final static Logger logger = LoggerFactory.getLogger(SpecialityMasterController.class);

	/**
	 * @author LaveenaS 
	 * 
	 * This method makes a get request to service layer to fetch only required
	 *         speciality master table columns.
	 * @return ResponseEntity<Map<Integer, String>>  returns response status as
	 *         OK if all goes well.
	 *
	 */
	@GetMapping("/fetch-speciality-master-map-details")
	@ApiOperation(value = "to fetch only specified speciality master table details.")
	public ResponseEntity<Map<Integer, String>> fetchSpecialityMasterMapTableDetails() {

		Map<Integer, String> specialityMasterMap = new HashMap<>();

		logger.info("Inside fetchSpecialityMasterMapTableDetails method ");

		specialityMasterMap = specialityMasterService.fetchSpecialityMasterMapTableDetails();

		return ResponseEntity.ok(specialityMasterMap);

	}
	
	/**
	 * @author LaveenaS 
	 * 
	 * This method makes a get request to service layer to fetch
	 *         speciality master table details.
	 * @return ResponseEntity<List<SpecialityMasterDto>> returns response status as
	 *         OK if all goes well.
	 *
	 */
	@GetMapping("/fetch-speciality-master-table-details")
	@ApiOperation(value = "to fetch all speciality master table details.")
	public ResponseEntity<List<SpecialityMasterDto>> fetchSpecialityMasterTableDetails() {

		List<SpecialityMasterDto> specialityMasterDtoList = new ArrayList<>();

		logger.info("Inside fetchSpecialityMasterTableDetails method ");

		specialityMasterDtoList = specialityMasterService.fetchSpecialityMasterTableDetails();

		return ResponseEntity.ok(specialityMasterDtoList);

	}
	
	/**
	 * @author LaveenaS 
	 * 
	 * This method makes a get request to service layer to fetch
	 *         speciality names against provided speciality master id
	 * @return ResponseEntity<String> returns response status as
	 *         OK if all goes well.
	 *
	 */
	@GetMapping("/fetch-speciality-name/{specialityMasterId}")
	@ApiOperation(value = "to fetch role name against provided role id")
	public ResponseEntity<String> fetchSpecialityName(@ApiParam(value = "Speciality Id", required = true) @PathVariable Integer specialityMasterId) {

		String specialityName;

		logger.info("Inside fetchSpecialityName method ");

		specialityName = specialityMasterService.fetchSpecialityName(specialityMasterId);

		return ResponseEntity.ok(specialityName);

	}

}
