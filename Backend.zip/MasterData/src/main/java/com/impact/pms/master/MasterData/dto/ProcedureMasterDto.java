package com.impact.pms.master.MasterData.dto;

/**
 * @author LaveenaS
 * This is a DTO class that is used to fetch only required contents of Procedure Master table.
 *
 */
public class ProcedureMasterDto {
	
	private Integer procedureMasterId;

	private String procedureCode;

	private String procedureDescription;

	private String procedureApproach;

	private boolean procedureDepricatedFlag;

	/**
	 * @return the procedureMasterId
	 */
	public Integer getProcedureMasterId() {
		return procedureMasterId;
	}

	/**
	 * @param procedureMasterId the procedureMasterId to set
	 */
	public void setProcedureMasterId(Integer procedureMasterId) {
		this.procedureMasterId = procedureMasterId;
	}

	/**
	 * @return the procedureCode
	 */
	public String getProcedureCode() {
		return procedureCode;
	}

	/**
	 * @param procedureCode the procedureCode to set
	 */
	public void setProcedureCode(String procedureCode) {
		this.procedureCode = procedureCode;
	}

	/**
	 * @return the procedureDescription
	 */
	public String getProcedureDescription() {
		return procedureDescription;
	}

	/**
	 * @param procedureDescription the procedureDescription to set
	 */
	public void setProcedureDescription(String procedureDescription) {
		this.procedureDescription = procedureDescription;
	}

	/**
	 * @return the procedureApproach
	 */
	public String getProcedureApproach() {
		return procedureApproach;
	}

	/**
	 * @param procedureApproach the procedureApproach to set
	 */
	public void setProcedureApproach(String procedureApproach) {
		this.procedureApproach = procedureApproach;
	}

	/**
	 * @return the procedureDepricatedFlag
	 */
	public boolean isProcedureDepricatedFlag() {
		return procedureDepricatedFlag;
	}

	/**
	 * @param procedureDepricatedFlag the procedureDepricatedFlag to set
	 */
	public void setProcedureDepricatedFlag(boolean procedureDepricatedFlag) {
		this.procedureDepricatedFlag = procedureDepricatedFlag;
	}

}
