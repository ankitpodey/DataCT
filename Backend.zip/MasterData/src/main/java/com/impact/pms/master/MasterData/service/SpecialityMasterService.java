package com.impact.pms.master.MasterData.service;

import java.util.List;
import java.util.Map;

import com.impact.pms.master.MasterData.dto.SpecialityMasterDto;

/**
 * @author LaveenaS
 * Service class to define methods of SpecialityMaster service layer.
 *
 */
public interface SpecialityMasterService {

	Map<Integer, String> fetchSpecialityMasterMapTableDetails();

	List<SpecialityMasterDto> fetchSpecialityMasterTableDetails();

	String fetchSpecialityName(Integer specialityMasterId);

}
