package com.impact.pms.master.MasterData.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.pms.master.MasterData.dto.ProcedureMasterDto;
import com.impact.pms.master.MasterData.model.ProcedureMaster;
import com.impact.pms.master.MasterData.repository.ProcedureMasterRepository;
import com.impact.pms.master.MasterData.service.ProcedureMasterService;

/**
 * @author LaveenaS
 * 
 *         Service class to call repository method to read procedure master
 *         table contents
 *
 */
@Service
public class ProcedureMasterServiceImpl implements ProcedureMasterService {

	private final static Logger logger = LoggerFactory.getLogger(ProcedureMasterServiceImpl.class);

	@Autowired
	private ProcedureMasterRepository procedureMasterRepository;

	/**
	 * @return ProcedureMasterDto that contains data sent to front-end for
	 *         displaying in data table. This method calls repository method
	 *         (findAll) for reading all contents and filters records that are
	 *         active in the table.
	 *
	 */
	@Override
	public List<ProcedureMasterDto> fetchProcedureMasterTableDetails() {

		logger.info("Inside ProcedureMasterServiceImpl fetchProcedureMasterTableDetails method");

		List<ProcedureMasterDto> procedureMasterDtoList = new ArrayList<>();
		List<ProcedureMaster> filteredProcedureMasterList = new ArrayList<>();

		List<ProcedureMaster> procedureMasterList = procedureMasterRepository.findAll();

		// Stream API + filter method to get only active records from table
		filteredProcedureMasterList = procedureMasterList.stream()
				.filter(procedureMasterRecord -> procedureMasterRecord.isDelFlag() == false)
				.collect(Collectors.toList());

		// Copying properties from filtered records to Dto object
		filteredProcedureMasterList.forEach(procedureMasterRecord -> {
			ProcedureMasterDto procedureMasterDto = new ProcedureMasterDto();
			BeanUtils.copyProperties(procedureMasterRecord, procedureMasterDto);
			procedureMasterDtoList.add(procedureMasterDto);
		});

		logger.info("Total number of active records in Procedure_Master table : " + procedureMasterDtoList.size());
		return procedureMasterDtoList;
	}
	
	/**
	 * @return Map<Integer, ProcedureMasterDto> that contains data sent to visit-ms
	 * for patient past visit endpoint
	 * 
	 *
	 */
	@Override
	public Map<Integer, ProcedureMasterDto> fetchProcedureMasterTableMapDetails() {
		
		logger.info("Inside ProcedureMasterServiceImpl fetcProcedureMasterTableMapDetails method");
		
		Map<Integer, ProcedureMasterDto> procedureMasterMap = new HashMap<>();
		List<ProcedureMasterDto> procedureMasterDtoList = new ArrayList<>();
		
		procedureMasterDtoList = fetchProcedureMasterTableDetails();
		for (ProcedureMasterDto procedureMasterDto : procedureMasterDtoList) {
			procedureMasterMap.put(procedureMasterDto.getProcedureMasterId(), procedureMasterDto);
		}
		
		logger.info("Total number of active records in Procedure_Master table : " + procedureMasterMap.size());
		
		return procedureMasterMap;
	}

}
