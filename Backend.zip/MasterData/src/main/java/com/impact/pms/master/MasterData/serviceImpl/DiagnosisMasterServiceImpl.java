package com.impact.pms.master.MasterData.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.pms.master.MasterData.dto.DiagnosisMasterDto;
import com.impact.pms.master.MasterData.model.DiagnosisMaster;
import com.impact.pms.master.MasterData.repository.DiagnosisMasterRepository;
import com.impact.pms.master.MasterData.service.DiagnosisMasterService;

/**
 * @author LaveenaS
 * 
 *         Service class to call repository method to read diagnosis master
 *         table contents
 *
 */
@Service
public class DiagnosisMasterServiceImpl implements DiagnosisMasterService {

	private final static Logger logger = LoggerFactory.getLogger(DiagnosisMasterServiceImpl.class);

	@Autowired
	private DiagnosisMasterRepository diagnosisMasterRepository;

	/**
	 * @return DiagnosisMasterDto that contains data sent to front-end for
	 *         displaying in data table. This method calls repository method
	 *         (findAll) for reading all contents and filters records that are
	 *         active in the table.
	 *
	 */
	@Override
	public List<DiagnosisMasterDto> fetchDiagnosisMasterTableDetails() {

		logger.info("Inside DiagnosisMasterServiceImpl fetchDiagnosisMasterTableDetails method");

		List<DiagnosisMasterDto> diagnosisMasterDtoList = new ArrayList<>();
		List<DiagnosisMaster> filteredDiagnosisMasterList = new ArrayList<>();

		List<DiagnosisMaster> diagnosisMasterList = diagnosisMasterRepository.findAll();

		// Stream API + filter method to get only active records from table
		filteredDiagnosisMasterList = diagnosisMasterList.stream()
				.filter(diagnosisMasterRecord -> diagnosisMasterRecord.isDelFlag() == false)
				.collect(Collectors.toList());

		// Copying properties from filtered records to Dto object
		filteredDiagnosisMasterList.forEach(diagnosisMasterRecord -> {
			DiagnosisMasterDto diagnosisMasterDto = new DiagnosisMasterDto();
			BeanUtils.copyProperties(diagnosisMasterRecord, diagnosisMasterDto);
			diagnosisMasterDtoList.add(diagnosisMasterDto);
		});

		logger.info("Total number of active records in Diagnosis_Master table : " + diagnosisMasterDtoList.size());
		return diagnosisMasterDtoList;
	}

	/**
	 * @return Map<Integer, DiagnosisMasterDto> that contains data sent to visit-ms
	 * for patient past visit endpoint
	 * 
	 *
	 */
	@Override
	public Map<Integer, DiagnosisMasterDto> fetchDiagnosisMasterTableMapDetails() {
		
		logger.info("Inside DiagnosisMasterServiceImpl fetchDiagnosisMasterTableMapDetails method");
		
		Map<Integer, DiagnosisMasterDto> diagnosisMasterMap = new HashMap<>();
		List<DiagnosisMasterDto> diagnosisMasterDtoList = new ArrayList<>();
		
		diagnosisMasterDtoList = fetchDiagnosisMasterTableDetails();
		for (DiagnosisMasterDto diagnosisMasterDto : diagnosisMasterDtoList) {
			diagnosisMasterMap.put(diagnosisMasterDto.getDiagnosisMasterId(), diagnosisMasterDto);
		}
		
		logger.info("Total number of active records in Diagnosis_Master table : " + diagnosisMasterMap.size());
		
		return diagnosisMasterMap;
	}

	// Stream API to process each element of list
	/*
	 * diagnosisMasterList.stream().forEach(diagnosisMasterRecord -> {
	 * DiagnosisMasterDto diagnosisMasterDto = new DiagnosisMasterDto(); if
	 * (!diagnosisMasterRecord.isDelFlag()) {
	 * BeanUtils.copyProperties(diagnosisMasterRecord, diagnosisMasterDto);
	 * diagnosisMasterDtoList.add(diagnosisMasterDto);
	 * logger.info("Stream size is : " + diagnosisMasterDtoList.size()); } });
	 */

	// Traditional approach : for loop
	/*
	 * for (DiagnosisMaster diagnosisMasterRecord : diagnosisMasterList) {
	 * diagnosisMasterDto = new DiagnosisMasterDto(); if
	 * (!diagnosisMasterRecord.isDelFlag()) {
	 * BeanUtils.copyProperties(diagnosisMasterRecord, diagnosisMasterDto);
	 * diagnosisMasterDtoList.add(diagnosisMasterDto); } }
	 */

}
