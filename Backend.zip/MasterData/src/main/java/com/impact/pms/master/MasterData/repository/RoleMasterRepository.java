package com.impact.pms.master.MasterData.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.impact.pms.master.MasterData.model.RoleMaster;

/**
 * @author LaveenaS
 * Repository interface that connects to Master.Role_Master table.
 *
 */
@Repository
public interface RoleMasterRepository extends JpaRepository<RoleMaster, Integer> {

}
