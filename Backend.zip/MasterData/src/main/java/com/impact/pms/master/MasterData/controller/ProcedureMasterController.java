package com.impact.pms.master.MasterData.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.impact.pms.master.MasterData.dto.ProcedureMasterDto;
import com.impact.pms.master.MasterData.service.ProcedureMasterService;

import io.swagger.annotations.ApiOperation;

/**
 * @author LaveenaS
 * 
 *         This is a controller class that makes a call to service. URLs are
 *         mapped as /master as this is a master application and makes call to
 *         master schema tables through service layer.
 *
 */
@RestController
@RequestMapping("/master/procedure")
public class ProcedureMasterController {

	@Autowired
	private ProcedureMasterService procedureMasterService;

	private final static Logger logger = LoggerFactory.getLogger(ProcedureMasterController.class);

	/**
	 * @author LaveenaS 
	 * 
	 * This method makes a get request to service layer to fetch
	 *         diagnosis master table details.
	 * @return ResponseEntity<List<DiagnosisMasterDto>> returns response status as
	 *         OK if all goes well.
	 *
	 */
	@GetMapping("/fetch-procedure-master-table-details")
	@ApiOperation(value = "to fetch procedure master table details")
	public ResponseEntity<List<ProcedureMasterDto>> fetchProcedureMasterTableDetails() {

		List<ProcedureMasterDto> procedureMasterDtoList = new ArrayList<>();

		logger.info("Inside fetchProcedureMasterTableDetails method ");

		procedureMasterDtoList = procedureMasterService.fetchProcedureMasterTableDetails();

		return ResponseEntity.ok(procedureMasterDtoList);

	}
	
	/**
	 * @return Map<Integer, DiagnosisMasterDto> that contains data sent to visit-ms
	 * for patient past visit endpoint
	 * 
	 *
	 */
	@GetMapping("/fetch-procedure-master-table-map-details")
	@ApiOperation(value = "to fetch procedure master table details for past visit details of patient")
	public ResponseEntity<Map<Integer, ProcedureMasterDto>> fetchProcedureMasterTableMapDetails() {

		Map<Integer, ProcedureMasterDto> procedureMasterDtoMap = new HashMap<>();

		logger.info("Inside fetchProcedureMasterTableMapDetails method ");

		procedureMasterDtoMap = procedureMasterService.fetchProcedureMasterTableMapDetails();

		return ResponseEntity.ok(procedureMasterDtoMap);

	}

}
