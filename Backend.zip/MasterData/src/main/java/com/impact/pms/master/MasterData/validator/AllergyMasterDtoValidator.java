package com.impact.pms.master.MasterData.validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.impact.pms.master.MasterData.dto.AllergyMasterDto;
import com.impact.pms.master.MasterData.util.ValidationUtil;

/**
 * @author LaveenaS
 * 
 *         This class is to validate contents of AllergyMasterDto Object in
 *         request body of POST request
 *
 */
@Component
@Qualifier("AllergyMasterDtoValidator")
public class AllergyMasterDtoValidator implements Validator {

	private final static Logger logger = LoggerFactory.getLogger(AllergyMasterDtoValidator.class);

	/**
	 * 
	 * This method is to define the class on which the validation is to be performed
	 *
	 */
	@Override
	public boolean supports(Class<?> clazz) {
		logger.info("Inside AllergyMasterDtoValidator class, supports method ");
		return AllergyMasterDto.class.equals(clazz);
	}

	/**
	 * 
	 * This method is to validate the contents of AllergyMasterDto object received
	 * in POST request body.
	 *
	 */
	@Override
	public void validate(Object target, Errors errors) {
		logger.info("Inside AllergyMasterDtoValidator class, validate method ");

		// cast target to AllergyMasterDto
		AllergyMasterDto allergyMasterDto = (AllergyMasterDto) target;

		// perform validation
		if (ValidationUtil.isStringNullOrEmpty(allergyMasterDto.getAllergyType())) {
			errors.rejectValue("allergyType", "allergyMasterDto.allergyType.invalid");
		}

		if (ValidationUtil.isStringNullOrEmpty(allergyMasterDto.getAllergyName())) {
			errors.rejectValue("allergyName", "allergyMasterDto.allergyName.invalid");
		}

		if (ValidationUtil.isStringNullOrEmpty(allergyMasterDto.getAllergyDescription())) {
			errors.rejectValue("allergyDescription", "allergyMasterDto.allergyDescription.invalid");
		}

	}

}
