package com.impact.pms.master.MasterData.dto;

/**
 * @author LaveenaS
 * 
 * This is a DTO class that is used to fetch only Allergy_master_id and Allergy_name from Allergy Master table.
 *
 */
public class AllergyMasterMapDto {
	
	private Integer allergyMasterId;

	private String allergyName;

	/**
	 * @return the allergyMasterId
	 */
	public Integer getAllergyMasterId() {
		return allergyMasterId;
	}

	/**
	 * @param allergyMasterId the allergyMasterId to set
	 */
	public void setAllergyMasterId(Integer allergyMasterId) {
		this.allergyMasterId = allergyMasterId;
	}

	/**
	 * @return the allergyName
	 */
	public String getAllergyName() {
		return allergyName;
	}

	/**
	 * @param allergyName the allergyName to set
	 */
	public void setAllergyName(String allergyName) {
		this.allergyName = allergyName;
	}

}
