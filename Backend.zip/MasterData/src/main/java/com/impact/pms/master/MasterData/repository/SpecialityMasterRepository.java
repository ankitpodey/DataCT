package com.impact.pms.master.MasterData.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.impact.pms.master.MasterData.model.SpecialityMaster;

/**
 * @author LaveenaS
 * Repository interface that connects to Master.Speciality_Master table.
 *
 */
@Repository
public interface SpecialityMasterRepository extends JpaRepository<SpecialityMaster, Integer> {
	
}
