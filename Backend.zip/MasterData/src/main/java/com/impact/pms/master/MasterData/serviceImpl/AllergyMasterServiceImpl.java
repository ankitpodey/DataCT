package com.impact.pms.master.MasterData.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.pms.master.MasterData.dto.AllergyMasterDto;
import com.impact.pms.master.MasterData.dto.AllergyMasterMapDto;
import com.impact.pms.master.MasterData.model.AllergyMaster;
import com.impact.pms.master.MasterData.repository.AllergyMasterRepository;
import com.impact.pms.master.MasterData.service.AllergyMasterService;

/**
 * @author LaveenaS
 * 
 *         Service class to call repository method to read Allergy master table
 *         contents
 *
 */
@Service
public class AllergyMasterServiceImpl implements AllergyMasterService {

	private final static Logger logger = LoggerFactory.getLogger(AllergyMasterServiceImpl.class);

	@Autowired
	private AllergyMasterRepository allergyMasterRepository;

	/**
	 * @return AllergyMasterMapDto that contains data sent to front-end for
	 *         displaying in data table. This method calls repository method
	 *         (findAll) for reading Allergy_master table details
	 *
	 */
	@Override
	public Map<Integer, String> fetchAllergyMasterMapTableDetails() {

		logger.info("Inside AllergyMasterServiceImpl fetchAllergyMasterMapTableDetails method");

		Map<Integer, String> allergyMasterResultMap = new HashMap<>();

		List<AllergyMaster> allergyMasterList = allergyMasterRepository.findAll();

		for (AllergyMaster allergyMasterListRecord : allergyMasterList) {
			AllergyMasterMapDto allergyMasterMapDto = new AllergyMasterMapDto();
			BeanUtils.copyProperties(allergyMasterListRecord, allergyMasterMapDto);
			allergyMasterResultMap.put(allergyMasterMapDto.getAllergyMasterId(), allergyMasterMapDto.getAllergyName());
		}

		logger.info("Total number of active records in Speciality_Master table : " + allergyMasterResultMap.size());
		return allergyMasterResultMap;
	}

	/**
	 * @return List<AllergyMasterDto> that contains data sent to front-end for
	 *         displaying in data table. This method calls repository method
	 *         (findAll) for reading Allergy_master table details and filters active
	 *         records
	 *
	 */
	@Override
	public List<AllergyMasterDto> fetchAllergyMasterTableDetails() {

		logger.info("Inside AllergyMasterServiceImpl fetchAllergyMasterTableDetails method");

		List<AllergyMasterDto> allergyMasterDtoList = new ArrayList<>();
		List<AllergyMaster> filteredAllergyMasterList = new ArrayList<>();

		List<AllergyMaster> allergyMasterList = allergyMasterRepository.findAll();

		// Stream API + filter method to get only active records from table
		filteredAllergyMasterList = allergyMasterList.stream()
				.filter(allergyMasterRecord -> allergyMasterRecord.isDelFlag() == false).collect(Collectors.toList());

		// Copying properties from filtered records to Dto object
		filteredAllergyMasterList.forEach(allergyMasterRecord -> {
			AllergyMasterDto allergyMasterDto = new AllergyMasterDto();
			BeanUtils.copyProperties(allergyMasterRecord, allergyMasterDto);
			allergyMasterDtoList.add(allergyMasterDto);
		});

		logger.info("Total number of active records in Diagnosis_Master table : " + allergyMasterDtoList.size());
		return allergyMasterDtoList;
	}

	/**
	 * @return AllergyMaster that contains allergy details, added to allergy
	 *         master table through repository.save method.
	 *
	 */
	@Override
	public AllergyMaster addAllergy(AllergyMasterDto allergyMasterDto) {

		logger.info("Inside AllergyMasterServiceImpl addAllergy method");

		AllergyMaster allergyMaster = new AllergyMaster();

		BeanUtils.copyProperties(allergyMasterDto, allergyMaster);
		AllergyMaster allergyMasterDtoRecord = allergyMasterRepository.save(allergyMaster);
		return allergyMasterDtoRecord;
	}

}