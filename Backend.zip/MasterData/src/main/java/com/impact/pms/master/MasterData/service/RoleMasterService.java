package com.impact.pms.master.MasterData.service;

import java.util.List;
import java.util.Map;

import com.impact.pms.master.MasterData.dto.RoleMasterDto;

/**
 * @author LaveenaS
 * Service class to define methods of RoleMaster service layer.
 *
 */
public interface RoleMasterService {

	List<RoleMasterDto> fetchRoleMasterTableDetails();

	Map<Integer, String> fetchRoleMasterMapTableDetails();

	String fetchRoleName(Integer roleMasterId);

}
