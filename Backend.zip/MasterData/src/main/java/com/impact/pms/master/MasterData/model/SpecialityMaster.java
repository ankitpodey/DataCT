package com.impact.pms.master.MasterData.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Model class for Speciality_Master Table
 */
@Entity
@Table(name = "speciality_master")
@ApiModel
public class SpecialityMaster implements Serializable {
	
	/**
	 * Added generated serial version ID
	 */
	private static final long serialVersionUID = -8946975531177210599L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty
	private Integer specialityMasterId;

	private String specialityName;

	private String specialityDescription;

	@CreationTimestamp
	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;

	public SpecialityMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SpecialityMaster(Integer specialityMasterId, String specialityName, String specialityDescription,
			LocalDate dateCreated, LocalDate dateUpdated, Integer createdBy, Integer updatedBy) {
		super();
		this.specialityMasterId = specialityMasterId;
		this.specialityName = specialityName;
		this.specialityDescription = specialityDescription;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "SpecialityMaster [specialityMasterId=" + specialityMasterId + ", specialityName=" + specialityName
				+ ", specialityDescription=" + specialityDescription + ", dateCreated=" + dateCreated + ", dateUpdated="
				+ dateUpdated + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + "]";
	}

	/**
	 * @return the specialityMasterId
	 */
	public Integer getSpecialityMasterId() {
		return specialityMasterId;
	}

	/**
	 * @param specialityMasterId the specialityMasterId to set
	 */
	public void setSpecialityMasterId(Integer specialityMasterId) {
		this.specialityMasterId = specialityMasterId;
	}

	/**
	 * @return the specialityName
	 */
	public String getSpecialityName() {
		return specialityName;
	}

	/**
	 * @param specialityName the specialityName to set
	 */
	public void setSpecialityName(String specialityName) {
		this.specialityName = specialityName;
	}

	/**
	 * @return the specialityDescription
	 */
	public String getSpecialityDescription() {
		return specialityDescription;
	}

	/**
	 * @param specialityDescription the specialityDescription to set
	 */
	public void setSpecialityDescription(String specialityDescription) {
		this.specialityDescription = specialityDescription;
	}

	/**
	 * @return the dateCreated
	 */
	public LocalDate getDateCreated() {
		return dateCreated;
	}

	/**
	 * @param dateCreated the dateCreated to set
	 */
	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	/**
	 * @return the dateUpdated
	 */
	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	/**
	 * @param dateUpdated the dateUpdated to set
	 */
	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	/**
	 * @return the createdBy
	 */
	public Integer getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedBy
	 */
	public Integer getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

}
