package com.impact.pms.master.MasterData.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.impact.pms.master.MasterData.model.DiagnosisMaster;

/**
 * @author LaveenaS
 * Repository interface that connects to Master.Diagnosis_Master table.
 *
 */
@Repository
public interface DiagnosisMasterRepository extends JpaRepository<DiagnosisMaster, Integer> {
	
}