package com.impact.pms.master.MasterData.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.impact.pms.master.MasterData.model.ProcedureMaster;

/**
 * @author LaveenaS
 * Repository interface that connects to Master.Procedure_Master table.
 *
 */
@Repository
public interface ProcedureMasterRepository  extends JpaRepository<ProcedureMaster, Integer> {

}
