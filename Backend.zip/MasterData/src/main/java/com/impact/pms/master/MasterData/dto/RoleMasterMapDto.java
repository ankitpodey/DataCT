package com.impact.pms.master.MasterData.dto;

/**
 * @author LaveenaS
 * 
 * This is a DTO class that is used to fetch only specified details from Role Master table.
 *
 */
public class RoleMasterMapDto {
	
	private Integer roleId;

	private String roleType;

	/**
	 * @return the roleId
	 */
	public Integer getRoleId() {
		return roleId;
	}

	/**
	 * @param roleId the roleId to set
	 */
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	/**
	 * @return the roleType
	 */
	public String getRoleType() {
		return roleType;
	}

	/**
	 * @param roleType the roleType to set
	 */
	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}

}
