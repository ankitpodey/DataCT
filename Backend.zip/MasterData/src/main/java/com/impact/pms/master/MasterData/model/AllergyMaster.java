package com.impact.pms.master.MasterData.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Model class for Allergy_Master Table
 */
@Entity
@Table(name = "allergy_master")
@ApiModel
public class AllergyMaster implements Serializable {

	/**
	 * Added generated serial version ID
	 */
	private static final long serialVersionUID = 4425904806309764984L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty
	private Integer allergyMasterId;

	private String allergyType;

	private String allergyName;

	private String allergyDescription;

	private boolean delFlag;

	@CreationTimestamp
	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;

	public AllergyMaster() {
		super();
	}

	public AllergyMaster(Integer allergyMasterId, String allergyType, String allergyName, String allergyDescription,
			boolean delFlag, LocalDate dateCreated, LocalDate dateUpdated, Integer createdBy, Integer updatedBy) {
		super();
		this.allergyMasterId = allergyMasterId;
		this.allergyType = allergyType;
		this.allergyName = allergyName;
		this.allergyDescription = allergyDescription;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "AllergyMaster [allergyMasterId=" + allergyMasterId + ", allergyType=" + allergyType + ", allergyName="
				+ allergyName + ", allergyDescription=" + allergyDescription + ", delFlag=" + delFlag + ", dateCreated="
				+ dateCreated + ", dateUpdated=" + dateUpdated + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy
				+ "]";
	}

	/**
	 * @return the allergyMasterId
	 */
	public Integer getAllergyMasterId() {
		return allergyMasterId;
	}

	/**
	 * @param allergyMasterId the allergyMasterId to set
	 */
	public void setAllergyMasterId(Integer allergyMasterId) {
		this.allergyMasterId = allergyMasterId;
	}

	/**
	 * @return the allergyType
	 */
	public String getAllergyType() {
		return allergyType;
	}

	/**
	 * @param allergyType the allergyType to set
	 */
	public void setAllergyType(String allergyType) {
		this.allergyType = allergyType;
	}

	/**
	 * @return the allergyName
	 */
	public String getAllergyName() {
		return allergyName;
	}

	/**
	 * @param allergyName the allergyName to set
	 */
	public void setAllergyName(String allergyName) {
		this.allergyName = allergyName;
	}

	/**
	 * @return the allergyDescription
	 */
	public String getAllergyDescription() {
		return allergyDescription;
	}

	/**
	 * @param allergyDescription the allergyDescription to set
	 */
	public void setAllergyDescription(String allergyDescription) {
		this.allergyDescription = allergyDescription;
	}

	/**
	 * @return the delFlag
	 */
	public boolean isDelFlag() {
		return delFlag;
	}

	/**
	 * @param delFlag the delFlag to set
	 */
	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	/**
	 * @return the dateCreated
	 */
	public LocalDate getDateCreated() {
		return dateCreated;
	}

	/**
	 * @param dateCreated the dateCreated to set
	 */
	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	/**
	 * @return the dateUpdated
	 */
	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	/**
	 * @param dateUpdated the dateUpdated to set
	 */
	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	/**
	 * @return the createdBy
	 */
	public Integer getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedBy
	 */
	public Integer getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

}
