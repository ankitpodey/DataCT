package com.impact.pms.master.MasterData;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @author LaveenaS
 * 
 * Main class to start the MasterApplication
 *
 */
@SpringBootApplication
@EnableDiscoveryClient
public class MasterDataApplication {
	
	private final static Logger logger = LoggerFactory.getLogger(MasterDataApplication.class);

	public static void main(String[] args) {
		logger.info("Bootstrapping MasterApplication (Inside main method)...");
		SpringApplication.run(MasterDataApplication.class, args);
	}

}