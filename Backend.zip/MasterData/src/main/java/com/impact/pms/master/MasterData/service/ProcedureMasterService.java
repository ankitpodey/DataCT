package com.impact.pms.master.MasterData.service;

import java.util.List;
import java.util.Map;

import com.impact.pms.master.MasterData.dto.ProcedureMasterDto;

/**
 * @author LaveenaS
 * Service class to define methods of ProcedureMaster service layer.
 *
 */
public interface ProcedureMasterService {

	List<ProcedureMasterDto> fetchProcedureMasterTableDetails();

	Map<Integer, ProcedureMasterDto> fetchProcedureMasterTableMapDetails();

}
