package com.impact.pms.master.MasterData.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

/**
 * @author LaveenaS
 * 
 *         This class is for configuring message source to display custom
 *         messages taken from env/properties file.
 *
 */
@Configuration
public class CustomMessageSourceConfiguration {

	private final static Logger logger = LoggerFactory.getLogger(CustomMessageSourceConfiguration.class);

	/**
	 * 
	 *         This method is for configuring message source to display custom
	 *         messages (for validation/response) taken from env/properties file.
	 *
	 */
	@Bean
	public MessageSource messageSource() {

		logger.info(
				"Inside CustomMessageSourceConfiguration class, messageSource method: Loading validation-error-message file. ");

		ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();

		messageSource.setBasenames("classpath:response-message", "classpath:validation-error-message");

		messageSource.setDefaultEncoding("UTF-8");

		return messageSource;
	}

	@Bean
	public LocalValidatorFactoryBean getValidator() {

		logger.info(
				"Inside CustomMessageSourceConfiguration class, getValidator method: Setting validation check message from  validation-error-message file. ");

		LocalValidatorFactoryBean bean = new LocalValidatorFactoryBean();
		
		bean.setValidationMessageSource(messageSource());

		return bean;
	}

}