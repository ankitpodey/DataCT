package com.impact.pms.master.MasterData.dto;

/**
 * @author LaveenaS
 * 
 * This is a DTO class that is used to fetch only speciality_master_id and speciality_name from Speciality Master table.
 *
 */
public class SpecialityMasterMapDto {
	
	private Integer specialityMasterId;

	private String specialityName;

	/**
	 * @return the specialityMasterId
	 */
	public Integer getSpecialityMasterId() {
		return specialityMasterId;
	}

	/**
	 * @param specialityMasterId the specialityMasterId to set
	 */
	public void setSpecialityMasterId(Integer specialityMasterId) {
		this.specialityMasterId = specialityMasterId;
	}

	/**
	 * @return the specialityName
	 */
	public String getSpecialityName() {
		return specialityName;
	}

	/**
	 * @param specialityName the specialityName to set
	 */
	public void setSpecialityName(String specialityName) {
		this.specialityName = specialityName;
	}

	public SpecialityMasterMapDto(Integer specialityMasterId, String specialityName) {
		super();
		this.specialityMasterId = specialityMasterId;
		this.specialityName = specialityName;
	}

	public SpecialityMasterMapDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "SpecialityMasterForPatientsDto [specialityMasterId=" + specialityMasterId + ", specialityName="
				+ specialityName + "]";
	}

}
