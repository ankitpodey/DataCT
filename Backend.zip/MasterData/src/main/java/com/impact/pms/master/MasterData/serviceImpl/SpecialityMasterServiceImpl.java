package com.impact.pms.master.MasterData.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.pms.master.MasterData.dto.SpecialityMasterDto;
import com.impact.pms.master.MasterData.dto.SpecialityMasterMapDto;
import com.impact.pms.master.MasterData.model.RoleMaster;
import com.impact.pms.master.MasterData.model.SpecialityMaster;
import com.impact.pms.master.MasterData.repository.SpecialityMasterRepository;
import com.impact.pms.master.MasterData.service.SpecialityMasterService;

/**
 * @author LaveenaS
 * 
 *         Service class to call repository method to read speciality master
 *         table contents
 *
 */
@Service
public class SpecialityMasterServiceImpl implements SpecialityMasterService {

	private final static Logger logger = LoggerFactory.getLogger(SpecialityMasterServiceImpl.class);

	@Autowired
	private SpecialityMasterRepository specialityMasterRepository;

	/**
	 * @return SpecialityMasterMapDto that contains data sent to front-end for
	 *         displaying in data table. This method calls repository method
	 *         (findAll) for reading speciality_master table details
	 *
	 */
	@Override
	public Map<Integer, String> fetchSpecialityMasterMapTableDetails() {

		logger.info("Inside SpecialityMasterServiceImpl fetchSpecialityMasterMapTableDetails method");

		Map<Integer, String> specialityMasterResultMap = new HashMap<>();

		List<SpecialityMaster> specialityMasterList = specialityMasterRepository.findAll();

		for (SpecialityMaster specialityMasterListRecord : specialityMasterList) {
			SpecialityMasterMapDto specialityMasterMapDto = new SpecialityMasterMapDto();
			BeanUtils.copyProperties(specialityMasterListRecord, specialityMasterMapDto);
			specialityMasterResultMap.put(specialityMasterMapDto.getSpecialityMasterId(),
					specialityMasterMapDto.getSpecialityName());
		}

		logger.info("Total number of active records in Speciality_Master table : " + specialityMasterResultMap.size());
		return specialityMasterResultMap;
	}

	/**
	 * @return List<SpecialityMasterDto> that contains data sent to front-end for
	 *         displaying in data table. This method calls repository method
	 *         (findAll) for reading Speciality_master table details and filters active records
	 *
	 */
	@Override
	public List<SpecialityMasterDto> fetchSpecialityMasterTableDetails() {
		
		logger.info("Inside SpecialityMasterServiceImpl fetchSpecialityMasterTableDetails method");

		List<SpecialityMasterDto> specialityMasterDtoList = new ArrayList<>();

		List<SpecialityMaster> specialityMasterList = specialityMasterRepository.findAll();

		// Copying properties from filtered records to Dto object
		specialityMasterList.forEach(specialityMasterRecord -> {
			SpecialityMasterDto specialityMasterDto = new SpecialityMasterDto();
			BeanUtils.copyProperties(specialityMasterRecord, specialityMasterDto);
			specialityMasterDtoList.add(specialityMasterDto);
		});

		logger.info("Total number of active records in Speciality_Master table : " + specialityMasterDtoList.size());
		return specialityMasterDtoList;
	}

	/**
	 * @return String (SpecialityName) for provided specialityMasterId
	 *
	 */
	@Override
	public String fetchSpecialityName(Integer specialityMasterId) {
		logger.info("Inside SpecialityMasterServiceImpl fetchSpecialityMasterTableDetails method");

		Optional<SpecialityMaster> specialityMasterRecord = specialityMasterRepository.findById(specialityMasterId);

		SpecialityMaster specialityMaster = specialityMasterRecord.get();

		String specialityName = specialityMaster.getSpecialityName();
		
		logger.info("Speciality name is fethed from DB ");
		
		return specialityName;
	}

}
