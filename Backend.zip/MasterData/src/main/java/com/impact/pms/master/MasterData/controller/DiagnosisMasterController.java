package com.impact.pms.master.MasterData.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.impact.pms.master.MasterData.dto.DiagnosisMasterDto;
import com.impact.pms.master.MasterData.service.DiagnosisMasterService;

import io.swagger.annotations.ApiOperation;

/**
 * @author LaveenaS
 * 
 *         This is a controller class that makes a call to service. URLs are
 *         mapped as /master as this is a master application and makes call to
 *         master schema tables through service layer.
 *
 */
@RestController
@RequestMapping("/master/diagnosis")
public class DiagnosisMasterController {

	@Autowired
	private DiagnosisMasterService diagnosisMasterService;

	private final static Logger logger = LoggerFactory.getLogger(DiagnosisMasterController.class);

	/**
	 * @author LaveenaS
	 * 
	 *         This method makes a get request to service layer to fetch diagnosis
	 *         master table details.
	 * @return ResponseEntity<List<DiagnosisMasterDto>> returns response status as
	 *         OK if all goes well.
	 *
	 */
	@GetMapping("/fetch-diagnosis-master-table-details")
	@ApiOperation(value = "to fetch diagnosis master table details")
	public ResponseEntity<List<DiagnosisMasterDto>> fetchDiagnosisMasterTableDetails() {

		List<DiagnosisMasterDto> diagnosisMasterDtoList = new ArrayList<>();

		logger.info("Inside fetchDiagnosisMasterTableDetails method ");

		diagnosisMasterDtoList = diagnosisMasterService.fetchDiagnosisMasterTableDetails();

		return ResponseEntity.ok(diagnosisMasterDtoList);

	}

	/**
	 * @return Map<Integer, DiagnosisMasterDto> that contains data sent to visit-ms
	 * for patient past visit endpoint
	 * 
	 *
	 */
	@GetMapping("/fetch-diagnosis-master-table-map-details")
	@ApiOperation(value = "to fetch diagnosis master table details for past visit details of patient")
	public ResponseEntity<Map<Integer, DiagnosisMasterDto>> fetchDiagnosisMasterTableMapDetails() {

		Map<Integer, DiagnosisMasterDto> diagnosisMasterDtoMap = new HashMap<>();

		logger.info("Inside fetchDiagnosisMasterTableMapDetails method ");

		diagnosisMasterDtoMap = diagnosisMasterService.fetchDiagnosisMasterTableMapDetails();

		return ResponseEntity.ok(diagnosisMasterDtoMap);

	}
}
