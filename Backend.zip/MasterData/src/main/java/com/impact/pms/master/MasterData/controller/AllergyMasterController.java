package com.impact.pms.master.MasterData.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.impact.pms.master.MasterData.dto.AllergyMasterDto;
import com.impact.pms.master.MasterData.model.AllergyMaster;
import com.impact.pms.master.MasterData.service.AllergyMasterService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * @author LaveenaS
 * 
 *         This is a controller class that makes a call to service. URLs are
 *         mapped as /master as this is a master application and makes call to
 *         master schema tables through service layer.
 *
 */
@RestController
@PropertySource("classpath:response-message.properties")
@RequestMapping("/master/allergy")
public class AllergyMasterController {

	@Autowired
	private AllergyMasterService allergyMasterService;

	private final static Logger logger = LoggerFactory.getLogger(AllergyMasterController.class);

	@Autowired
	private Environment env;

	@Autowired
	@Qualifier("AllergyMasterDtoValidator")
	private Validator allergyMasterDtoValidator;

	@InitBinder("allergyMasterDto")
	public void allergyMasterDtoInitBinder(WebDataBinder binder) {
		binder.setValidator(allergyMasterDtoValidator);
	}

	/**
	 * @author LaveenaS
	 * 
	 *         This method makes a get request to service layer to fetch only
	 *         specified Allergy master table details.
	 * @return ResponseEntity<Map<Integer, String>> returns response status as OK if
	 *         all goes well.
	 *
	 */
	@GetMapping("/fetch-allergy-master-map-details")
	@ApiOperation(value = "to fetch only specified Allergy master table details")
	public ResponseEntity<Map<Integer, String>> fetchAllergyMasterMapTableDetails() {

		Map<Integer, String> allergyMasterMap = new HashMap<>();

		logger.info("Inside fetchAllergyMasterMapTableDetails method ");

		allergyMasterMap = allergyMasterService.fetchAllergyMasterMapTableDetails();

		return ResponseEntity.ok(allergyMasterMap);

	}

	/**
	 * @author LaveenaS
	 * 
	 *         This method makes a get request to service layer to fetch Allergy
	 *         master table details.
	 * @return ResponseEntity<List<AllergyMasterDto>> returns response status as OK
	 *         if all goes well.
	 *
	 */
	@GetMapping("/fetch-allergy-master-table-details")
	@ApiOperation(value = "to fetch all Allergy master table details")
	public ResponseEntity<List<AllergyMasterDto>> fetchAllergyMasterTableDetails() {

		List<AllergyMasterDto> allergyMasterDtoList = new ArrayList<>();

		logger.info("Inside fetchAllergyMasterMapTableDetails method ");

		allergyMasterDtoList = allergyMasterService.fetchAllergyMasterTableDetails();

		return ResponseEntity.ok(allergyMasterDtoList);

	}

	/**
	 * Method for adding a new allergy record in master table
	 * 
	 * @param patient
	 * @return
	 */
	@PostMapping("/add-allergy")
	@ApiOperation(value = "to add a new allergy record in Allergy master table")
	public ResponseEntity<String> addAllergy(
			@ApiParam(value = "Contents of new allergy master record", required = true) @Validated @RequestBody AllergyMasterDto allergyMasterDto) {

		logger.info("Inside AllergyMasterController addAllergy method");

		AllergyMaster allergyMaster = allergyMasterService.addAllergy(allergyMasterDto);
		if (null != allergyMaster) {
			logger.info("New Allergy Record added successfully in master records.");
			return ResponseEntity.ok(env.getProperty("allergy.addition.success"));
		} else {
			logger.info("Failed to add New Allergy Record. Please try again later.");
			return ResponseEntity.ok(env.getProperty("allergy.addition.failure"));
		}

	}

}