package com.impact.pms.master.MasterData.dto;

/**
 * @author LaveenaS
 * 
 * This is a DTO class that is used to fetch details from Allergy Master table.
 *
 */
public class AllergyMasterDto {
	
	private Integer allergyMasterId;

	private String allergyType;

	private String allergyName;

	private String allergyDescription;

	/**
	 * @return the allergyMasterId
	 */
	public Integer getAllergyMasterId() {
		return allergyMasterId;
	}

	/**
	 * @param allergyMasterId the allergyMasterId to set
	 */
	public void setAllergyMasterId(Integer allergyMasterId) {
		this.allergyMasterId = allergyMasterId;
	}

	/**
	 * @return the allergyType
	 */
	public String getAllergyType() {
		return allergyType;
	}

	/**
	 * @param allergyType the allergyType to set
	 */
	public void setAllergyType(String allergyType) {
		this.allergyType = allergyType;
	}

	/**
	 * @return the allergyName
	 */
	public String getAllergyName() {
		return allergyName;
	}

	/**
	 * @param allergyName the allergyName to set
	 */
	public void setAllergyName(String allergyName) {
		this.allergyName = allergyName;
	}

	/**
	 * @return the allergyDescription
	 */
	public String getAllergyDescription() {
		return allergyDescription;
	}

	/**
	 * @param allergyDescription the allergyDescription to set
	 */
	public void setAllergyDescription(String allergyDescription) {
		this.allergyDescription = allergyDescription;
	}

}
