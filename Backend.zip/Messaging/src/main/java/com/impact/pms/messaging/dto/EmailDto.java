package com.impact.pms.messaging.dto;

/**
 * @author BhagyashriA
 *
 */
public class EmailDto {

	private String reciverEmailId;
	private String messageSubject;
	private String messageBody;

	public EmailDto() {
		super();
	}

	public EmailDto(String reciverEmailId, String messageSubject, String messageBody) {
		super();
		this.reciverEmailId = reciverEmailId;
		this.messageSubject = messageSubject;
		this.messageBody = messageBody;
	}

	public String getReciverEmailId() {
		return reciverEmailId;
	}

	public void setReciverEmailId(String reciverEmailId) {
		this.reciverEmailId = reciverEmailId;
	}

	public String getMessageSubject() {
		return messageSubject;
	}

	public void setMessageSubject(String messageSubject) {
		this.messageSubject = messageSubject;
	}

	public String getMessageBody() {
		return messageBody;
	}

	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}

	@Override
	public String toString() {
		return "ReciverEmail [reciverEmailId=" + reciverEmailId + ", MessageSubject=" + messageSubject
				+ ", messageBody=" + messageBody + "]";
	}

}
