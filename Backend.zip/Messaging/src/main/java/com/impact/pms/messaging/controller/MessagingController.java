package com.impact.pms.messaging.controller;

import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.impact.pms.messaging.dto.EmailDto;
import com.impact.pms.messaging.dto.ResponseMessageDto;
import com.impact.pms.messaging.model.Message;
import com.impact.pms.messaging.service.MessagingService;
import com.impact.pms.messaging.serviceImpl.SendEmailSevice;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * 
 * @author Bhagyashri Aher This is the controller class which is responsible for
 *         processing incoming REST API requests, preparing a model, and
 *         returning the view to be rendered as a response.
 *
 */
@RestController
@RequestMapping("/messaging")
@PropertySource("classpath:response-message.properties")
public class MessagingController {

	private final static Logger log = LoggerFactory.getLogger(MessagingController.class);

	@Autowired
	private MessagingService service;

	@Autowired
	private SendEmailSevice sendEmailSevice;
	
	@Autowired
	private Environment env;

	// getMyMessages
	@GetMapping("/messages/{receiverEmpId}")
	@ApiOperation(value = "To get messages by using sender id", notes = "To get messages by  sender id using  GET method")
	public ResponseEntity <List<Message>> getMessagesByReceiverId(
			@ApiParam(value = "To get messages by  sender id using  GET method")
			@PathVariable Integer receiverEmpId) {
		log.info("getting messages" + receiverEmpId);
		 List<Message> list = service.getMessagesByReceiverId(receiverEmpId);
		return ResponseEntity.ok(list);
	}

	// CreateMessage
	@PostMapping("/savemessage")
	@ApiOperation(value = "To create messages", notes = "To create messages  using  Post method")
	public ResponseEntity<ResponseMessageDto> saveMessage(
			@ApiParam(value = "To create messages  using  Post method") @RequestBody Message message) {
		log.info("saving messages" + message);
		Boolean isMessageSave = service.saveMessage(message);
		if(isMessageSave)
		return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("composeMessage.success"), true));
		return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("composeMessage.fail"), false));
		
	}

	
	
	// markMessageAsRead
	@PutMapping("/markreadmsg/{messageId}")
	@ApiOperation(value = "To Update messages and make read flag true ", notes = "To Update messages by using  PUT method")
	public ResponseEntity<ResponseMessageDto> markMemarkMessageAsRead(
			@ApiParam(value = "To Update messages by using  PUT method") @PathVariable Integer messageId) {
		log.info("mark message as read using id" + messageId);
		Boolean readMessages = service.markMessageAsRead(messageId);
		if(readMessages)
			return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("markAsRead.success"), true));
			return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("markAsRead.fail"), false));
	}

	// Send Email
	@PostMapping(value = "/sendemail")
	public ResponseEntity<Boolean> send(@RequestBody EmailDto reciver) {
		Boolean flag = false;
		try {
			sendEmailSevice.sendEmail(reciver);
			flag = true;
		} catch (Exception e) {
			// TODO: handle exception
			flag = false;

		}
//		sendingEmailApplication.sendEmailWithAttachment();
		return new ResponseEntity<Boolean>(flag, HttpStatus.OK);
	}

}
