package com.impact.pms.messaging.serviceImpl;

import java.io.File;
import java.io.IOException;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.impact.pms.messaging.dto.EmailDto;

/**
 * @author BhagyashriA
 *
 */
@Service
public class SendEmailSevice {

	@Autowired
	private JavaMailSender javaMailSender;

	private final static Logger log = LoggerFactory.getLogger(SendEmailSevice.class);


	// Normal Email
	public void sendEmail(EmailDto reciver) {

		SimpleMailMessage msg = new SimpleMailMessage();

		msg.setTo(reciver.getReciverEmailId());
		msg.setSubject(reciver.getMessageSubject());
		msg.setText(reciver.getMessageBody());

		try {
			log.info("sendinal mail with data"+msg.toString());
			javaMailSender.send(msg);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Email with Attachment
	void sendEmailWithAttachment() throws MessagingException, IOException {

		MimeMessage msg = javaMailSender.createMimeMessage();

		// true = multipart message
		MimeMessageHelper helper = new MimeMessageHelper(msg, true);

		helper.setTo("bpaher1994@gmail.com");

		helper.setSubject("Testing from Spring Boot");

		// default = text/plain
		// helper.setText("Check attachment for image!");

		// true = text/html
		helper.setText("<h1>Check attachment for image!</h1>", true);

		// hard coded a file path
		FileSystemResource file = new FileSystemResource(new File("C:/Users\\1302143\\Desktop\\ssl4.png"));

		helper.addAttachment("ssl4.png", file);

		javaMailSender.send(msg);

	}

}
