package com.impact.pms.messaging.constants;

public class ApplicationConstants {

	public static final String MeetingStatus_APPROVE= "A";
	public static final String MeetingStatus_REJECT= "R";
	
	//ROLE CONSTANTS	
	public static class Roles
	{
		public Roles() {
			
		}
	public static final Integer ROLE_ID_OF_ADMIN=1;
	public static final Integer ROLE_ID_OF_PHYSICIAN=2;
	public static final Integer ROLE_ID_OF_NURSE=3;
	public static final Integer ROLE_ID_OF_PATIENT=4;
	}

	
	
}
