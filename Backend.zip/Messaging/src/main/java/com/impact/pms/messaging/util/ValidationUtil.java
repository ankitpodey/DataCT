package com.impact.pms.messaging.util;

/**
 * 
 * @author Bhagyashri Aher
 * 
 */
public class ValidationUtil {
	private static boolean checkEmpty(String value) {
		if (value == null || value.trim().equalsIgnoreCase("NONE")
				|| value.trim().replaceAll("\\.", "").replaceAll("\\s+", "").equalsIgnoreCase("NA")
				|| value.trim().equalsIgnoreCase("NA") || value.trim().contains("N.A") || value.trim().contains("N.A.")
				|| value.trim().equalsIgnoreCase("NIL") || value.trim().isEmpty()) {
			return true;
		}
		return false;
	}

	public static boolean isStringNullOrEmpty(String string) {
		return checkEmpty(string) ? true : false;
	}

}
