package com.impact.pms.messaging.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "message", schema = "chat")
@ApiModel(description = "Details about Messaging Microservice")

public class Message {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty(notes = "Auto generated primary ID of Messaging")
	private Integer messageId;

	private Integer senderEmpId;

	private Integer receiverEmpId;

	private String messageSubject;

	@Transient
	private String senderEmpName;

	private String messageBody;

	private LocalDate messageCreatedTimeStamp;

	private boolean readFlag;

	private boolean delFlag;

	public Message() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Message(Integer messageId, Integer senderEmpId, Integer receiverEmpId, String messageSubject,
			String senderEmpName, String messageBody, LocalDate messageCreatedTimeStamp, boolean readFlag,
			boolean delFlag) {
		super();
		this.messageId = messageId;
		this.senderEmpId = senderEmpId;
		this.receiverEmpId = receiverEmpId;
		this.messageSubject = messageSubject;
		this.senderEmpName = senderEmpName;
		this.messageBody = messageBody;
		this.messageCreatedTimeStamp = messageCreatedTimeStamp;
		this.readFlag = readFlag;
		this.delFlag = delFlag;
	}

	public Integer getMessageId() {
		return messageId;
	}

	public void setMessageId(Integer messageId) {
		this.messageId = messageId;
	}

	public Integer getSenderEmpId() {
		return senderEmpId;
	}

	public void setSenderEmpId(Integer senderEmpId) {
		this.senderEmpId = senderEmpId;
	}

	public Integer getReceiverEmpId() {
		return receiverEmpId;
	}

	public void setReceiverEmpId(Integer receiverEmpId) {
		this.receiverEmpId = receiverEmpId;
	}

	public String getMessageSubject() {
		return messageSubject;
	}

	public void setMessageSubject(String messageSubject) {
		this.messageSubject = messageSubject;
	}

	public String getSenderEmpName() {
		return senderEmpName;
	}

	public void setSenderEmpName(String senderEmpName) {
		this.senderEmpName = senderEmpName;
	}

	public String getMessageBody() {
		return messageBody;
	}

	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}

	public LocalDate getMessageCreatedTimeStamp() {
		return messageCreatedTimeStamp;
	}

	public void setMessageCreatedTimeStamp(LocalDate messageCreatedTimeStamp) {
		this.messageCreatedTimeStamp = messageCreatedTimeStamp;
	}

	public boolean isReadFlag() {
		return readFlag;
	}

	public void setReadFlag(boolean readFlag) {
		this.readFlag = readFlag;
	}

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	@Override
	public String toString() {
		return "Message [messageId=" + messageId + ", senderEmpId=" + senderEmpId + ", receiverEmpId=" + receiverEmpId
				+ ", messageSubject=" + messageSubject + ", senderEmpName=" + senderEmpName + ", messageBody="
				+ messageBody + ", messageCreatedTimeStamp=" + messageCreatedTimeStamp + ", readFlag=" + readFlag
				+ ", delFlag=" + delFlag + "]";
	}

}
