package com.impact.pms.messaging.model;

import java.time.LocalDate;

public class PatientAllergy {
	
	
	private Integer patientAllergyId;

	private Integer patientId;

	private Integer allergyMasterId;

	private String allergyClinicalInformation;

	private boolean allergyFatal;

	private boolean delFlag;

	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;

	public PatientAllergy() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PatientAllergy(Integer patientAllergyId, Integer patientId, Integer allergyMasterId,
			String allergyClinicalInformation, boolean allergyFatal, boolean delFlag, LocalDate dateCreated,
			LocalDate dateUpdated, Integer createdBy, Integer updatedBy) {
		super();
		this.patientAllergyId = patientAllergyId;
		this.patientId = patientId;
		this.allergyMasterId = allergyMasterId;
		this.allergyClinicalInformation = allergyClinicalInformation;
		this.allergyFatal = allergyFatal;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}

	public Integer getPatientAllergyId() {
		return patientAllergyId;
	}

	public void setPatientAllergyId(Integer patientAllergyId) {
		this.patientAllergyId = patientAllergyId;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public Integer getAllergyMasterId() {
		return allergyMasterId;
	}

	public void setAllergyMasterId(Integer allergyMasterId) {
		this.allergyMasterId = allergyMasterId;
	}

	public String getAllergyClinicalInformation() {
		return allergyClinicalInformation;
	}

	public void setAllergyClinicalInformation(String allergyClinicalInformation) {
		this.allergyClinicalInformation = allergyClinicalInformation;
	}

	

	public boolean isAllergyFatal() {
		return allergyFatal;
	}

	public void setAllergyFatal(boolean allergyFatal) {
		this.allergyFatal = allergyFatal;
	}

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "PatientAllergy [patientAllergyId=" + patientAllergyId + ", patientId=" + patientId
				+ ", allergyMasterId=" + allergyMasterId + ", allergyClinicalInformation=" + allergyClinicalInformation
				+ ", allergyFatal=" + allergyFatal + ", delFlag=" + delFlag + ", dateCreated=" + dateCreated
				+ ", dateUpdated=" + dateUpdated + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + "]";
	}

	
	
	
}
