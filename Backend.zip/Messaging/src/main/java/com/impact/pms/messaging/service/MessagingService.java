package com.impact.pms.messaging.service;

import java.util.List;
import java.util.Map;

import com.impact.pms.messaging.model.Message;

/**
 * @author Bhagyashri Aher
 *  This service interface is an abstract type that
 *         contains a collection of methods
 */

public interface MessagingService {

	public List<Message> getMessagesByReceiverId(Integer receiverEmpId);

	public Boolean saveMessage(Message saveMessage);

	public Boolean markMessageAsRead(Integer messageId);

}
