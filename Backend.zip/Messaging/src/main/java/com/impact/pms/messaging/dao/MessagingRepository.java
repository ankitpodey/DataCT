package com.impact.pms.messaging.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.impact.pms.messaging.model.Message;

@Repository
public interface MessagingRepository extends JpaRepository<Message, Integer> {

	List<Message> findAllMessageByReceiverEmpIdAndReadFlag(Integer receiverEmpId, boolean readFlag);

	

}
