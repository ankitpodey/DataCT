package com.impact.pms.messaging.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.CreationTimestamp;


@Entity
@Table(name="appointment" ,schema = "consultation")
public class Appointment {

	//SELECT appointment_id, patient_id, doctor_id, appointment_title, appointment_description, appointment_date, appointment_time, appointment_status, reason_of_edit, del_flag, date_created, date_updated, created_by, updated_by
//	FROM consultation.appointment;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer  appointmentId;

	private Integer patientId;

	private Integer doctorId;

	private String appointmentTitle;

	private String appointmentDescription;

	@Transient
	private String practitionerName;

	private LocalDate appointmentDate;

	@Transient
	private String timeSlot;

	private String appointmentStatus;

	private String reasonOfEdit;

	private boolean delFlag;

	@CreationTimestamp
	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;

	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Appointment(Integer appointmentId, Integer patientId, Integer doctorId, String appointmentTitle,
			String appointmentDescription, String practitionerName, LocalDate appointmentDate, String timeSlot,
			String appointmentStatus, String reasonOfEdit, boolean delFlag, LocalDate dateCreated,
			LocalDate dateUpdated, Integer createdBy, Integer updatedBy) {
		super();
		this.appointmentId = appointmentId;
		this.patientId = patientId;
		this.doctorId = doctorId;
		this.appointmentTitle = appointmentTitle;
		this.appointmentDescription = appointmentDescription;
		this.practitionerName = practitionerName;
		this.appointmentDate = appointmentDate;
		this.timeSlot = timeSlot;
		this.appointmentStatus = appointmentStatus;
		this.reasonOfEdit = reasonOfEdit;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}

	
	public Integer getAppointmentId() {
		return appointmentId;
	}


	public void setAppointmentId(Integer appointmentId) {
		this.appointmentId = appointmentId;
	}


	public Integer getPatientId() {
		return patientId;
	}


	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}


	public Integer getDoctorId() {
		return doctorId;
	}


	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}


	public String getAppointmentTitle() {
		return appointmentTitle;
	}


	public void setAppointmentTitle(String appointmentTitle) {
		this.appointmentTitle = appointmentTitle;
	}


	public String getAppointmentDescription() {
		return appointmentDescription;
	}


	public void setAppointmentDescription(String appointmentDescription) {
		this.appointmentDescription = appointmentDescription;
	}


	public String getPractitionerName() {
		return practitionerName;
	}


	public void setPractitionerName(String practitionerName) {
		this.practitionerName = practitionerName;
	}


	public LocalDate getAppointmentDate() {
		return appointmentDate;
	}


	public void setAppointmentDate(LocalDate appointmentDate) {
		this.appointmentDate = appointmentDate;
	}


	public String getTimeSlot() {
		return timeSlot;
	}


	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}


	public String getAppointmentStatus() {
		return appointmentStatus;
	}


	public void setAppointmentStatus(String appointmentStatus) {
		this.appointmentStatus = appointmentStatus;
	}


	public String getReasonOfEdit() {
		return reasonOfEdit;
	}


	public void setReasonOfEdit(String reasonOfEdit) {
		this.reasonOfEdit = reasonOfEdit;
	}


	public boolean isDelFlag() {
		return delFlag;
	}


	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}


	public LocalDate getDateCreated() {
		return dateCreated;
	}


	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}


	public LocalDate getDateUpdated() {
		return dateUpdated;
	}


	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}


	public Integer getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}


	public Integer getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}


	@Override
	public String toString() {
		return "Appointment [appointmentId=" + appointmentId + ", patientId=" + patientId + ", doctorId=" + doctorId
				+ ", appointmentTitle=" + appointmentTitle + ", appointmentDescription=" + appointmentDescription
				+ ", practitionerName=" + practitionerName + ", appointmentDate=" + appointmentDate + ", timeSlot="
				+ timeSlot + ", appointmentStatus=" + appointmentStatus + ", reasonOfEdit=" + reasonOfEdit
				+ ", delFlag=" + delFlag + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated
				+ ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + "]";
	}


	

	

	
}
