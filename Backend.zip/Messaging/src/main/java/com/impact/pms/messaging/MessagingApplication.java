package com.impact.pms.messaging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * 
 * @author Bhagyashri Aher
 *
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class MessagingApplication {
	private final static Logger log = LoggerFactory.getLogger(MessagingApplication.class);

	public static void main(String[] args) {
		log.info("Inside messaging main method");
		SpringApplication.run(MessagingApplication.class, args);
	}

}
