package com.impact.pms.messaging.model;

import java.time.LocalDate;

public class MedicationMaster {
	
	private Integer medicationMasterId;

	private String medicationId;

	private String medicationName;

	private String medicationGenericName;

	private String medicationManufacturerName;

	private String medicationForm;

	private Integer medicationStrength;

	private boolean delFlag;

	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;

	public MedicationMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MedicationMaster(Integer medicationMasterId, String medicationId, String medicationName,
			String medicationGenericName, String medicationManufacturerName, String medicationForm,
			Integer medicationStrength, boolean delFlag, LocalDate dateCreated, LocalDate dateUpdated,
			Integer createdBy, Integer updatedBy) {
		super();
		this.medicationMasterId = medicationMasterId;
		this.medicationId = medicationId;
		this.medicationName = medicationName;
		this.medicationGenericName = medicationGenericName;
		this.medicationManufacturerName = medicationManufacturerName;
		this.medicationForm = medicationForm;
		this.medicationStrength = medicationStrength;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}

	public Integer getMedicationMasterId() {
		return medicationMasterId;
	}

	public void setMedicationMasterId(Integer medicationMasterId) {
		this.medicationMasterId = medicationMasterId;
	}

	public String getMedicationId() {
		return medicationId;
	}

	public void setMedicationId(String medicationId) {
		this.medicationId = medicationId;
	}

	public String getMedicationName() {
		return medicationName;
	}

	public void setMedicationName(String medicationName) {
		this.medicationName = medicationName;
	}

	public String getMedicationGenericName() {
		return medicationGenericName;
	}

	public void setMedicationGenericName(String medicationGenericName) {
		this.medicationGenericName = medicationGenericName;
	}

	public String getMedicationManufacturerName() {
		return medicationManufacturerName;
	}

	public void setMedicationManufacturerName(String medicationManufacturerName) {
		this.medicationManufacturerName = medicationManufacturerName;
	}

	public String getMedicationForm() {
		return medicationForm;
	}

	public void setMedicationForm(String medicationForm) {
		this.medicationForm = medicationForm;
	}

	public Integer getMedicationStrength() {
		return medicationStrength;
	}

	public void setMedicationStrength(Integer medicationStrength) {
		this.medicationStrength = medicationStrength;
	}

	
	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "MedicationMaster [medicationMasterId=" + medicationMasterId + ", medicationId=" + medicationId
				+ ", medicationName=" + medicationName + ", medicationGenericName=" + medicationGenericName
				+ ", medicationManufacturerName=" + medicationManufacturerName + ", medicationForm=" + medicationForm
				+ ", medicationStrength=" + medicationStrength + ", delFlag=" + delFlag + ", dateCreated=" + dateCreated
				+ ", dateUpdated=" + dateUpdated + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + "]";
	}

	
	
	
}
