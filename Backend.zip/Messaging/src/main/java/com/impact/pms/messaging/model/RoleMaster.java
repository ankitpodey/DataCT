package com.impact.pms.messaging.model;

import java.time.LocalDate;

public class RoleMaster {
	
	private Integer roleId;

	private String roleType;

	private String roleDescription;

	private boolean delFlag;

	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;

	public RoleMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RoleMaster(Integer roleId, String roleType, String roleDescription, boolean delFlag, LocalDate dateCreated,
			LocalDate dateUpdated, Integer createdBy, Integer updatedBy) {
		super();
		this.roleId = roleId;
		this.roleType = roleType;
		this.roleDescription = roleDescription;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getRoleType() {
		return roleType;
	}

	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	
	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "RoleMaster [roleId=" + roleId + ", roleType=" + roleType + ", roleDescription=" + roleDescription
				+ ", delFlag=" + delFlag + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated
				+ ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + "]";
	}

	
	
}
