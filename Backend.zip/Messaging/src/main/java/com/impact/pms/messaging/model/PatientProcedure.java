package com.impact.pms.messaging.model;

import java.time.LocalDate;

public class PatientProcedure {
	
	private Integer patientProcedureId;

	private Integer patientDiagnosisId;

	private Integer procedureMasterId;

	private boolean delFlag;

	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	public PatientProcedure() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PatientProcedure(Integer patientProcedureId, Integer patientDiagnosisId, Integer procedureMasterId,
			boolean delFlag, LocalDate dateCreated, LocalDate dateUpdated) {
		super();
		this.patientProcedureId = patientProcedureId;
		this.patientDiagnosisId = patientDiagnosisId;
		this.procedureMasterId = procedureMasterId;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
	}

	public Integer getPatientProcedureId() {
		return patientProcedureId;
	}

	public void setPatientProcedureId(Integer patientProcedureId) {
		this.patientProcedureId = patientProcedureId;
	}

	public Integer getPatientDiagnosisId() {
		return patientDiagnosisId;
	}

	public void setPatientDiagnosisId(Integer patientDiagnosisId) {
		this.patientDiagnosisId = patientDiagnosisId;
	}

	public Integer getProcedureMasterId() {
		return procedureMasterId;
	}

	public void setProcedureMasterId(Integer procedureMasterId) {
		this.procedureMasterId = procedureMasterId;
	}

	

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	@Override
	public String toString() {
		return "PatientProcedure [patientProcedureId=" + patientProcedureId + ", patientDiagnosisId="
				+ patientDiagnosisId + ", procedureMasterId=" + procedureMasterId + ", delFlag=" + delFlag
				+ ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated + "]";
	}

	
	
	


}
