package com.impact.pms.messaging.model;

import java.time.LocalDate;

public class PatientMedication {
	
	private Integer patientMedicationId;

	private Integer patientDiagnosisId;

	private Integer medicationMasterId;

	private String dosage;

	private boolean delFlag;

	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	public PatientMedication() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PatientMedication(Integer patientMedicationId, Integer patientDiagnosisId, Integer medicationMasterId,
			String dosage, boolean delFlag, LocalDate dateCreated, LocalDate dateUpdated) {
		super();
		this.patientMedicationId = patientMedicationId;
		this.patientDiagnosisId = patientDiagnosisId;
		this.medicationMasterId = medicationMasterId;
		this.dosage = dosage;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
	}

	public Integer getPatientMedicationId() {
		return patientMedicationId;
	}

	public void setPatientMedicationId(Integer patientMedicationId) {
		this.patientMedicationId = patientMedicationId;
	}

	public Integer getPatientDiagnosisId() {
		return patientDiagnosisId;
	}

	public void setPatientDiagnosisId(Integer patientDiagnosisId) {
		this.patientDiagnosisId = patientDiagnosisId;
	}

	public Integer getMedicationMasterId() {
		return medicationMasterId;
	}

	public void setMedicationMasterId(Integer medicationMasterId) {
		this.medicationMasterId = medicationMasterId;
	}

	public String getDosage() {
		return dosage;
	}

	public void setDosage(String dosage) {
		this.dosage = dosage;
	}

	

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	@Override
	public String toString() {
		return "PatientMedication [patientMedicationId=" + patientMedicationId + ", patientDiagnosisId="
				+ patientDiagnosisId + ", medicationMasterId=" + medicationMasterId + ", dosage=" + dosage
				+ ", delFlag=" + delFlag + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated + "]";
	}

	
	
}
