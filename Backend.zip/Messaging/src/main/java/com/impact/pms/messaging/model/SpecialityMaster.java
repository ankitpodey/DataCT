package com.impact.pms.messaging.model;

import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "speciality_master", schema = "master")
public class SpecialityMaster {

	@Id
	private Integer specialityMasterId;

	private String specialityName;

	private String specialityDescription;

	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;

	public SpecialityMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SpecialityMaster(Integer specialityMasterId, String specialityName, String specialityDescription,
			LocalDate dateCreated, LocalDate dateUpdated, Integer createdBy, Integer updatedBy) {
		super();
		this.specialityMasterId = specialityMasterId;
		this.specialityName = specialityName;
		this.specialityDescription = specialityDescription;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}

	public Integer getSpecialityMasterId() {
		return specialityMasterId;
	}

	public void setSpecialityMasterId(Integer specialityMasterId) {
		this.specialityMasterId = specialityMasterId;
	}

	public String getSpecialityName() {
		return specialityName;
	}

	public void setSpecialityName(String specialityName) {
		this.specialityName = specialityName;
	}

	public String getSpecialityDescription() {
		return specialityDescription;
	}

	public void setSpecialityDescription(String specialityDescription) {
		this.specialityDescription = specialityDescription;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "SpecialityMaster [specialityMasterId=" + specialityMasterId + ", specialityName=" + specialityName
				+ ", specialityDescription=" + specialityDescription + ", dateCreated=" + dateCreated + ", dateUpdated="
				+ dateUpdated + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + "]";
	}

}
