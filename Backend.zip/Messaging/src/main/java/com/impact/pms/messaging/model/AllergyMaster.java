package com.impact.pms.messaging.model;

import java.time.LocalDate;

public class AllergyMaster
{
	private Integer allergyMasterId;

	private String allergyType;

	private String allergyName;

	private String allergyDescription;

	private boolean delFlag;

	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;
	
	
	private Integer updatedBy;
	
	

	private Boolean allergyFatal;
	
	public AllergyMaster() {
		super();
	}
	
	public AllergyMaster(Integer allergyMasterId, String allergyType, String allergyName, String allergyDescription,
			boolean delFlag, LocalDate dateCreated, LocalDate dateUpdated, Integer createdBy, Integer updatedBy,
			Boolean allergyFatal) {
		super();
		this.allergyMasterId = allergyMasterId;
		this.allergyType = allergyType;
		this.allergyName = allergyName;
		this.allergyDescription = allergyDescription;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
		this.allergyFatal = allergyFatal;
	}

	public Integer getAllergyMasterId() {
		return allergyMasterId;
	}

	public void setAllergyMasterId(Integer allergyMasterId) {
		this.allergyMasterId = allergyMasterId;
	}

	public String getAllergyType() {
		return allergyType;
	}

	public void setAllergyType(String allergyType) {
		this.allergyType = allergyType;
	}

	public String getAllergyName() {
		return allergyName;
	}

	public void setAllergyName(String allergyName) {
		this.allergyName = allergyName;
	}

	public String getAllergyDescription() {
		return allergyDescription;
	}

	public void setAllergyDescription(String allergyDescription) {
		this.allergyDescription = allergyDescription;
	}

	

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Boolean getAllergyFatal() {
		return allergyFatal;
	}

	public void setAllergyFatal(Boolean allergyFatal) {
		this.allergyFatal = allergyFatal;
	}

	@Override
	public String toString() {
		return "AllergyMaster [allergyMasterId=" + allergyMasterId + ", allergyType=" + allergyType + ", allergyName="
				+ allergyName + ", allergyDescription=" + allergyDescription + ", delFlag=" + delFlag + ", dateCreated="
				+ dateCreated + ", dateUpdated=" + dateUpdated + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy
				+ ", allergyFatal=" + allergyFatal + "]";
	}

	

	
	
}
