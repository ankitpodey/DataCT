package com.impact.pms.messaging.model;

import java.time.LocalDate;

public class PatientDiagnosis {
	
	private Integer patientDiagnosisId;

	private Integer visitId;

	private Integer diagnosisMasterId;

	private boolean delFlag;

	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	public PatientDiagnosis() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PatientDiagnosis(Integer patientDiagnosisId, Integer visitId, Integer diagnosisMasterId, boolean delFlag,
			LocalDate dateCreated, LocalDate dateUpdated) {
		super();
		this.patientDiagnosisId = patientDiagnosisId;
		this.visitId = visitId;
		this.diagnosisMasterId = diagnosisMasterId;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
	}

	public Integer getPatientDiagnosisId() {
		return patientDiagnosisId;
	}

	public void setPatientDiagnosisId(Integer patientDiagnosisId) {
		this.patientDiagnosisId = patientDiagnosisId;
	}

	public Integer getVisitId() {
		return visitId;
	}

	public void setVisitId(Integer visitId) {
		this.visitId = visitId;
	}

	public Integer getDiagnosisMasterId() {
		return diagnosisMasterId;
	}

	public void setDiagnosisMasterId(Integer diagnosisMasterId) {
		this.diagnosisMasterId = diagnosisMasterId;
	}

	

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	@Override
	public String toString() {
		return "PatientDiagnosis [patientDiagnosisId=" + patientDiagnosisId + ", visitId=" + visitId
				+ ", diagnosisMasterId=" + diagnosisMasterId + ", delFlag=" + delFlag + ", dateCreated=" + dateCreated
				+ ", dateUpdated=" + dateUpdated + "]";
	}

	
	
}
