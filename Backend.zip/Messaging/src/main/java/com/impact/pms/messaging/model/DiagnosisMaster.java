package com.impact.pms.messaging.model;

import java.time.LocalDate;

public class DiagnosisMaster {
	
	private Integer diagnosisMasterId;

	private String diagnosisCode;

	private String diagnosisDescription;

	private String diagnosisType;

	private boolean diagnosisDepricatedFlag;

	private boolean delFlag;

	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;

	public DiagnosisMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DiagnosisMaster(Integer diagnosisMasterId, String diagnosisCode, String diagnosisDescription,
			String diagnosisType, boolean diagnosisDepricatedFlag, boolean delFlag, LocalDate dateCreated,
			LocalDate dateUpdated, Integer createdBy, Integer updatedBy) {
		super();
		this.diagnosisMasterId = diagnosisMasterId;
		this.diagnosisCode = diagnosisCode;
		this.diagnosisDescription = diagnosisDescription;
		this.diagnosisType = diagnosisType;
		this.diagnosisDepricatedFlag = diagnosisDepricatedFlag;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}

	public Integer getDiagnosisMasterId() {
		return diagnosisMasterId;
	}

	public void setDiagnosisMasterId(Integer diagnosisMasterId) {
		this.diagnosisMasterId = diagnosisMasterId;
	}

	public String getDiagnosisCode() {
		return diagnosisCode;
	}

	public void setDiagnosisCode(String diagnosisCode) {
		this.diagnosisCode = diagnosisCode;
	}

	public String getDiagnosisDescription() {
		return diagnosisDescription;
	}

	public void setDiagnosisDescription(String diagnosisDescription) {
		this.diagnosisDescription = diagnosisDescription;
	}

	public String getDiagnosisType() {
		return diagnosisType;
	}

	public void setDiagnosisType(String diagnosisType) {
		this.diagnosisType = diagnosisType;
	}

	
	public boolean isDiagnosisDepricatedFlag() {
		return diagnosisDepricatedFlag;
	}

	public void setDiagnosisDepricatedFlag(boolean diagnosisDepricatedFlag) {
		this.diagnosisDepricatedFlag = diagnosisDepricatedFlag;
	}

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "DiagnosisMaster [diagnosisMasterId=" + diagnosisMasterId + ", diagnosisCode=" + diagnosisCode
				+ ", diagnosisDescription=" + diagnosisDescription + ", diagnosisType=" + diagnosisType
				+ ", diagnosisDepricatedFlag=" + diagnosisDepricatedFlag + ", delFlag=" + delFlag + ", dateCreated="
				+ dateCreated + ", dateUpdated=" + dateUpdated + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy
				+ "]";
	}

	
	
	
}
