package com.impact.pms.messaging.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.pms.messaging.client.EmployeeFeignClient;
import com.impact.pms.messaging.dao.MessagingRepository;
import com.impact.pms.messaging.model.Message;
import com.impact.pms.messaging.service.MessagingService;

/**
 * 
 * @author Bhagyashri Aher This is implementation class of service interface
 *         where business logic is written
 *
 */
@Service
public class MessagingServiceImpl implements MessagingService {

	private final static Logger log = LoggerFactory.getLogger(MessagingServiceImpl.class);

	@Autowired
	private MessagingRepository repository;
	
	@Autowired
	private EmployeeFeignClient employeeFeignClient;
	@Override
	public  List<Message> getMessagesByReceiverId(Integer receiverEmpId) {
		
		List<Message> messagesByReceiverId = repository.findAllMessageByReceiverEmpIdAndReadFlag(receiverEmpId, false);
		List<Message> returnMessageList = new ArrayList<>();
		
		log.info("message list" + messagesByReceiverId);
		
		if(null !=messagesByReceiverId && messagesByReceiverId.size()>0 ) {

			String name = "";
			Map<Integer, String> employeeMap=employeeFeignClient.getMapOfPhyAndNurseForChat();
			for(Message messageRecieved : messagesByReceiverId) {
				messageRecieved.setSenderEmpName(employeeMap.get(messageRecieved.getSenderEmpId()));
				name = employeeMap.get(messageRecieved.getSenderEmpId());
				log.info("sender name : "+name);
				returnMessageList.add(messageRecieved);
			}
			
			
		}
		return returnMessageList;
	}

	@Override
	public Boolean saveMessage(Message saveMessage) {
		boolean isMessageSave=false;
		saveMessage = repository.save(saveMessage);
		log.info("save message" + saveMessage);
		isMessageSave =true;
		
		return isMessageSave;

		//return saveMessage;
	}

	@Override
	public Boolean markMessageAsRead(Integer messageId) {
		// msg ids -> use this to fetch msg row obj row object
		Optional<Message> optionalMessage = repository.findById(messageId);
		log.info("list of msgs" + optionalMessage);

	 Message message=optionalMessage.get();
	 message.setReadFlag(true);
		// save
		repository.save(message);
		log.info("update msg" + message);

		// return msgs;
		return true;
	}

}
