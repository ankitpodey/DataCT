//package com.impact.pms.messaging.service;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.mockito.Mockito.when;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.mockito.junit.MockitoJUnitRunner;
//import org.springframework.boot.test.context.SpringBootTest;
//import com.impact.pms.messaging.dao.MessagingRepository;
//import com.impact.pms.messaging.model.Message;
//import com.impact.pms.messaging.serviceImpl.MessagingServiceImpl;
//
//@SpringBootTest
//@RunWith(MockitoJUnitRunner.class)
//public class MessagingServiceTest {
//
//	@Mock
//	private MessagingRepository repository;
//
//	@InjectMocks
//	private MessagingServiceImpl service;
//
////	@Before
////	public void init() {
////		MockitoAnnotations.initMocks(this);
////	}
//
//	private List<Message> getMessagesList() {
//
//		List<Message> messagesBySenderId = new ArrayList();
//
//		Message m1 = new Message();
//		m1.setMessageBody("test");
//		m1.setReceiverEmpId(21);
//		m1.setSenderEmpId(11);
//		messagesBySenderId.add(m1);
//
//		Message m2 = new Message();
//		m2.setMessageBody("test1");
//		m2.setReceiverEmpId(21);
//		m2.setSenderEmpId(11);
//		messagesBySenderId.add(m2);
//
//		Message m3 = new Message();
//		m3.setMessageBody("test");
//		m3.setReceiverEmpId(31);
//		m3.setSenderEmpId(11);
//		messagesBySenderId.add(m3);
//
//		Message m4 = new Message();
//		m4.setMessageBody("test1");
//		m4.setReceiverEmpId(31);
//		m4.setSenderEmpId(11);
//		messagesBySenderId.add(m4);
//
//		return messagesBySenderId;
//			
//
//	}
//	
//	private List<Message> getMessagesMarkAsRead(){
//		List<Message> messages = new ArrayList();
//		Message m1 = new Message();
//		m1.setMessageId(1);
//		m1.setMessageBody("test");
//		m1.setReceiverEmpId(21);
//		m1.setSenderEmpId(11);
//		messages.add(m1);
//		Message m2 = new Message();
//		m2.setMessageId(2);
//		m2.setMessageBody("test1");
//		m2.setReceiverEmpId(21);
//		m2.setSenderEmpId(11);
//		messages.add(m2);
//		Message m3 = new Message();
//		m3.setMessageId(3);
//		m3.setMessageBody("test");
//		m3.setReceiverEmpId(31);
//		m3.setSenderEmpId(11);
//		messages.add(m3);
//		Message m4 = new Message();
//		m4.setMessageId(4);
//		m4.setMessageBody("test1");
//		m4.setReceiverEmpId(31);
//		m4.setSenderEmpId(11);
//		messages.add(m4);
//				
//
//		 return messages;
//	}
//
//	@Test
//	public void getMessagesBySenderId_WithSuccess() {
//		Integer senderEmpId = 11;
//		List<Message> messagesBySenderId = getMessagesList();
//
//		when(repository.findAllMessageBySenderEmpId(senderEmpId)).thenReturn(messagesBySenderId);
//
//		Map<Integer, List<Message>> map = service.getMessagesBySenderId(senderEmpId);
//
//		assertEquals(2, map.get(31).size());
//		assertEquals(2, map.get(21).size());
//
//	}
//	
//	
//	@Test
//	public void getMessagesBySenderId_Exception() {
//		Integer senderEmpId = 11;
//		
//
//		when(repository.findAllMessageBySenderEmpId(senderEmpId)).thenThrow(new RuntimeException());
//
//		 assertThrows(RuntimeException.class,()->service.getMessagesBySenderId(senderEmpId));
//
//		
//
//	}
//	
//	@Test
//	public void saveMessage_WithSuccess() {
//		List<Message> messagesBySenderId = getMessagesList();
//		Message message = messagesBySenderId.get(0);
//
//		when(repository.save(message)).thenReturn(message);
//
//		Message messageResponse = service.saveMessage(message);
//
//		assertEquals(message.getMessageId(), messageResponse.getMessageId());
//
//	}
//	
//	@Test
//	public void saveMessage_Exception() {
//		List<Message> messagesBySenderId = getMessagesList();
//		Message message = messagesBySenderId.get(0);
//
//		when(repository.save(message)).thenThrow(new RuntimeException());
//
//		 assertThrows(RuntimeException.class,()->service.saveMessage(message));
//
//	}
//	
//	
//	@Test
//	public void markMessageAsRead_WithSuccess() {
//		List<Integer> msgIds = new ArrayList<>();
//		msgIds.add(1);
//		msgIds.add(2);
//		msgIds.add(3);
//		msgIds.add(4);
//		List<Message> messagesBySenderId = getMessagesMarkAsRead();
//
//		when(repository.findAllById(msgIds)).thenReturn(messagesBySenderId);
//		when(repository.saveAll(messagesBySenderId)).thenReturn(messagesBySenderId);
//
//		List<Message> msgResponse = service.markMessageAsRead(msgIds);
//
//		assertEquals(msgIds.size(), msgResponse.size());
//		assertEquals(true, msgResponse.get(0).isReadFlag());
//
//	}
//	
//	
//	@Test
//	public void markMessageAsRead_WithException() {
//		List<Integer> msgIds = new ArrayList<>();
//		msgIds.add(1);
//		msgIds.add(2);
//		msgIds.add(3);
//		msgIds.add(4);
//
//		when(repository.findAllById(msgIds)).thenThrow(new RuntimeException());
//
//
//		assertThrows(RuntimeException.class,()->service.markMessageAsRead(msgIds));
//
//	}
//}
