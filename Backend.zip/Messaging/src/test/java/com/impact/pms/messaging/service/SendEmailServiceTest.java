
//package com.impact.pms.messaging.service;
//
//
//import static org.junit.Assert.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.mockito.Mockito.doNothing;
//import static org.mockito.Mockito.doThrow;
//import static org.mockito.Mockito.when;
//import static org.springframework.test.web.client.match.MockRestRequestMatchers.anything;
//
//import java.util.List;
//
//import javax.mail.internet.MimeMessage;
//
//import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.MockitoJUnitRunner;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.mail.SimpleMailMessage;
//import org.springframework.mail.javamail.JavaMailSender;
//
//import com.impact.pms.messaging.model.Message;
//import com.impact.pms.messaging.model.ReciverEmail;
//import com.impact.pms.messaging.serviceImpl.SendEmailSevice;
//
//@SpringBootTest
//@RunWith(MockitoJUnitRunner.class)
//public class SendEmailServiceTest {
//
//	@Mock
//	private JavaMailSender javaMailSender;
//	
//	@InjectMocks
//	private SendEmailSevice service;
//	
//	
//	
//	@Test
//	public void sendEmail_WithSuccess() {
//		ReciverEmail resEmail = new ReciverEmail("user@gmail.com","subject","Body");
//		
////       doNothing().when(javaMailSender).send((MimeMessage) any(MimeMessage.class));
//
//		 service.sendEmail(resEmail);
//
//		assertNotNull(resEmail);
//
//	}
//	
//	@Test
//	public void sendEmail_WithException() {
//
//		 assertThrows(RuntimeException.class,()->service.sendEmail(null));
//
//	}
//}
