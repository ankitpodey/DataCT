
//package com.impact.pms.messaging.controller;
//
//
//import static org.junit.Assert.assertEquals;
//import java.time.LocalDate;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
//import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.MediaType;
//import org.springframework.mock.web.MockHttpServletResponse;
//import org.springframework.test.context.junit4.SpringRunner;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.MockMvcBuilder;
//import org.springframework.test.web.servlet.MvcResult;
//import org.springframework.test.web.servlet.RequestBuilder;
//import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
//import org.springframework.test.web.servlet.setup.MockMvcBuilders;
//import org.springframework.web.client.RestTemplate;
//import org.springframework.web.context.WebApplicationContext;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.impact.pms.messaging.model.Message;
//import com.impact.pms.messaging.model.ReciverEmail;
//import com.impact.pms.messaging.service.MessagingService;
//import com.impact.pms.messaging.serviceImpl.SendEmailSevice;
//
////@RunWith(SpringRunner.class)
////@WebMvcTest(MessagingController.class)
//@AutoConfigureMockMvc
//@SpringBootTest
//
//public class MessagingControllerTest {
//
//	@MockBean
//	private MessagingService service;
//	
//	@MockBean
//	private SendEmailSevice emailservice;
//
//	@Mock
//	private RestTemplate resttemplatemock;
//
//	@Autowired
//	private WebApplicationContext wac;
//
//	@Autowired
//	private MockMvc mockMvc;
//	
//	@BeforeEach
//	public void init() {
//		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
//	}
//
//	@Test
//	public void saveMessageWhenSuccess() throws Exception {
//		LocalDate date = LocalDate.now();
//		Message msg = new Message(1, 2, 3, "subject", "Body", null, false, false);
//		//		(Integer messageId, Integer senderEmpId, Integer receiverEmpId, String messageSubject,
//		//				String messageBody, LocalDate messageCreatedTimeStamp, boolean readFlag, boolean delFlag
//
//		// Object mapper instance
//		ObjectMapper mapper = new ObjectMapper();
//
//		// Convert POJO to JSON
//		String json = mapper.writeValueAsString(msg);
//
//		// studentService.addCourse to respond back with mockCourse
//		Mockito.when(service.saveMessage(Mockito.any(Message.class))).thenReturn(msg);
//
//		// Send course as body to /students/Student1/courses
//		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/messaging/savemessage")
//				.content(json).contentType(MediaType.APPLICATION_JSON);
//
//		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
//
//		MockHttpServletResponse response = result.getResponse();
//
//		assertEquals(HttpStatus.OK.value(), response.getStatus());
//
//		assertEquals(json, response.getContentAsString());
//
//	}
//
//	
//
//
//	@Test
//	public void saveMessageWhenException() throws Exception {
//		LocalDate date = LocalDate.now();
//		Message msg = new Message(1, 2, 3, "subject", "Body", null, false, false);
//		//		(Integer messageId, Integer senderEmpId, Integer receiverEmpId, String messageSubject,
//		//				String messageBody, LocalDate messageCreatedTimeStamp, boolean readFlag, boolean delFlag
//
//		// Object mapper instance
//		ObjectMapper mapper = new ObjectMapper();
//
//		// Convert POJO to JSON
//		String json = mapper.writeValueAsString(msg);
//
//		// studentService.addCourse to respond back with mockCourse
//		Mockito.when(service.saveMessage(Mockito.any(Message.class))).thenThrow(new RuntimeException());
//
//		// Send course as body to /students/Student1/courses
//		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/messaging/savemessage")
//				.content(json).contentType(MediaType.APPLICATION_JSON);
//
//		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
//
//		MockHttpServletResponse response = result.getResponse();
//
//		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getStatus());
//
//
//	}
//
//
//
//
//	@Test
//	public void getMessagesBySenderIdWhenSuccess() throws Exception {
//		LocalDate date = LocalDate.now();
//		Map<Integer, List<Message>>  mapofmsg = new HashMap<>();
//		Message msg = new Message(1, 2, 3, "subject", "Body", null, false, false);
//		Message msg1 = new Message(1, 2, 3, "subject1", "Body1", null, false, false);
//		List<Message> msgList =new ArrayList<>();
//		msgList.add(msg);
//		msgList.add(msg1);
//		mapofmsg.put(3, msgList);
//		Message msg2 = new Message(1, 2, 4, "subject2", "Body2", null, false, false);
//		Message msg3 = new Message(1, 2, 4, "subject3", "Body3", null, false, false);
//		List<Message> msgList1 =new ArrayList<>();
//		msgList1.add(msg2);
//		msgList1.add(msg3);
//		mapofmsg.put(4, msgList1);
//		//		(Integer messageId, Integer senderEmpId, Integer receiverEmpId, String messageSubject,
//		//				String messageBody, LocalDate messageCreatedTimeStamp, boolean readFlag, boolean delFlag
//
//		// Object mapper instance
//		ObjectMapper mapper = new ObjectMapper();
//
//		// Convert POJO to JSON
//		String json = mapper.writeValueAsString(mapofmsg);
//
//		// studentService.addCourse to respond back with mockCourse
//		Mockito.when(service.getMessagesBySenderId(Mockito.anyInt())).thenReturn(mapofmsg);
//
//		// Send course as body to /students/Student1/courses
//		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/messaging/messages/2");
//
//		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
//
//		MockHttpServletResponse response = result.getResponse();
//
//		assertEquals(HttpStatus.OK.value(), response.getStatus());
//
//		assertEquals(json, response.getContentAsString());
//
//	}
//
//	@Test
//	public void getMessagesBySenderIdWhenException() throws Exception {
//		LocalDate date = LocalDate.now();
//
//		//		(Integer messageId, Integer senderEmpId, Integer receiverEmpId, String messageSubject,
//		//				String messageBody, LocalDate messageCreatedTimeStamp, boolean readFlag, boolean delFlag
//
//
//
//		// studentService.addCourse to respond back with mockCourse
//		Mockito.when(service.getMessagesBySenderId(Mockito.anyInt())).thenThrow(new RuntimeException());
//
//		// Send course as body to /students/Student1/courses
//		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/messaging/messages/2");
//
//		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
//
//		MockHttpServletResponse response = result.getResponse();
//
//
//		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getStatus());
//
//	}
//
//
//	@Test
//	public void markMemarkMessageAsReadWhenSuccess() throws Exception {
//		LocalDate date = LocalDate.now();
//		Message msg = new Message(1, 2, 3, "subject", "Body", null, true, false);
//		Message msg1 = new Message(2, 2, 3, "subject1", "Body1", null, true, false);
//		List<Message> msgList =new ArrayList<>();
//		msgList.add(msg);
//		msgList.add(msg1);
//		List<Integer> msgIds = new ArrayList<>();
//		msgIds.add(1);
//		msgIds.add(2);
//
//		//		(Integer messageId, Integer senderEmpId, Integer receiverEmpId, String messageSubject,
//		//				String messageBody, LocalDate messageCreatedTimeStamp, boolean readFlag, boolean delFlag
//
//		// Object mapper instance
//		ObjectMapper mapper = new ObjectMapper();
//
//		// Convert POJO to JSON
//		String jsonReponse = mapper.writeValueAsString(msgList);
//		
//
//		// Convert POJO to JSON
//		String jsonRequest = mapper.writeValueAsString(msgIds);
//
//		// studentService.addCourse to respond back with mockCourse
//		Mockito.when(service.markMessageAsRead(Mockito.anyList())).thenReturn(msgList);
//
//		RequestBuilder requestBuilder = MockMvcRequestBuilders.put("/messaging/markreadmsg")
//				.content(jsonRequest).contentType(MediaType.APPLICATION_JSON);
//
//
//		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
//
//		MockHttpServletResponse response = result.getResponse();
//
//		assertEquals(HttpStatus.OK.value(), response.getStatus());
//
//		assertEquals(jsonReponse, response.getContentAsString());
//
//	}
//	
//	@Test
//	public void markMemarkMessageAsReadWhenException() throws Exception {
//		List<Integer> msgIds = new ArrayList<>();
//		msgIds.add(1);
//		msgIds.add(2);
//
//		//		(Integer messageId, Integer senderEmpId, Integer receiverEmpId, String messageSubject,
//		//				String messageBody, LocalDate messageCreatedTimeStamp, boolean readFlag, boolean delFlag
//
//		// Object mapper instance
//		ObjectMapper mapper = new ObjectMapper();
//
//		// Convert POJO to JSON
//		String jsonRequest = mapper.writeValueAsString(msgIds);
//
//		// studentService.addCourse to respond back with mockCourse
//		Mockito.when(service.markMessageAsRead(Mockito.anyList())).thenThrow(new RuntimeException());
//
//		RequestBuilder requestBuilder = MockMvcRequestBuilders.put("/messaging/markreadmsg")
//				.content(jsonRequest).contentType(MediaType.APPLICATION_JSON);
//
//
//		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
//
//		MockHttpServletResponse response = result.getResponse();
//
//		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getStatus());
//
//
//	}
//	
//	@Test
//	public void testsend_whenEmailSentSuccessfully() throws Exception {
//		
//		ReciverEmail resEmail = new ReciverEmail("user@gmail.com","subject","Body");
//		
//		//String reciverEmailId, String messageSubject, String messageBody
//		
//		// Object mapper instance
//		ObjectMapper mapper = new ObjectMapper();
//
//		// Convert POJO to JSON
//		String json = mapper.writeValueAsString(resEmail);
//
//		// studentService.addCourse to respond back with mockCourse
//		//Mockito.when(emailservice.sendEmail(Mockito.any(ReciverEmail.class))).thenReturn();
//		Mockito.doNothing().when(emailservice).sendEmail(Mockito.any(ReciverEmail.class));
//
//		// Send course as body to /students/Student1/courses
//		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/messaging/sendemail")
//				.content(json).contentType(MediaType.APPLICATION_JSON);
//
//		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
//
//		MockHttpServletResponse response = result.getResponse();
//
//		assertEquals(HttpStatus.OK.value(), response.getStatus());
//
//		assertEquals("true", response.getContentAsString());
//
//	}
//
//	@Test
//	public void testsend_whenEmailSentThrowsException() throws Exception {
//		
//		ReciverEmail resEmail = new ReciverEmail("user@gmail.com","subject","Body");
//		
//		//String reciverEmailId, String messageSubject, String messageBody
//		
//		// Object mapper instance
//		ObjectMapper mapper = new ObjectMapper();
//
//		// Convert POJO to JSON
//		String json = mapper.writeValueAsString(resEmail);
//
//		// studentService.addCourse to respond back with mockCourse
//		//Mockito.when(emailservice.sendEmail(Mockito.any(ReciverEmail.class))).thenReturn();
//		Mockito.doThrow(new RuntimeException()).when(emailservice).sendEmail(Mockito.any(ReciverEmail.class));
//
//		// Send course as body to /students/Student1/courses
//		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/messaging/sendemail")
//				.content(json).contentType(MediaType.APPLICATION_JSON);
//
//		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
//
//		MockHttpServletResponse response = result.getResponse();
//
//		assertEquals(HttpStatus.OK.value(), response.getStatus());
//
//		assertEquals("false", response.getContentAsString());
//
//	}
//
//}

