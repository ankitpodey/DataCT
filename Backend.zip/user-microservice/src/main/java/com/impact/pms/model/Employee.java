package com.impact.pms.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.CreationTimestamp;

@Entity(name = "employee")
public class Employee {
	
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer employeeId;
	
	private String title;
	
	private String firstName;
	
	
	private String lastName;
	
	
	private String emailId;

	private LocalDate dateOfBirth;

	private String contactNumber;

	private String addressLineOne;

	private String addressLineTwo;

	private String addressStreet;

	private String addressLandmark;

	private String addressCity;

	private String addressState;

	private String addressCountry;

	private String addressZipCode;
	@CreationTimestamp
	private LocalDate dateCreated;
	
	private LocalDate dateUpdated;

	private Integer roleId;

	private boolean delFlag;

	private Integer createdBy;

	private Integer updatedBy;

	private Integer specialityMasterId;

	private Integer reportsTo;
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(Integer employeeId, String title, String firstName, String lastName, String emailId,
			LocalDate dateOfBirth, String contactNumber, String addressLineOne, String addressLineTwo,
			String addressStreet, String addressLandmark, String addressCity, String addressState,
			String addressCountry, String addressZipCode, LocalDate dateCreated, LocalDate dateUpdated, Integer roleId,
			boolean delFlag, Integer createdBy, Integer updatedBy, Integer specialityMasterId, Integer reportsTo) {
		super();
		this.employeeId = employeeId;
		this.title = title;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.dateOfBirth = dateOfBirth;
		this.contactNumber = contactNumber;
		this.addressLineOne = addressLineOne;
		this.addressLineTwo = addressLineTwo;
		this.addressStreet = addressStreet;
		this.addressLandmark = addressLandmark;
		this.addressCity = addressCity;
		this.addressState = addressState;
		this.addressCountry = addressCountry;
		this.addressZipCode = addressZipCode;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.roleId = roleId;
		this.delFlag = delFlag;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
		this.specialityMasterId = specialityMasterId;
		this.reportsTo = reportsTo;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getAddressLineOne() {
		return addressLineOne;
	}

	public void setAddressLineOne(String addressLineOne) {
		this.addressLineOne = addressLineOne;
	}

	public String getAddressLineTwo() {
		return addressLineTwo;
	}

	public void setAddressLineTwo(String addressLineTwo) {
		this.addressLineTwo = addressLineTwo;
	}

	public String getAddressStreet() {
		return addressStreet;
	}

	public void setAddressStreet(String addressStreet) {
		this.addressStreet = addressStreet;
	}

	public String getAddressLandmark() {
		return addressLandmark;
	}

	public void setAddressLandmark(String addressLandmark) {
		this.addressLandmark = addressLandmark;
	}

	public String getAddressCity() {
		return addressCity;
	}

	public void setAddressCity(String addressCity) {
		this.addressCity = addressCity;
	}

	public String getAddressState() {
		return addressState;
	}

	public void setAddressState(String addressState) {
		this.addressState = addressState;
	}

	public String getAddressCountry() {
		return addressCountry;
	}

	public void setAddressCountry(String addressCountry) {
		this.addressCountry = addressCountry;
	}

	public String getAddressZipCode() {
		return addressZipCode;
	}

	public void setAddressZipCode(String addressZipCode) {
		this.addressZipCode = addressZipCode;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Integer getSpecialityMasterId() {
		return specialityMasterId;
	}

	public void setSpecialityMasterId(Integer specialityMasterId) {
		this.specialityMasterId = specialityMasterId;
	}

	public Integer getReportsTo() {
		return reportsTo;
	}

	public void setReportsTo(Integer reportsTo) {
		this.reportsTo = reportsTo;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", title=" + title + ", firstName=" + firstName + ", lastName="
				+ lastName + ", emailId=" + emailId + ", dateOfBirth=" + dateOfBirth + ", contactNumber="
				+ contactNumber + ", addressLineOne=" + addressLineOne + ", addressLineTwo=" + addressLineTwo
				+ ", addressStreet=" + addressStreet + ", addressLandmark=" + addressLandmark + ", addressCity="
				+ addressCity + ", addressState=" + addressState + ", addressCountry=" + addressCountry
				+ ", addressZipCode=" + addressZipCode + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated
				+ ", roleId=" + roleId + ", delFlag=" + delFlag + ", createdBy=" + createdBy + ", updatedBy="
				+ updatedBy + ", specialityMasterId=" + specialityMasterId + ", reportsTo=" + reportsTo + "]";
	}

	


}
