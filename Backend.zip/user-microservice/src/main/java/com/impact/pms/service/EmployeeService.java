package com.impact.pms.service;

import com.impact.pms.model.Employee;

public interface EmployeeService {


	
	Employee updateEmployee(Employee employee);

	Employee findByEmailId(String emailId);
	
	
}
