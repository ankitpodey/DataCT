package com.impact.pms.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.impact.pms.model.Employee;

@Repository
public interface EmployeeRegistrationRepository extends JpaRepository<Employee, Integer> {

	Employee findByEmailId(String emailId);
	
	
}
