package com.impact.pms.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.impact.pms.dao.EmployeeRegistrationRepository;
import com.impact.pms.model.Employee;
import com.impact.pms.service.EmployeeService;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRegistrationRepository repository;
	
	


	@Override
	public Employee updateEmployee(Employee employee) {
		
		return repository.save(employee);
	}

	@Override
	public Employee findByEmailId(String emailId) {
		
		return repository.findByEmailId(emailId);
	}
	
	
	
}
