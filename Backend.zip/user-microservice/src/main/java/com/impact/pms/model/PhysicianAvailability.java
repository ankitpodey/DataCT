package com.impact.pms.model;

import java.time.LocalDate;

public class PhysicianAvailability {
	
	private String physicianAvailabilityId;

	private Integer employeeId;

	private String monday;

	private String tuesday;

	private String wednesday;

	private String thursday;

	private String friday;

	private String saturday;

	private String sunday;

	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;
	
	public PhysicianAvailability() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PhysicianAvailability(String physicianAvailabilityId, Integer employeeId, String monday, String tuesday,
			String wednesday, String thursday, String friday, String saturday, String sunday, LocalDate dateCreated,
			LocalDate dateUpdated, Integer createdBy, Integer updatedBy) {
		super();
		this.physicianAvailabilityId = physicianAvailabilityId;
		this.employeeId = employeeId;
		this.monday = monday;
		this.tuesday = tuesday;
		this.wednesday = wednesday;
		this.thursday = thursday;
		this.friday = friday;
		this.saturday = saturday;
		this.sunday = sunday;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}

	public String getPhysicianAvailabilityId() {
		return physicianAvailabilityId;
	}

	public void setPhysicianAvailabilityId(String physicianAvailabilityId) {
		this.physicianAvailabilityId = physicianAvailabilityId;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getMonday() {
		return monday;
	}

	public void setMonday(String monday) {
		this.monday = monday;
	}

	public String getTuesday() {
		return tuesday;
	}

	public void setTuesday(String tuesday) {
		this.tuesday = tuesday;
	}

	public String getWednesday() {
		return wednesday;
	}

	public void setWednesday(String wednesday) {
		this.wednesday = wednesday;
	}

	public String getThursday() {
		return thursday;
	}

	public void setThursday(String thursday) {
		this.thursday = thursday;
	}

	public String getFriday() {
		return friday;
	}

	public void setFriday(String friday) {
		this.friday = friday;
	}

	public String getSaturday() {
		return saturday;
	}

	public void setSaturday(String saturday) {
		this.saturday = saturday;
	}

	public String getSunday() {
		return sunday;
	}

	public void setSunday(String sunday) {
		this.sunday = sunday;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "PhysicianAvailability [physicianAvailabilityId=" + physicianAvailabilityId + ", employeeId="
				+ employeeId + ", monday=" + monday + ", tuesday=" + tuesday + ", wednesday=" + wednesday
				+ ", thursday=" + thursday + ", friday=" + friday + ", saturday=" + saturday + ", sunday=" + sunday
				+ ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated + ", createdBy=" + createdBy
				+ ", updatedBy=" + updatedBy + "]";
	}

	
	
}
