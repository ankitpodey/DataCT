package com.impact.pms.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.pms.dao.PatientRepository;
import com.impact.pms.model.Patient;
import com.impact.pms.service.PatientService;

@Service
public class PatientServiceImpl implements PatientService {

	@Autowired
	private PatientRepository repository;
	
	

	@Override
	public Patient updatePatient(Patient patient) {
	
		return repository.save(patient);
	}



	@Override
	public Patient findByEmailId(String emailId) {
		
		return repository.findByEmailId(emailId);
	}
	
	
	
	
}
