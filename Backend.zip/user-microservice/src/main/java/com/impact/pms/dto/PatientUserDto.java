package com.impact.pms.dto;

import java.time.LocalDate;

public class PatientUserDto {
	
	private Integer patientId;

	private String firstName;

	private String lastName;

	private String emailId;

	private LocalDate dateOfBirth;

	private Integer roleId;
	
	private boolean isActive;

	public PatientUserDto(Integer patientId, String firstName, String lastName, String emailId, LocalDate dateOfBirth,
			Integer roleId, boolean isActive) {
		super();
		this.patientId = patientId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.dateOfBirth = dateOfBirth;
		this.roleId = roleId;
		this.isActive = isActive;
	}

	public PatientUserDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	@Override
	public String toString() {
		return "PatientUserDto [patientId=" + patientId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", emailId=" + emailId + ", dateOfBirth=" + dateOfBirth + ", roleId=" + roleId + ", isActive="
				+ isActive + "]";
	}
	
	


}
