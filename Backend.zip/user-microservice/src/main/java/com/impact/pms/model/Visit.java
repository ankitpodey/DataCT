package com.impact.pms.model;

import java.time.LocalDate;

public class Visit {
	
	private Integer visitId;

	private Integer patientId;

	private Integer meetingId;

	private Integer doctorId;

	private Integer nurseId;

	private Double height;

	private Double weight;

	private String bloodPressure;

	private Double bodyTemperature;

	private Integer respirationRate;

	private boolean delFlag;

	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;

	public Visit() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Visit(Integer visitId, Integer patientId, Integer meetingId, Integer doctorId, Integer nurseId,
			Double height, Double weight, String bloodPressure, Double bodyTemperature, Integer respirationRate,
			boolean delFlag, LocalDate dateCreated, LocalDate dateUpdated, Integer createdBy, Integer updatedBy) {
		super();
		this.visitId = visitId;
		this.patientId = patientId;
		this.meetingId = meetingId;
		this.doctorId = doctorId;
		this.nurseId = nurseId;
		this.height = height;
		this.weight = weight;
		this.bloodPressure = bloodPressure;
		this.bodyTemperature = bodyTemperature;
		this.respirationRate = respirationRate;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}

	public Integer getVisitId() {
		return visitId;
	}

	public void setVisitId(Integer visitId) {
		this.visitId = visitId;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public Integer getMeetingId() {
		return meetingId;
	}

	public void setMeetingId(Integer meetingId) {
		this.meetingId = meetingId;
	}

	public Integer getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}

	public Integer getNurseId() {
		return nurseId;
	}

	public void setNurseId(Integer nurseId) {
		this.nurseId = nurseId;
	}

	public Double getHeight() {
		return height;
	}

	public void setHeight(Double height) {
		this.height = height;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getBloodPressure() {
		return bloodPressure;
	}

	public void setBloodPressure(String bloodPressure) {
		this.bloodPressure = bloodPressure;
	}

	public Double getBodyTemperature() {
		return bodyTemperature;
	}

	public void setBodyTemperature(Double bodyTemperature) {
		this.bodyTemperature = bodyTemperature;
	}

	public Integer getRespirationRate() {
		return respirationRate;
	}

	public void setRespirationRate(Integer respirationRate) {
		this.respirationRate = respirationRate;
	}

	

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "Visit [visitId=" + visitId + ", patientId=" + patientId + ", meetingId=" + meetingId + ", doctorId="
				+ doctorId + ", nurseId=" + nurseId + ", height=" + height + ", weight=" + weight + ", bloodPressure="
				+ bloodPressure + ", bodyTemperature=" + bodyTemperature + ", respirationRate=" + respirationRate
				+ ", delFlag=" + delFlag + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated
				+ ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + "]";
	}

	
	
	
}
