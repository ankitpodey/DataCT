package com.impact.pms.dto;

import java.time.LocalDate;

public class PatientRegistrationDto {
	
	private Integer patientId;
	
	private String title;

	private String firstName;

	private String lastName;

	private String emailId;

	private LocalDate dateOfBirth;

	private String contactNumber;
	
	private String confirmPassword;
	
	private String Password;
	
	

	public PatientRegistrationDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	@Override
	public String toString() {
		return "PatientRegistrationDto [patientId=" + patientId + ", title=" + title + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", emailId=" + emailId + ", dateOfBirth=" + dateOfBirth
				+ ", contactNumber=" + contactNumber + ", confirmPassword=" + confirmPassword + ", Password=" + Password
				+ "]";
	}

	
	

}
