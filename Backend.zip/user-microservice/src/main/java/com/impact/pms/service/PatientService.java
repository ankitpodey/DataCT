package com.impact.pms.service;

import com.impact.pms.model.Patient;

public interface PatientService {
	
	 
	
	Patient updatePatient(Patient patient);

	Patient findByEmailId(String emailId);
	

}
