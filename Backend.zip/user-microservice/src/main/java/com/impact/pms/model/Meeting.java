package com.impact.pms.model;

import java.time.LocalDate;

public class Meeting {
	
	private Integer meetingId;

	private Integer patientId;

	private Integer doctorId;

	private String meetingTitle;

	private String meetingDescription;

	private String practitionerName;

	private LocalDate meetingDate;

	private String timeSlot;

	private String meetingStatus;

	private String reasonOfEdit;

	private boolean delFlag;

	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;

	public Meeting() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Meeting(Integer meetingId, Integer patientId, Integer doctorId, String meetingTitle,
			String meetingDescription, String practitionerName, LocalDate meetingDate, String timeSlot,
			String meetingStatus, String reasonOfEdit, boolean delFlag, LocalDate dateCreated, LocalDate dateUpdated,
			Integer createdBy, Integer updatedBy) {
		super();
		this.meetingId = meetingId;
		this.patientId = patientId;
		this.doctorId = doctorId;
		this.meetingTitle = meetingTitle;
		this.meetingDescription = meetingDescription;
		this.practitionerName = practitionerName;
		this.meetingDate = meetingDate;
		this.timeSlot = timeSlot;
		this.meetingStatus = meetingStatus;
		this.reasonOfEdit = reasonOfEdit;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}

	public Integer getMeetingId() {
		return meetingId;
	}

	public void setMeetingId(Integer meetingId) {
		this.meetingId = meetingId;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public Integer getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}

	public String getMeetingTitle() {
		return meetingTitle;
	}

	public void setMeetingTitle(String meetingTitle) {
		this.meetingTitle = meetingTitle;
	}

	public String getMeetingDescription() {
		return meetingDescription;
	}

	public void setMeetingDescription(String meetingDescription) {
		this.meetingDescription = meetingDescription;
	}

	public String getPractitionerName() {
		return practitionerName;
	}

	public void setPractitionerName(String practitionerName) {
		this.practitionerName = practitionerName;
	}

	public LocalDate getMeetingDate() {
		return meetingDate;
	}

	public void setMeetingDate(LocalDate meetingDate) {
		this.meetingDate = meetingDate;
	}

	public String getTimeSlot() {
		return timeSlot;
	}

	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}

	public String getMeetingStatus() {
		return meetingStatus;
	}

	public void setMeetingStatus(String meetingStatus) {
		this.meetingStatus = meetingStatus;
	}

	public String getReasonOfEdit() {
		return reasonOfEdit;
	}

	public void setReasonOfEdit(String reasonOfEdit) {
		this.reasonOfEdit = reasonOfEdit;
	}

	

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "Meeting [meetingId=" + meetingId + ", patientId=" + patientId + ", doctorId=" + doctorId
				+ ", meetingTitle=" + meetingTitle + ", meetingDescription=" + meetingDescription
				+ ", practitionerName=" + practitionerName + ", meetingDate=" + meetingDate + ", timeSlot=" + timeSlot
				+ ", meetingStatus=" + meetingStatus + ", reasonOfEdit=" + reasonOfEdit + ", delFlag=" + delFlag
				+ ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated + ", createdBy=" + createdBy
				+ ", updatedBy=" + updatedBy + "]";
	}

	

	
}
