package com.impact.pms.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.impact.pms.dto.ChangePasswordDto;
import com.impact.pms.dto.ResponseMessageDto;
import com.impact.pms.service.UserService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/user")
@PropertySource("classpath:response-message.properties")
public class UserController {

		@Autowired
		UserService service;
		
		@Autowired
		Environment env;
		
		private static final Logger log =  LoggerFactory.getLogger(UserController.class);
		
		/**
		 * Endpoint to check if email is already registered
		 * @param emailId
		 * @return
		 */
		@ApiOperation(value = "check if email registered", notes = "get method to check id email already registered in system")
		@GetMapping("/check-if-email-already-exists/{emailId}")	//to check email exist
		public ResponseEntity<Boolean> checkIfEmailAlreadyExists(@ApiParam(value = "emailId", required = true)
		@PathVariable String emailId)
		{	
			boolean result = service.checkIfEmailAlreadyExists(emailId);
			return ResponseEntity.ok(result);
		}
		
		/**
		 * Endpoint to unlock user
		 * @param emailId
		 * @return
		 */
		@ApiOperation(value = "unlock user", notes = "get method to unlock user, in case profile is locked after 3 unsuccessful attempts")
		@GetMapping("/unlock-user/{emailId}")
		public ResponseEntity<ResponseMessageDto> unlockUser(@ApiParam(value = "emailId", required = true)
		@PathVariable String emailId)
		{
			boolean result = service.unlockUser(emailId);
			if(result)
				return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("unlock.user.success"), true));
			return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("unlock.user.fail"), false));
		}
		
		/**
		 * Endpoint to disable user
		 * @param emailId
		 * @return
		 */
		@ApiOperation(value = "disable user", notes = "put method to disable/deactivate an user account")
		@GetMapping("/disable-user/{emailId}")
		public ResponseEntity<ResponseMessageDto> disableUser(@ApiParam(value = "emailId", required = true)@PathVariable String emailId)
		{
			boolean result = service.disableUser(emailId);
			if(result)
				return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("disable.user.success"), true));
			return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("disable.user.fail"), false));
		
		}
		
		/**
		 * Endpoint to disable user
		 * @param emailId
		 * @return
		 */
		@ApiOperation(value = "disable user", notes = "put method to disable/deavtivate an user account")
		@GetMapping("/enable-user/{emailId}")
		public ResponseEntity<ResponseMessageDto> enableUser(@ApiParam(value = "emailId", required = true)@PathVariable String emailId)
		{
			boolean result = service.enableUser(emailId);
			if(result)
				return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("enable.user.success"), true));
			return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("enable.user.fail"), false));
		
		}
		
		/**
		 * Endpoint to change user password
		 * @param changePasswordDto
		 * @return
		 */
		@ApiOperation(value = "change password by respective user", notes = "post method to change password by user logged in")
		@PostMapping("/change-password")
		public ResponseEntity<ResponseMessageDto> changePassword(@ApiParam(value = "changePassword object consisting of current password new password", required = true)
		@RequestBody ChangePasswordDto changePasswordDto){
			boolean result = service.changePassword(changePasswordDto);
			if(result) 
				return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("change.password.success"), true));
			return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("change.password.wrongpassword"), false));
				
		}
		
		/**
		 * Endpoint to reset password
		 * @param employeeId
		 * @return
		 */
		@ApiOperation(value = "reset password", notes = "get method to reset password of an user by admin")
		@GetMapping("/forgot-password/{emailId}")
		public ResponseEntity<ResponseMessageDto> resetPassword(@ApiParam(value = "Email Id of user", required = true) 
		@PathVariable("emailId") String emailId){
			log.info("in resetPassword "+ emailId);
			boolean result = service.resetPassword(emailId);
			if(result)
				return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("reset.password.success"), true));
			return ResponseEntity.ok(new ResponseMessageDto(env.getProperty("reset.password.fail"), false));
		}
	
}
