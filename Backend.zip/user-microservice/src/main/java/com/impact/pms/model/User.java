package com.impact.pms.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Entity
@Table(name = "user", schema = "useradministration")
@ApiModel(description = "details about User entity")
public class User {
	
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@ApiModelProperty(notes = "identifier for User entity")
	private Integer userId;

	private Integer roleId;

	private String emailId;

	private String password;

	private boolean delFlag;

	private Integer noOfWrongPasswordAttempts;

	private boolean isActive;
	
	@ CreationTimestamp
	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(Integer userId, Integer roleId, String emailId, String password, boolean delFlag,
			Integer noOfWrongPasswordAttempts, boolean isActive, LocalDate dateCreated, LocalDate dateUpdated) {
		super();
		this.userId = userId;
		this.roleId = roleId;
		this.emailId = emailId;
		this.password = password;
		this.delFlag = delFlag;
		this.noOfWrongPasswordAttempts = noOfWrongPasswordAttempts;
		this.isActive = isActive;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public Integer getNoOfWrongPasswordAttempts() {
		return noOfWrongPasswordAttempts;
	}

	public void setNoOfWrongPasswordAttempts(Integer noOfWrongPasswordAttempts) {
		this.noOfWrongPasswordAttempts = noOfWrongPasswordAttempts;
	}

	

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", roleId=" + roleId + ", emailId=" + emailId + ", password=" + password
				+ ", delFlag=" + delFlag + ", noOfWrongPasswordAttempts=" + noOfWrongPasswordAttempts + ", isActive="
				+ isActive + ", dateCreated=" + dateCreated + ", dateUpdated=" + dateUpdated + "]";
	}

	

}
