package com.impact.pms.model;

import java.time.LocalDate;

public class ProcedureMaster {
	
	private Integer procedureMasterId;

	private String procedureCode;

	private String procedureDescription;

	private String procedureApproach;

	private boolean procedureDepricatedFlag;

	private boolean delFlag;

	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	private Integer createdBy;

	private Integer updatedBy;

	public ProcedureMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProcedureMaster(Integer procedureMasterId, String procedureCode, String procedureDescription,
			String procedureApproach, boolean procedureDepricatedFlag, boolean delFlag, LocalDate dateCreated,
			LocalDate dateUpdated, Integer createdBy, Integer updatedBy) {
		super();
		this.procedureMasterId = procedureMasterId;
		this.procedureCode = procedureCode;
		this.procedureDescription = procedureDescription;
		this.procedureApproach = procedureApproach;
		this.procedureDepricatedFlag = procedureDepricatedFlag;
		this.delFlag = delFlag;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
	}

	public Integer getProcedureMasterId() {
		return procedureMasterId;
	}

	public void setProcedureMasterId(Integer procedureMasterId) {
		this.procedureMasterId = procedureMasterId;
	}

	public String getProcedureCode() {
		return procedureCode;
	}

	public void setProcedureCode(String procedureCode) {
		this.procedureCode = procedureCode;
	}

	public String getProcedureDescription() {
		return procedureDescription;
	}

	public void setProcedureDescription(String procedureDescription) {
		this.procedureDescription = procedureDescription;
	}

	public String getProcedureApproach() {
		return procedureApproach;
	}

	public void setProcedureApproach(String procedureApproach) {
		this.procedureApproach = procedureApproach;
	}

	
	public boolean isProcedureDepricatedFlag() {
		return procedureDepricatedFlag;
	}

	public void setProcedureDepricatedFlag(boolean procedureDepricatedFlag) {
		this.procedureDepricatedFlag = procedureDepricatedFlag;
	}

	public boolean isDelFlag() {
		return delFlag;
	}

	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "ProcedureMaster [procedureMasterId=" + procedureMasterId + ", procedureCode=" + procedureCode
				+ ", procedureDescription=" + procedureDescription + ", procedureApproach=" + procedureApproach
				+ ", procedureDepricatedFlag=" + procedureDepricatedFlag + ", delFlag=" + delFlag + ", dateCreated="
				+ dateCreated + ", dateUpdated=" + dateUpdated + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy
				+ "]";
	}

	
	
	
}
