package com.impact.pms.serviceImpl;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.impact.pms.client.MessagingFeignClient;
import com.impact.pms.constants.ApplicationConstants.Roles;
import com.impact.pms.dao.UserRepository;
import com.impact.pms.dto.ChangePasswordDto;
import com.impact.pms.dto.EmailDto;
import com.impact.pms.model.Employee;
import com.impact.pms.model.Patient;
import com.impact.pms.model.User;
import com.impact.pms.service.EmployeeService;
import com.impact.pms.service.PatientService;
import com.impact.pms.service.UserService;
import com.impact.pms.util.GeneratePassword;

@Service
public class UserServiceImpl implements UserService {

	private final static Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
	
	@Autowired
	private UserRepository repository;

	@Autowired
	private PatientService patientService;

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	BCryptPasswordEncoder bCryptPassEnco;
	
	@Autowired
	private MessagingFeignClient messagingFeignClient;
	
	@Override
	public boolean checkIfEmailAlreadyExists(String emailId) {
		boolean emailExist=false;
		try {
			User user = repository.findByEmailId(emailId);
			if(user!=null)
			{
				emailExist= true;
			}
		}catch(Exception e)
		{
			e.getMessage();		
		}
		return emailExist;
	}

	@Override
	public boolean unlockUser(String emailId) {

		boolean userUnlocked= false;
		try {

			User user= repository.findByEmailId(emailId);
			user.setActive(true);
			user.setNoOfWrongPasswordAttempts(0);
			repository.save(user);
			userUnlocked=true;

		}
		catch(Exception e)
		{
			e.getMessage();
		}
		return userUnlocked;
	}

	@Override
	public boolean disableUser(String emailId) {
		boolean userDisabled= false;
		User user = repository.findByEmailId(emailId);
		user.setDelFlag(true);
		log.info("user "+ user);
		try
		{
			
			if(user.getRoleId()==Roles.ROLE_ID_OF_PATIENT )
			{
				Patient patient=patientService.findByEmailId(emailId);
				log.info("patient "+patient);
				patient.setDelFlag(true);
				patientService.updatePatient(patient);
				
			}
			else
			{
				Employee employee=employeeService.findByEmailId(emailId);
				employee.setDelFlag(true);
				employeeService.updateEmployee(employee);

			}
			userDisabled=true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return userDisabled;
	}

	@Override
	public boolean changePassword(ChangePasswordDto changePasswordDto) {
		
		User user = new User();
		boolean result = false;
		//fetch saved password
		Optional<User> optionalUser = repository.findById(changePasswordDto.getUserId());
		user = optionalUser.get();
		
		//check if password sent matches
		boolean oldPassMatch = bCryptPassEnco.matches(changePasswordDto.oldPassword, user.getPassword());
		//update password in case old password provided is correct
		if(oldPassMatch) {
			//encrypt new password and save to user object
			user.setPassword(bCryptPassEnco.encode(changePasswordDto.getNewPassword()));
			//set wrong attempts to 0
			user.setNoOfWrongPasswordAttempts(0);
			//persist user object
			repository.save(user);
			result = true;
		}
		
		return result;
	}

	@Override
	public boolean resetPassword(String emailId) {
		User user = new User();
		boolean result = false;
		
		//fetch user object
		Optional<User> optionalUser = repository.findUserByEmailId(emailId);
		user = optionalUser.get();
		
		//generate password
		String newPassword = GeneratePassword.generateDefaultPassword(10);
		
		//encrypt password
		String newEncodedPassword = bCryptPassEnco.encode(newPassword);
		user.setPassword(newEncodedPassword);
		
		//email new password
		EmailDto emailDto = new EmailDto();
		emailDto.setReciverEmailId(user.getEmailId());
		emailDto.setMessageBody("Your new password is: " + newPassword + " .Please login using this password.");
		emailDto.setMessageSubject("Password reset successful");
		messagingFeignClient.send(emailDto);
		
		//persist user object
		repository.save(user);
		result = true;
		
		return result;
	}

	@Override
	public boolean enableUser(String emailId) {
		boolean userEnabled= false;
		User user = repository.findByEmailId(emailId);
		user.setDelFlag(true);
		try
		{
			if(user.getRoleId()==Roles.ROLE_ID_OF_PATIENT )
			{
				Patient patient=patientService.findByEmailId(emailId);
				patient.setDelFlag(false);
				patientService.updatePatient(patient);

			}
			else
			{
				Employee employee=employeeService.findByEmailId(emailId);
				employee.setDelFlag(false);
				employeeService.updateEmployee(employee);

			}
			userEnabled=true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return userEnabled;
	}

	






}
