package com.impact.pms.service;

import com.impact.pms.dto.ChangePasswordDto;

public interface UserService {
	

	boolean checkIfEmailAlreadyExists(String emailId);

	boolean unlockUser(String emailId);

	boolean disableUser(String emailId);

	boolean changePassword(ChangePasswordDto changePasswordDto);

	boolean resetPassword(String emailId);

	boolean enableUser(String emailId);

	

}
