package com.impact.pms.security.SecurityApp.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

/**
 * @author LaveenaS
 * 
 * This is entity class for User table of database.
 *
 */
@Entity
@Table(name = "user", schema = "useradministration")
public class UserEntity implements Serializable {

	private static final long serialVersionUID = 7720322620742087013L;

	@Id
	private Integer userId;

	private Integer roleId;

	private String emailId;

	private String password;

	private boolean delFlag;

	private Integer noOfWrongPasswordAttempts;

	private boolean isActive;

	@CreationTimestamp
	private LocalDate dateCreated;

	private LocalDate dateUpdated;

	/**
	 * @return the userId
	 */
	public Integer getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	/**
	 * @return the roleId
	 */
	public Integer getRoleId() {
		return roleId;
	}

	/**
	 * @param roleId the roleId to set
	 */
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the delFlag
	 */
	public boolean isDelFlag() {
		return delFlag;
	}

	/**
	 * @param delFlag the delFlag to set
	 */
	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}

	/**
	 * @return the noOfWrongPasswordAttempts
	 */
	public Integer getNoOfWrongPasswordAttempts() {
		return noOfWrongPasswordAttempts;
	}

	/**
	 * @param noOfWrongPasswordAttempts the noOfWrongPasswordAttempts to set
	 */
	public void setNoOfWrongPasswordAttempts(Integer noOfWrongPasswordAttempts) {
		this.noOfWrongPasswordAttempts = noOfWrongPasswordAttempts;
	}

	/**
	 * @return the isActive
	 */
	public boolean isActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the dateCreated
	 */
	public LocalDate getDateCreated() {
		return dateCreated;
	}

	/**
	 * @param dateCreated the dateCreated to set
	 */
	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	/**
	 * @return the dateUpdated
	 */
	public LocalDate getDateUpdated() {
		return dateUpdated;
	}

	/**
	 * @param dateUpdated the dateUpdated to set
	 */
	public void setDateUpdated(LocalDate dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

}