package com.impact.pms.security.SecurityApp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 * @author LaveenaS
 * 
 * Main class to start the SecurityApplication
 *
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class SecurityAppApplication {
	
	private final static Logger logger = LoggerFactory.getLogger(SecurityAppApplication.class);
	
	/**
	 * 
	 * Bean created for password encryption
	 *
	 */
	@Bean
	public BCryptPasswordEncoder bCryptPasswordEncoder()
	{
		return new BCryptPasswordEncoder();
	}
	
	/**
	 * 
	 * Main method
	 *
	 */
	public static void main(String[] args) {
		logger.info("Bootstrapping SecurityAppApplication (Inside main method)...");
		SpringApplication.run(SecurityAppApplication.class, args);
	}

}
