package com.impact.pms.security.SecurityApp.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.impact.pms.security.SecurityApp.dto.UserDto;

/**
 * @author LaveenaS
 * Interface that extends form UserDetailsService which is provided by spring security for Jpa-authorization.
 *
 */
public interface UserService extends UserDetailsService{

	UserDto getUserDetailsByemailId(String emailId);
	
}