package com.impact.pms.security.SecurityApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.impact.pms.security.SecurityApp.model.UserEntity;

/**
 * @author LaveenaS
 * Repository interface that connects to useradministration.user table.
 *
 */
@Repository
public interface UserRepository extends JpaRepository<UserEntity, Integer> {

	UserEntity findByEmailId(String emailId);

}
