package com.impact.pms.security.SecurityApp.client;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @author LaveenaS 
 * Interface to make a call to Employee microservice through
 *         feign client.
 *
 */
@FeignClient("employee-ms")
public interface EmployeeFeignClient {

	@GetMapping("/employee/get-employee-info-map/{userId}")
	public Map<String, Object> getEmployeeInfoMap(@PathVariable("userId") Integer userId);

}
