package com.impact.pms.security.SecurityApp.dto;

/**
 * @author LaveenaS
 * 
 * This class represents the login model. It contains fields email and password that are received from user from front-end.
 *
 */
public class LoginRequestModelDto {
	
	private String emailId;

	private String password;

	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

}
