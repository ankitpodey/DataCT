package com.impact.pms.security.SecurityApp.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @author LaveenaS
 * Interface to make a call to master microservice through feign client.
 *
 */
@FeignClient("masterapp-ms")
public interface MasterFeignClient {
	
	@GetMapping("/master/role/fetch-role-name/{roleMasterId}")
	public String fetchRoleName(@PathVariable("roleMasterId") Integer roleMasterId);

}