package com.impact.pms.security.SecurityApp.client;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @author LaveenaS
 * Interface to make a call to Patient microservice through feign client.
 *
 */
@FeignClient("patient-ms")
public interface PatientFeignClient {
	
	@GetMapping("/patient/get-patient-info-map/{userId}")
	public Map<String, Object> getPatietInfoMap(@PathVariable("userId") Integer userId);

}
