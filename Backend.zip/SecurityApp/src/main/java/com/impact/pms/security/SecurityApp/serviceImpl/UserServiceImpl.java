package com.impact.pms.security.SecurityApp.serviceImpl;

import java.util.ArrayList;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.impact.pms.security.SecurityApp.dto.UserDto;
import com.impact.pms.security.SecurityApp.model.UserEntity;
import com.impact.pms.security.SecurityApp.repository.UserRepository;
import com.impact.pms.security.SecurityApp.service.UserService;

/**
 * @author LaveenaS
 * Default service imlementation provided by spring security
 */
@Service
public class UserServiceImpl implements UserService {

	UserRepository userRepository;
	BCryptPasswordEncoder bCryptPasswordEncoder;
	Environment environment;
	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	public UserServiceImpl(UserRepository userRepository, BCryptPasswordEncoder bCryptPasswordEncoder,
			Environment environment) {
		this.userRepository = userRepository;
		this.bCryptPasswordEncoder = bCryptPasswordEncoder;
		this.environment = environment;
	}

	/**
	 * 
	 * This method is provoked by athentication manager for comparing the request values with Database values.
	 */
	@Override
	public UserDetails loadUserByUsername(String emailId) throws UsernameNotFoundException {

		UserEntity userEntity = userRepository.findByEmailId(emailId);
		if (userEntity == null)
			throw new UsernameNotFoundException(emailId);

		return new User(userEntity.getEmailId(), userEntity.getPassword(), true, true, true, true, new ArrayList<>());

	}

	/**
	 * 
	 * This method fetches list of email Ids from Database for comparison.
	 */
	@Override
	public UserDto getUserDetailsByemailId(String emailId) {
		UserEntity userEntity = userRepository.findByEmailId(emailId);

		if (userEntity == null)
			throw new UsernameNotFoundException(emailId);
		return new ModelMapper().map(userEntity, UserDto.class);
	}

}
