package com.impact.pms.security.SecurityApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
