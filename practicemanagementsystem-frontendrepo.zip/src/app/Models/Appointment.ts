export class Appointment
{
        public appointmentId: number;
        public appointmentTitle: string;
        public appointmentDescription : string;
        public appointmentDate : Date;
        public appointmentTime : string;
        public reasonOfEdit : string;
        public specialityMasterId : number;
        public physicianId : number;

        //
        public appointmentStatus :string;
        public patientId :number;
        public physicianName: string;

        constructor() { }

}