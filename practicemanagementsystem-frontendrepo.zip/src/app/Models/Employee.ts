import { PhysicianAvailability } from "./PhysicianAvailability";
import { User } from "./User";

export class Employee
{
        public employeeId: number;
        public title: string;
        public firstName : string;
        public lastName :string;
        public emailId : string;
        public contactNumber : string;
        public dateOfBirth : Date;

        public addressLineOne: string;
        public addressLineTwo: string;
        public addressStreet : string;
        public addressLandmark : string;
        public addressCity : string;
        public addressState : string;
        public addressCountry : string;
        public addressZipCode : string;

        public roleId : number;
        public role : string;

        public specialityMasterId : number;
        public speciality : string;

        public reportsTo : number;

        public physicianAvailability: PhysicianAvailability;
        public user: User;
         
       constructor() { }
}