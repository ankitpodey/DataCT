export class PatientProcedure
{

        public procedureMasterId : number;    
        public procedureCode : string;
        public procedureDescription : string;
        public procedureApproach : string;
        public visitId : string;
        
        constructor(){}
}