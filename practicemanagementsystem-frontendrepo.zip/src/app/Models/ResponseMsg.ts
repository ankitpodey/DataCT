export class ResponseMsg{
    
    public msg : string;
    public successFlag : boolean;

    // constructor(msg:string, successFlag:boolean){
    //     this.msg = msg;
    //     this.successFlag=successFlag;
    // }
    constructor(){

    }
  
}