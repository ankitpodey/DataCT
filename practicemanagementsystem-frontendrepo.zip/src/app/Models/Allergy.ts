export class Allergy{
    
    public patientAllergyId : number;
    public patientId : number;
    public allergyClinicalInformation : string;
    public allergyMasterId : number;
    public allergyFatal : boolean;
    public allergyName: string;


    constructor(){

    }
}