export class PatientMedication
{
        public medicationMasterId: number;    
        public medicationId: string;
        public medicationGenericName : string;
        public medicationManufacturerName : string;
        public medicationForm : string;
        public medicationStrength : string;
        public dosage: string;
        public visitId : number;
        public medicationName : string;
       
        constructor(){}
}