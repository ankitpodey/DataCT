export class EmergencyContact{

    public patientEmergencyContactId : number;
    public patientId : number;
    public firstName : string;
    public lastName : string;
    public relationship : string;
 
    public emailId : string;
    public contactNumber : string;
    public addressLineOne : string;
    public addressLineTwo : string;
    public addressStreet : string;
    public addressLandmark : string;
    public addressCity : string;
    public addressState : string;
    public addressCountry : string;
    public addressZipCode : string;
    public portalAccessFlag : boolean;
    constructor(){

    }



}