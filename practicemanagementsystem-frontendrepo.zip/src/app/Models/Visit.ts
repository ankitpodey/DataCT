import { PatientDiagnosis } from "./PatientDiagnosis";
import { PatientMedication } from "./PatientMedication";
import { PatientProcedure } from "./PatientProcedure";

export class Visit
{
        public visitId: number;
        public patientId: number;
        public appointmentId: number;
        public physicianId: number;
        public nurseId: number;
        public height : number;
        public weight :number;
        public bloodPressure : string;
        public bodyTemperature : number;
        public respirationRate : number;

        public physicianName: string;
        public nurseName: string; 
        public diagnosisdto: PatientDiagnosis[];
        public medicationdto: PatientMedication[];
        public proceduredto: PatientProcedure[];
       

       
        constructor(){}
}