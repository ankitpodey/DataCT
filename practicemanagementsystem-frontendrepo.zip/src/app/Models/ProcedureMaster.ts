export class ProcedureMaster {

    
    public procedureMasterId : number;
    public procedureCode : string;
    public procedureDescription : string;
    public procedureApproach : string;
    public procedureDepricatedFlag : boolean;
    public delFlag :boolean;
   

    constructor(){

    }


}