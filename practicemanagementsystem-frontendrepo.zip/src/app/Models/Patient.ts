import { Allergy } from "./Allergy";
import { EmergencyContact } from "./EmergencyContact";

export class Patient{

    public patientId : number;
    public title : string;
    public firstName : string;
    public lastName : string;
    public emailId : string;
    public dateOfBirth : Date;
    public contactNumber : string;
    public gender : string;
    public race : string;
    public ethinicity : string;
    public languagesKnown : string;
    public addressLineOne : string;
    public addressLineTwo : string;
    public addressStreet : string;
    public addressLandmark : string;
    public addressCity : string;
    public addressState : string;
    public addressCountry : string;
    public addressZipCode : string;
    public verificationFlag : boolean;
    public password : string;
    public confirmPassword : string;
    
    public relationship :string;
    //for allergies
    public patientAllergies : Allergy[];

    //for emergency contact 
    public patientEmergencyContact : EmergencyContact;

    constructor(){

    }
}