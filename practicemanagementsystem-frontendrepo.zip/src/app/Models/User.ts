export class User
{
    public role : string = "";
        public userId : number = 0;
        public roleId : number = 0;
        public emailId : string = "";
        public password : string = "";
        public noOfWrongPasswordAttempts : number = 0;
        public oldPassword = "";
        public newPassword = "";

    constructor(){
    }
}