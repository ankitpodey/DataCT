export class ComposeMessage {

    public messageId: number;
    public senderEmpId: number;
    public receiverEmpId: number;
    public messageSubject: String;
    public messageBody: String;
    constructor() {

    }
}