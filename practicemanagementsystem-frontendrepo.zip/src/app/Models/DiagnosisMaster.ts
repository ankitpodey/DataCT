export class DiagnosisMaster {

    
    public diagnosisMasterId : number;
    public diagnosisCode : number;
    public diagnosisDescription : string;
    public diagnosisType : number;
    public diagnosisDepricatedFlag : boolean;
   

    constructor(){

    }


}