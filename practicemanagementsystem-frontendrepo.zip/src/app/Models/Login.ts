export class Login
{
        public emailId : string = "";
        public password : string = "";

    constructor(){
    }
}