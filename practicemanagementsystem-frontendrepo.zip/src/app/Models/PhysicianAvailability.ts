export class PhysicianAvailability
{
        public mondayFrom : string = "";
        public mondayTo : string = "";
        public tuesdayFrom : string = "";
        public tuesdayTo : string = "";
        public wednesdayFrom : string = "";
        public wednesdayTo : string = "";
        public thursdayFrom : string = "";
        public thursdayTo : string = "";
        public fridayFrom : string = "";
        public fridayTo : string = "";
        public saturdayFrom : string = "";
        public saturdayTo : string = "";
        public sundayFrom : string = "";
        public sundayTo : string = "";

constructor(){}


}



