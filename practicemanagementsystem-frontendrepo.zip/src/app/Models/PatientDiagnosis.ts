export class PatientDiagnosis {
        public visitId: number;
        public patientDiagnosisId: number;
        public diagnosisMasterId: number;
        public diagnosisDescription: string;
        public diagnosisCode: string;
        public diagnosisType: string;
        constructor() { }
}