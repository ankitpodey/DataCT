export class MedicationMaster {

    
    public medicationMasterId : number;
    public medicationName : string;
    public medicationGenericName : string;
    public medicationManufacturerName : string;
    public medicationForm : string;
    public medicationStrength :string;
   

    constructor(){

    }


}