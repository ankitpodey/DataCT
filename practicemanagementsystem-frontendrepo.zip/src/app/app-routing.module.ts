import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './Modules/user/login/login.component';
import { SharedWrapperComponent } from './Modules/sharedwrapper/shared-wrapper/shared-wrapper.component';
import { RegisterPatientComponent } from './Modules/user/register-patient/register-patient.component';
import { ForgotpasswordComponent } from './Modules/user/forgotpassword/forgotpassword.component';

const routes: Routes = [

  {
    path: "",
    component: LoginComponent
  },
  {
    path: "register",
    component: RegisterPatientComponent
  },
  {
    path: "forgotpassword",
    component: ForgotpasswordComponent
  },
  {
    path: "home",
    component: SharedWrapperComponent,
    loadChildren: () => import('./Modules/sharedwrapper/sharedwrapper.module').then(m => m.SharedwrapperModule)
  },
  {
    path: "**",
    redirectTo : ""
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {enableTracing :false})],
  exports: [RouterModule]
})

export class AppRoutingModule { }
