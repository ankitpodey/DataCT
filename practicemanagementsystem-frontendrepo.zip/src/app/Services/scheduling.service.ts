import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Appointment } from '../Models/Appointment';

@Injectable({
  providedIn: 'root'
})
export class SchedulingService {

  constructor(private http: HttpClient) { }

  public scheduleAppointment(meeting: any): Observable<any> 
  {
    return this.http.post<any>('http://localhost:5001/scheduling-ms/scheduling/save-appointment', meeting);
  }

  public fetchTwoMonthsUpcomingAppointmnetForPhysician(physicianId: number): Observable<any> 
  {
    return this.http.get<any>('http://localhost:5001/scheduling-ms/scheduling/physician/fetch-two-months-upcoming-appointmnets-for-physician/' + physicianId);
  }

  public GetUpcomingAppointmentForPatient(patientId: number): Observable<any> 
  {
    //return this.http.get<any>('http://localhost:5001/scheduling-ms/scheduling//fetch-upcoming-appointment-for-patient-user/' + patientId);
    return this.http.get<any>('http://localhost:5001/scheduling-ms/scheduling/fetch-upcoming-appointment-for-patient-user/' + patientId);
  }

  public GetIncomingAppointment(employeeId: number): Observable<any> 
  {
    return this.http.get<any>('http://localhost:5001/scheduling-ms/scheduling/fetch-incoming-appointment-for-physician/' + employeeId);
  }

  public acceptAppointment(appointmentId: number): Observable<any> 
  {
    return this.http.get<any>('http://localhost:5001/scheduling-ms/scheduling/accept-appointment/' + appointmentId);
  }

  public rejectAppointment(appointmentId: number): Observable<any> 
  {
    return this.http.get<any>('http://localhost:5001/scheduling-ms/scheduling/reject-appointment/' + appointmentId);
  }

  public GetUpcomingAppointmentForNurse(nurseId: number): Observable<any> 
  {
    return this.http.get<any>('http://localhost:5001/scheduling-ms/scheduling/nurse/fetch-todays-upcoming-appointment-for-nurse/' + nurseId);
  }

  public fetchTodaysUpcomingAppointmentForPhysician(physicianId: number): Observable<Appointment[]> 
  {
        return this.http.get<Appointment[]>('http://localhost:5001/scheduling-ms/scheduling/physician/fetch-todays-upcoming-appointment-for-physician/' + physicianId);
  }

  public fetchTodaysUpcomingAppointmentForNurse(nurseId: number): Observable<Appointment[]> 
  {
    return this.http.get<Appointment[]>('http://localhost:5001/scheduling-ms/scheduling/nurse/fetch-todays-upcoming-appointment-for-nurse/' + nurseId);
  }

}
