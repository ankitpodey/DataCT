import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Appointment } from '../Models/Appointment';
import { ResponseMsg } from '../Models/ResponseMsg';
import { Visit } from '../Models/Visit';

@Injectable({
  providedIn: 'root'
})
export class VisitService {

  constructor(private httpClient:HttpClient) { }

  public GetPatientDiagnosisDetails():Observable<any>{
    return this.httpClient.get<any>("http://localhost:5001/masterapp-ms/master/diagnosis/fetch-diagnosis-master-table-details");
  }

  public GetPatientProcedureDetails():Observable<any>{
    return this.httpClient.get<any>("http://localhost:5001/masterapp-ms/master/diagnosis/fetch-diagnosis-master-table-details");
  }
  public GetPatientMedicationDetails():Observable<any>{
    return this.httpClient.get<any>("http://localhost:5001/masterapp-ms/master/diagnosis/fetch-diagnosis-master-table-details");
  }
  public GetPatientVisitDetails(appointmentId :number):Observable<any>{
    return this.httpClient.get<any>("http://localhost:5001/visit-ms/visit/get-visit-detail/"+appointmentId);
  }
  public fetchAppointment(appointmentId: number): Observable<Appointment> {
    return this.httpClient.get<Appointment>('http://localhost:5001/scheduling-ms/scheduling/get-appointment/' + appointmentId);
}
  public addVisit(visit:Visit): Observable<ResponseMsg>{
    return this.httpClient.post<ResponseMsg>('http://localhost:5001/visit-ms/visit/capture-visit', visit);
  }

}
