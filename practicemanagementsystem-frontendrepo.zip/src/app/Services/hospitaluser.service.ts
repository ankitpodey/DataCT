import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from '../Models/Employee';

@Injectable({
  providedIn: 'root'
})
export class HospitaluserService {

  constructor(private http: HttpClient) { }

  public getHospitalUserProfile(employeeId: number): Observable<any>
  {
    return this.http.get<any>('http://localhost:5001/employee-ms/employee/' + employeeId);
  }

  public updateHospitalUserProfile(employee: Employee): Observable<Employee>
  {
    return this.http.put<Employee>('http://localhost:5001/employee-ms/employee/', employee);
  }

  // public getHospitalUserSpeciality(specialityMasterId: number): Observable<any>
  // {
  //   return this.http.get<any>('http://localhost:5001/masterapp-ms/master/speciality/fetch-speciality-name/' + specialityMasterId);
  //   // {responseType: 'text'});
  //   //{responseType?: 'text'});
  // }

  public getHospitalUserSpeciality(): Observable<any> 
  {
    return this.http.get<any>('http://localhost:5001/masterapp-ms/master/speciality/fetch-speciality-master-map-details');
  }

  public getHospitalUserRoleName(): Observable<any>
  {
    return this.http.get<any>('http://localhost:5001/masterapp-ms/master/role/fetch-role-master-map-details');
  }
  
}
