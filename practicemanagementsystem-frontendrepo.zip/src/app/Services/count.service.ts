import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CountService {
 

  constructor(private http: HttpClient) { }

  public getNumberOfPatients(): Observable<any>
  {
    return this.http.get<any>('http://localhost:5001/patient-ms/patient/patient-user-count');
  }

  public getNumberOfEmployees(): Observable<any>
  {
    return this.http.get<any>('http://localhost:5001/employee-ms/employee/employee-user-count');
  }

  public getNumberOfAppointmentsToday(): Observable<any>
  {
    return this.http.get<any>('http://localhost:5001/scheduling-ms/scheduling/fetch-appointment-count-today');
  }

  public getNumberOfAppointmentsTillDate(): Observable<any>
  {
    return this.http.get<any>('http://localhost:5001/scheduling-ms/scheduling/fetch-appointment-count-till-date');
  }

  public getNumberOfAppointmentsTillDateForPatient(patientId: number) : Observable<any> {
    return this.http.get<any>('http://localhost:5001/scheduling-ms/scheduling/get-count-of-patient-appointment/'+patientId);
  }
  
}
