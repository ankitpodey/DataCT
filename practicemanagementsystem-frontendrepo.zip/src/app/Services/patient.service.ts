import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Patient } from '../Models/Patient';
import { catchError } from 'rxjs/operators';
import {  throwError } from 'rxjs';
import { ResponseMsg } from '../Models/ResponseMsg';
import { Visit } from '../Models/Visit';

@Injectable({
  providedIn: 'root'
})
export class PatientService {

  constructor(private httpClient: HttpClient) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  public getPatientById(patientId: number): Observable<any> //Patient []
  {
    return this.httpClient.get<any>('http://localhost:5001/patient-ms/patient/'+patientId)
    
  }

  updatePatient( patient:any): Observable<ResponseMsg> 
  {
    return this.httpClient.put<ResponseMsg>('http://localhost:5001/patient-ms/patient/', patient)
    
  }

  public getPastVisitDetails(patientId:number):Observable<Visit[]>{
    return this.httpClient.get<Visit[]>("http://localhost:5001/visit-ms/visit/past-visit-details/" + patientId);
  }
  
 
  
}


