import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from '../Models/Employee';
import { Patient } from '../Models/Patient';
import { ResponseMsg } from '../Models/ResponseMsg';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private httpClient:HttpClient) { }

  public getAllPatientUsers():Observable<Patient[]>{
    return this.httpClient.get<Patient[]>("http://localhost:5001/patient-ms/patient/fetch-all");
  }

  public getAllHospitalUsers():Observable<Employee[]>{
    return this.httpClient.get<Employee[]>("http://localhost:5001/employee-ms/employee/fetch-all");
  }

  //function to deactivate user
  public disableUser(emailId:string):Observable<ResponseMsg>{
    return this.httpClient.get<ResponseMsg>("http://localhost:5001/user-ms/user/disable-user/"+ emailId);
  }


  //function activate user
  public enableUser(emailId:string):Observable<ResponseMsg>{
    return this.httpClient.get<ResponseMsg>("http://localhost:5001/user-ms/user/enable-user/"+ emailId);
  }


  //function to unlock user
  public unlockUser(emailId:string):Observable<ResponseMsg>{
    return this.httpClient.get<ResponseMsg>("http://localhost:5001/user-ms/user/unlock-user/"+emailId);
  }

  //function to reset password
  public resetHospitalUserPassword(emailId:string):Observable<ResponseMsg>{
    return this.httpClient.get<ResponseMsg>("http://localhost:5001/user-ms/user/forgot-password/"+emailId);
  }
}
