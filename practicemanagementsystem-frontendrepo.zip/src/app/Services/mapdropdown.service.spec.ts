import { TestBed } from '@angular/core/testing';

import { MapdropdownService } from './mapdropdown.service';

describe('MapdropdownService', () => {
  let service: MapdropdownService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MapdropdownService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
