import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ResponseMsg } from '../Models/ResponseMsg';
import { User } from '../Models/User';


@Injectable({
  providedIn: 'root'
})
export class PasswordService {

  constructor(private http: HttpClient) { }

  public resetPassword(emailId: string): Observable<ResponseMsg>
  {
    
    return this.http.get<ResponseMsg>('http://localhost:5001/user-ms/user/forgot-password/'+emailId);
  }

  public changePassword(user: User): Observable<ResponseMsg>
  {
    return this.http.post<ResponseMsg>('http://localhost:5001/user-ms/user/change-password', user);
  }

}
