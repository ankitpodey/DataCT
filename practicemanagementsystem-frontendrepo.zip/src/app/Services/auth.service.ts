import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from 'src/app/Models/User';



@Injectable({
  providedIn: 'root'
})

export class AuthService {

  //private const headero = {headers:new HttpHeaders({'Content-Type':'application.json'})};
  private token: string = "";
  private role: string = "";
  private emailId: string="";
  private userId: number;

  private patientId: number;
  private patientName: string="";

  private employeeId: number;
  private employeeName: string="";
  
  private isAuthenticated: boolean = false;


  constructor(private http: HttpClient) { }

  //getters setters
  public set AuthenticationToken(token: string)
  {
    this.token = token;
  }
  public get AuthenticationToken()
  {
    return this.token;
  }

  public set UserRole(role: string)
  {
    this.role = role;
  }
  public get UserRole()
  {
    return this.role;
  }

  public set EmailId(emailId: string)
  {
    this.emailId = emailId;
  }
  public get EmailId()
  {
    return this.emailId;
  }

  public set UserId(id: number)
  {
    this.userId = id;
  }
  public get UserId()
  {
    return this.userId;
  }

  public set PatientId(id: number)
  {
    this.patientId = id;
  }
  public get PatientId()
  {
    return this.patientId;
  }

  public set PatientName(name: string)
  {
    this.patientName = name;
  }
  public get PatientName()
  {
    return this.patientName;
  }

  public set EmployeeId(id: number)
  {
    this.employeeId = id;
  }
  public get EmployeeId()
  {
    return this.employeeId;
  }

  public set EmployeeName(name: string)
  {
    this.employeeName = name;
  }
  public get EmployeeName()
  {
    return this.employeeName;
  }


  



  //API calls

  public set IsAuthenticated(isAuthenticated: boolean)
  {
    this.isAuthenticated = isAuthenticated;
  }
  
  public get IsAuthenticated()
  {
    // if(Object.keys(this.token).length == 0)
    if(this.token == "")
    {
      this.isAuthenticated = false;
    }
    else
    {
      this.isAuthenticated = true;
    }
    return this.isAuthenticated;
  }

  //for expressjs server authetication
  public Login(userdata: any): Observable<any>
  {
    return this.http.post<any>('http://localhost:3000/api/login', userdata);
  }

  //for spring security authentication
  public getConfigResponse(loginModel: any): Observable<HttpResponse<any>> {
    
    return this.http.post<any>('http://localhost:5001/securityapp-ms/login', loginModel, {observe: 'response'});
    
  }

  public Logout(): void
  {
    this.isAuthenticated = false;
    this.token = "";
    this.role = "";
    
  }
  
  public validateUser(emailId : string) : Observable<User[]>
  {
    return this.http.get<User[]>('http://localhost:3000/user?emailId=' + emailId);
  }

public forgotPassword(emailId: string): Observable<string>
{
    return this.http.get<string>('http://localhost:3000/user/forgotpassword/' + emailId); //Path Variabl  
}


}
