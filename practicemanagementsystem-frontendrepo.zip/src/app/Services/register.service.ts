import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ResponseMsg } from '../Models/ResponseMsg';


@Injectable({
  providedIn: 'root'
})

export class RegisterService {

  constructor(private http: HttpClient) { }

  public registerPatient(patientdata: any): Observable<ResponseMsg>
  {
    return this.http.post<ResponseMsg>('http://localhost:5001/patient-ms/patient/', patientdata);
  }

  public registerHospitalUser(hospitaluserdata: any): Observable<any>
  {
    return this.http.post<any>('http://localhost:5001/employee-ms/employee/admin', hospitaluserdata);
  }

  public getReportsTo(): Observable<any>
  {
    return this.http.get<any>('http://localhost:3000/fetchreportsto');
  }

  

}
