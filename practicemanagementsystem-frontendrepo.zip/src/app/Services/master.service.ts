import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { ProcedureMaster } from '../Models/ProcedureMaster';
import { MedicationMaster } from '../Models/MedicationMaster';

@Injectable({
  providedIn: 'root'
})
export class MasterService {

  constructor(private httpClient:HttpClient) { }

  public GetDiagnosisMasterData():Observable<any>{
    return this.httpClient.get<any>("http://localhost:5001/masterapp-ms/master/diagnosis/fetch-diagnosis-master-table-details");
  }

  public GetProcedureMasterData():Observable<ProcedureMaster[]>{
    return this.httpClient.get<ProcedureMaster[]>("http://localhost:5001/masterapp-ms/master/procedure/fetch-procedure-master-table-details");
  }

  public GetMedicationMasterData():Observable<MedicationMaster[]>{
    return this.httpClient.get<MedicationMaster[]>("http://localhost:5001/masterapp-ms/master/medication/fetch-medication-master-table-details");
  }


}
