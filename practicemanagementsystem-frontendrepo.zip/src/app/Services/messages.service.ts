import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ResponseMsg } from '../Models/ResponseMsg';

@Injectable({
  providedIn: 'root'
})
export class MessagesService {

  constructor(private http: HttpClient) { }

  public getMessagesByReceiverId(receiverEmpId:number): Observable<any>
  {
    return this.http.get<any>('http://localhost:5001/messaging-ms/messaging/messages/' + receiverEmpId);
  }

  public saveMessage(composeMessage: any): Observable<ResponseMsg>
  {
    return this.http.post<ResponseMsg>('http://localhost:5001/messaging-ms/messaging/savemessage', composeMessage);
  }

  public markMessageAsRead(messageId: number): Observable<ResponseMsg> 
  {
    return this.http.put<ResponseMsg>('http://localhost:5001/messaging-ms/messaging/markreadmsg/' + messageId, null);
  }
}
