import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MapdropdownService {

  

  constructor(private http: HttpClient) { }

  // public registerPatient(patientdata: any): Observable<any>
  // {
  //   return this.http.post<any>('http://localhost:5001a/User', patientdata);
  // }

  public getSpeciality(): Observable<any>
  {
    return this.http.get<any>('http://localhost:5001/masterapp-ms/master/speciality/fetch-speciality-master-map-details');
  }


  public getEmployees(): Observable<any>
  {
    return this.http.get<any>('http://localhost:5001/employee-ms/employee/getall-phy-nurse-map');
  }
  // public getSpeciality(): Observable<Map<Number, String>>
  // {
  //   return this.http.get<Map<Number, String>>('http://localhost:5001/masterapp-ms/master/speciality/fetch-speciality-master-map-details');
  // }
  public getReportsTo(): Observable<any>
  {
    return this.http.get<any>('http://localhost:5001/employee-ms/employee/get-physician-map');
  }

  public getPhysicianBySpeciality(specialityMasterId: number): Observable<any>
  {
    return this.http.get<any>('http://localhost:5001/scheduling-ms/scheduling/physician-by-speciality/'+specialityMasterId);
  }

  public getAppointmentTimeByAppointmentDate(physicianId: number, meetingDate: Date): Observable<string[]>
  {
    return this.http.post<string[]>('http://localhost:5001/scheduling-ms/scheduling/patient/fetch-available-slots-by-physician/' + physicianId, meetingDate);
  }

  public getMasterDetails(): Observable<any>
  {
    return this.http.get<any>('http://localhost:5001/masterapp-ms/master/allergy/fetch-allergy-master-map-details');
  }

}
