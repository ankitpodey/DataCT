import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Observable } from 'rxjs';
import { CountService } from 'src/app/Services/count.service';

@Component({
  selector: 'app-admindashboard',
  templateUrl: './admindashboard.component.html',
  styleUrls: ['./admindashboard.component.css']
})
export class AdmindashboardComponent implements OnInit {

  apptitle: string = 'Practice-Management-System (PMS)';
  numberOfPatients: number;
  numberOfEmployees: number;
  numberOfAppointmentsToday: number;
  numberOfAppointmentsTillDate: number;
  public ob: Observable<any>;
  public error: string = "";

  constructor(private countService : CountService) { }

  ngOnInit(): void {

    this.numberOfPatients = this.GetNumberOfPatients();
    this.numberOfEmployees = this.GetNumberOfEmployees();
    this.numberOfAppointmentsToday = this.GetNumberOfAppointmentsToday();
    this.numberOfAppointmentsTillDate = this.GetNumberOfAppointmentsTillDate();
  }

  GetNumberOfPatients(): number {
    this.countService.getNumberOfPatients().subscribe(
      (data: any) => 
      {
        this.numberOfPatients = data;
      },
      (error: any) => this.error = error.error
    );
    return this.numberOfPatients;
  }
  
  GetNumberOfEmployees(): number {
    this.countService.getNumberOfEmployees().subscribe(
      (data: any) => 
      {
        this.numberOfEmployees = data;
      },
      (error: any) => this.error = error.error
    );
    return this.numberOfEmployees;
  }
  
  GetNumberOfAppointmentsToday(): number {
    this.countService.getNumberOfAppointmentsToday().subscribe(
      (data: any) => 
      {
        this.numberOfAppointmentsToday = data;
      },
      (error: any) => this.error = error.error
    );
    return this.numberOfAppointmentsToday;
  }
  
  GetNumberOfAppointmentsTillDate(): number {
    this.countService.getNumberOfAppointmentsTillDate().subscribe(
      (data: any) => 
      {
        this.numberOfAppointmentsTillDate = data;
      },
      (error: any) => this.error = error.error
    );
    return this.numberOfAppointmentsTillDate;
  }
}




