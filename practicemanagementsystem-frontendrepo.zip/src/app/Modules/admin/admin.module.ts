import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import adminroutes from './admin.routes';
import { AddEditHospitalUserComponent } from './add-edit-hospital-user/add-edit-hospital-user.component';
import { SharedMaterialModule } from '../shared-material/shared-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ManagehospitaluserComponent } from './managehospitaluser/managehospitaluser.component';
import { DataTablesModule } from 'angular-datatables';
import { ManagepatientuserComponent } from './managepatientuser/managepatientuser.component';
import { FlexLayoutModule } from '@angular/flex-layout';


@NgModule({
  declarations:
    [
      AdmindashboardComponent,
      AddEditHospitalUserComponent,
      ManagehospitaluserComponent,
      ManagepatientuserComponent
    ],
  imports: [
    CommonModule,
    adminroutes,
    SharedMaterialModule,
    FormsModule,
    ReactiveFormsModule,
    DataTablesModule,
    FlexLayoutModule
  ],
  exports: [
    [
      AdmindashboardComponent,
      AddEditHospitalUserComponent,
      ManagehospitaluserComponent,
      ManagepatientuserComponent,
      ReactiveFormsModule
    ]
  ]
})
export class AdminModule { }
