import { RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/Guard/auth.guard';
import { ChangePasswordComponent } from '../user/change-password/change-password.component';
import { HospitaluserprofileComponent } from '../user/hospitaluserprofile/hospitaluserprofile.component';
import { AddEditHospitalUserComponent } from './add-edit-hospital-user/add-edit-hospital-user.component';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { ManagehospitaluserComponent } from './managehospitaluser/managehospitaluser.component';
import { ManagepatientuserComponent } from './managepatientuser/managepatientuser.component';



const routes = [
    {
        path: '', 
        children: [
                { 
                path :'', 
                component : AdmindashboardComponent,
                canActivate: [AuthGuard]
                },
                { 
                    path :'myprofile', 
                    component : HospitaluserprofileComponent,
                    canActivate: [AuthGuard]
                },
                { 
                    path :'changepassword', 
                    component :ChangePasswordComponent,
                    canActivate: [AuthGuard]
                },
                {
                    path : 'managehospitaluser',
                    component : ManagehospitaluserComponent,
                    canActivate: [AuthGuard] 
                },
                {
                    path: 'managepatientuser',
                    component : ManagepatientuserComponent,
                    canActivate: [AuthGuard] 
                },
                {
                    path: 'addhospitaluser', 
                    component : AddEditHospitalUserComponent,
                    canActivate: [AuthGuard] 
                }
            ]
        }
];

export default RouterModule.forChild(routes);