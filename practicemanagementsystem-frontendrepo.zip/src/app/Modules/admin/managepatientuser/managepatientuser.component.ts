import { Component, OnInit, AfterViewInit, Renderer2, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { Patient } from 'src/app/Models/Patient';
import { ResponseMsg } from 'src/app/Models/ResponseMsg';
import { User } from 'src/app/Models/User';
import { AdminService } from 'src/app/Services/admin.service';

@Component({
  selector: 'app-managepatientuser',
  templateUrl: './managepatientuser.component.html',
  styleUrls: ['./managepatientuser.component.css']
})


export class ManagepatientuserComponent implements AfterViewInit, OnInit, OnDestroy {

  @ViewChild(DataTableDirective, { static: false })
  dtElement: DataTableDirective;

  @ViewChild('managePatientUserTable', {static:false})
  patientTable:ElementRef;


  dtPatientUserOptions: DataTables.Settings = {};
  patientData: Patient[] = [];
  dtTrigger: Subject<any> = new Subject<any>();

  constructor(private renderer: Renderer2, private router: Router, private adminSvc: AdminService, private _snackBar: MatSnackBar) {
  }
  
  ngOnInit() {

    //fetch patient user data
    this.adminSvc.getAllPatientUsers().subscribe(
      response => {

        console.log("inside observable" + response);

        this.patientData = response;
        this.dtPatientUserOptions.data = this.patientData;
        this.dtTrigger.next();

      })



    this.dtPatientUserOptions = {
      autoWidth: true,
      scrollX: true,
      columns: [
        {
          title: "Name",
          render: function (data, type, row) {
            return row.firstName + " " + row.lastName;
          }
        },
        {
          title: "Email Id",
          data: 'emailId'
        }
        , {
          title: 'Unlock',
          render: function (data, type, row) {
            let isActive = row.user.active;
            //check the current lock status
            if (!isActive) {
              //if true, display the unlock button
              let emailId = row.user.emailId;
              return '<div><button id = "unlock-btn" class="waves-effect btn btn-secondary btn-sm" email-id="' + emailId + '">Unlock</button></div>';
            }
            return "";
          }
          

        }, {
          title: 'Activate/Deactivate',
          render: function (data, type, row) {
            //for activate
            let emailId = row.user.emailId;
            if (row.delFlag) {
              return '<div><button id = "activate-btn" class="waves-effect btn btn-secondary btn-sm" email-id="' + emailId + '">Activate</button></div>';
            }
            //for deactivate
            else {
              return '<div><button id = "deactivate-btn" class="waves-effect btn btn-secondary btn-sm" email-id="' + emailId + '">Deactivate</button></div>';
            }
          }
        }],
        responsive:true
    };

  }

  ngAfterViewInit(): void {
    
    

    this.renderer.listen(this.patientTable.nativeElement, 'click', (event) => {
      //check the button id
      if (event.target.id == "unlock-btn") {
        this.unlockPatientUser(event.target.getAttribute("email-id"));
      }
      if (event.target.id == "activate-btn") {
        this.activatePatientUser(event.target.getAttribute("email-id"));
      }
      if (event.target.id == "deactivate-btn") {
        this.deactivatePatientUser(event.target.getAttribute("email-id"));
      }
      //console.log(event.target.getAttribute("user-id"));
      //this.router.navigate(["/person/" + event.target.getAttribute("view-person-id")]);

    });
    
  }

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();

      //fetch data again and set data again
      this.adminSvc.getAllPatientUsers().subscribe(
        response => {

          console.log("inside observable" + response);

          this.patientData = response;
          this.dtPatientUserOptions.data = this.patientData;

          // Call the dtTrigger to rerender again
          this.dtTrigger.next();
        })
    });
  }


  //function to unlock user
  unlockPatientUser(emailId: string): void {
    console.log("ts -> managepatientuser.component, function-> unlockPatientUser, unlockPatient -> " + emailId)
    //add logic/service call for unlocking user
    this.adminSvc.unlockUser(emailId).subscribe(
      (response : ResponseMsg)=>{
        console.log("unlock patient response "+response);
        if(response.successFlag){
          this.rerender();
        }
       this.openSnackBar(response.msg, "close")
       
      }
    )
    
    
  }


  //function to deactivate user
  deactivatePatientUser(emailId: string): void {
    console.log("ts -> managepatientuser.component, function-> deactivateUser, patientId -> " + emailId)
    //add service call for disabling user
    this.adminSvc.disableUser(emailId).subscribe(
      (response : ResponseMsg)=>{
        console.log("disable patient response "+response);
        if(response.successFlag){
          this.rerender();
        }
       this.openSnackBar(response.msg, "close")
       
      }
    )
  }

  //function to activate user
  activatePatientUser(emailId: string): void {
    console.log("ts -> managepatientuser.component, function-> activateUser, patientId -> " + emailId)
    //add service call for enabling user
    this.adminSvc.enableUser(emailId).subscribe(
      (response : ResponseMsg)=>{
        console.log("enable patient response "+response);
        if(response.successFlag){
          this.rerender();
        }
       this.openSnackBar(response.msg, "close")
       
      }
    )
  }

  public openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }




}
