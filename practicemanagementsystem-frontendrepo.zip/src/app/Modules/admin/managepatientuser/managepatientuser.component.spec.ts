import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagepatientuserComponent } from './managepatientuser.component';

describe('ManagepatientuserComponent', () => {
  let component: ManagepatientuserComponent;
  let fixture: ComponentFixture<ManagepatientuserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManagepatientuserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagepatientuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
