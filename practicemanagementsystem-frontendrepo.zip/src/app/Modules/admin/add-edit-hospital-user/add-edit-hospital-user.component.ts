import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { Employee } from 'src/app/Models/Employee';
import { PhysicianAvailability } from 'src/app/Models/PhysicianAvailability';
import { MapdropdownService } from 'src/app/Services/mapdropdown.service';
import { ResponseMsg } from 'src/app/Models/ResponseMsg';
import { RegisterService } from 'src/app/Services/register.service';

@Component({
  selector: 'app-add-edit-hospital-user',
  templateUrl: './add-edit-hospital-user.component.html',
  styleUrls: ['./add-edit-hospital-user.component.css']
})
export class AddEditHospitalUserComponent implements OnInit {

  maxDate = new Date();

  public ob: Observable<any>;
  public error: string = "";
  public employee: Employee = new Employee();
  public physicianAvailability: PhysicianAvailability = new PhysicianAvailability();
  fg: FormGroup;

  allSpecialitys: any = new Map();
  specialityMasterId: number;
  allReportsTo: any = new Map();
  //reportsToId: number;

  constructor(private mapDropDownService: MapdropdownService, private formBuilder: FormBuilder, private registerService: RegisterService, private router: Router, private _snackBar: MatSnackBar) {

  }

  //Below steps will display fields based on role selected by admin
  role = [
    { name: 'Nurse' },
    { name: 'Physician' }
  ];

  isVisible = -1;

  onItemChange(item, i) {
    if (item.name == 'Nurse') {
      this.isVisible = 0;
      this.employee.roleId = 3;
    } else if (item.name == 'Physician') {
      this.isVisible = 1;
      this.employee.roleId = 2;
    }
  }

  //Below code is for populating speciality values in drop down
  FillSpecialityDDL() {

    this.mapDropDownService.getSpeciality().subscribe(
      (data: any) => {
        console.log("DATA :" + data);

        let stringifiedData: any;
        stringifiedData = JSON.stringify(data);
        var jsonObject = JSON.parse(stringifiedData);
        console.log("json object " + jsonObject);
        var dataMap = new Map(Object.entries(jsonObject));
        this.allSpecialitys = dataMap;
        for (const key of dataMap.keys()) {
          console.log("key : " + key);
          console.log("value : " + dataMap.get(key));
        }

      },
      error => console.log(error), () => console.log('Some error occurred.')
    );

  }

  FillReportsToDDL() {

    this.mapDropDownService.getReportsTo().subscribe(
      (data: any) => {

        let stringifiedData: any;
        stringifiedData = JSON.stringify(data);
        var jsonObject = JSON.parse(stringifiedData);
        console.log("json object " + jsonObject);
        var dataMap = new Map(Object.entries(jsonObject));
        this.allReportsTo = dataMap;
        for (const key of dataMap.keys()) {
          console.log("key : " + key);
          console.log("value : " + dataMap.get(key));
        }
      },
      error => console.log(error), () => console.log('Some error occurred.')
    );

  }

  ngOnInit(): void {

    this.physicianAvailability.mondayFrom = "09:00";
    this.physicianAvailability.tuesdayFrom = "09:00";
    this.physicianAvailability.wednesdayFrom = "09:00";
    this.physicianAvailability.thursdayFrom = "09:00";
    this.physicianAvailability.fridayFrom = "09:00";
    this.physicianAvailability.saturdayFrom = "09:00";
    this.physicianAvailability.sundayFrom = "09:00";

    this.physicianAvailability.mondayTo = "18:00";
    this.physicianAvailability.tuesdayTo = "18:00";
    this.physicianAvailability.wednesdayTo = "18:00";
    this.physicianAvailability.thursdayTo = "18:00";
    this.physicianAvailability.fridayTo = "18:00";
    this.physicianAvailability.saturdayTo = "18:00";
    this.physicianAvailability.sundayTo = "18:00";

    this.employee.physicianAvailability = this.physicianAvailability;

    //creating required formcontrol using the formbuilder(injected in constructor)
    this.fg = this.formBuilder.group({
      title: [this.employee.title, [Validators.required]],  //check how to initialize for select element
      firstName: [this.employee.firstName, [Validators.required, Validators.pattern('^[a-zA-Z]+$'), Validators.minLength(3), Validators.maxLength(20)]],
      lastName: [this.employee.lastName, [Validators.required, Validators.minLength(3), Validators.maxLength(20), Validators.pattern('^[a-zA-Z]+$')]],
      emailId: [this.employee.emailId, [Validators.required, Validators.pattern('[A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+\\.[a-z]{2,3}')]],
      dateOfBirth: [this.employee.dateOfBirth, [Validators.required, validateDateOfBirth]],
      contactNumber: [this.employee.contactNumber, [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],

      specialityMasterId: [this.employee.specialityMasterId, [Validators.required]],
      roleId: [this.employee.roleId, [Validators.required]],
      reportsToId: [this.employee.reportsTo, [Validators.required]],

      addressLineOne: [this.employee.addressLineOne],
      addressLineTwo: [this.employee.addressLineTwo],
      addressStreet: [this.employee.addressStreet],
      addressLandmark: [this.employee.addressLandmark],
      addressCity: [this.employee.addressCity],
      addressState: [this.employee.addressState],
      addressCountry: [this.employee.addressCountry],
      addressZipCode: [this.employee.addressZipCode, [Validators.minLength(6), Validators.maxLength(6), Validators.pattern('^[0-9]+$')]],

      mondayFrom: [this.physicianAvailability.mondayFrom, [Validators.required]],
      mondayTo: [this.physicianAvailability.mondayTo, [Validators.required]],
      tuesdayFrom: [this.physicianAvailability.tuesdayFrom, [Validators.required]],
      tuesdayTo: [this.physicianAvailability.tuesdayTo, [Validators.required]],
      wednesdayFrom: [this.physicianAvailability.wednesdayFrom, [Validators.required]],
      wednesdayTo: [this.physicianAvailability.wednesdayTo, [Validators.required]],
      thursdayFrom: [this.physicianAvailability.thursdayFrom, [Validators.required]],
      thursdayTo: [this.physicianAvailability.thursdayTo, [Validators.required]],
      fridayFrom: [this.physicianAvailability.fridayFrom, [Validators.required]],
      fridayTo: [this.physicianAvailability.fridayTo, [Validators.required]],
      saturdayFrom: [this.physicianAvailability.saturdayFrom, [Validators.required]],
      saturdayTo: [this.physicianAvailability.saturdayTo, [Validators.required]],
      sundayFrom: [this.physicianAvailability.sundayFrom, [Validators.required]],
      sundayTo: [this.physicianAvailability.sundayTo, [Validators.required]]
    })

    this.FillSpecialityDDL();

    this.FillReportsToDDL();

  }

  public RegisterHospitalUser(): void {
    console.log("Employee is getting registered");
    this.employee.title = this.fg.value.title;
    this.employee.firstName = this.fg.value.firstName;
    this.employee.lastName = this.fg.value.lastName;
    this.employee.emailId = this.fg.value.emailId;
    this.employee.contactNumber = this.fg.value.contactNumber;
    this.employee.dateOfBirth = this.fg.value.dateOfBirth;

    this.employee.addressLineOne = this.fg.value.addressLineOne;
    this.employee.addressLineTwo = this.fg.value.addressLineTwo;
    this.employee.addressStreet = this.fg.value.addressStreet;
    this.employee.addressCity = this.fg.value.addressCity;
    this.employee.addressLandmark = this.fg.value.addressLandmark;
    this.employee.addressState = this.fg.value.addressState;
    this.employee.addressCountry = this.fg.value.addressCountry;
    this.employee.addressZipCode = this.fg.value.addressZipCode;

    this.employee.specialityMasterId = this.fg.value.specialityMasterId;
    this.employee.reportsTo = this.fg.value.reportsToId;

    this.physicianAvailability.mondayFrom = this.fg.value.mondayFrom;
    this.physicianAvailability.mondayTo = this.fg.value.mondayTo;
    this.physicianAvailability.tuesdayFrom = this.fg.value.tuesdayFrom;
    this.physicianAvailability.tuesdayTo = this.fg.value.tuesdayTo;
    this.physicianAvailability.wednesdayFrom = this.fg.value.wednesdayFrom;
    this.physicianAvailability.wednesdayTo = this.fg.value.wednesdayTo;
    this.physicianAvailability.thursdayFrom = this.fg.value.thursdayFrom;
    this.physicianAvailability.thursdayTo = this.fg.value.thursdayTo;
    this.physicianAvailability.fridayFrom = this.fg.value.fridayFrom;
    this.physicianAvailability.fridayTo = this.fg.value.fridayTo;
    this.physicianAvailability.saturdayFrom = this.fg.value.saturdayFrom;
    this.physicianAvailability.saturdayTo = this.fg.value.saturdayTo;
    this.physicianAvailability.sundayFrom = this.fg.value.sundayFrom;
    this.physicianAvailability.sundayTo = this.fg.value.sundayTo;

    this.employee.physicianAvailability = this.physicianAvailability;

    this.registerService.registerHospitalUser(this.employee).subscribe(
      (response: ResponseMsg) => {
        console.log("Processing registration");
        if (response.successFlag) {
          this.fg.reset();
        }
        this.openSnackBar(response.msg, "Close");
      },
      (error: any) => this.error = error.error
    );
  }

  public openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }
}

function validateDateOfBirth(control: AbstractControl): { [key: string]: any } | null {
  const dob: Date = control.value;
  let today = new Date();
  if (dob > today) {
    return { "dobValidationError": true };
  } else {
    return null;
  }
}
