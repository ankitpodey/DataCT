import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditHospitalUserComponent } from './add-edit-hospital-user.component';

describe('AddEditHospitalUserComponent', () => {
  let component: AddEditHospitalUserComponent;
  let fixture: ComponentFixture<AddEditHospitalUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditHospitalUserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditHospitalUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
