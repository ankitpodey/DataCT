import { OnDestroy } from '@angular/core';
import { Component, OnInit , AfterViewInit, Renderer2, ViewChild, ElementRef} from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { Employee } from 'src/app/Models/Employee';
import { ResponseMsg } from 'src/app/Models/ResponseMsg';
import { AdminService } from 'src/app/Services/admin.service';
import { AuthService } from 'src/app/Services/auth.service';

@Component({
  selector: 'app-managehospitaluser',
  templateUrl: './managehospitaluser.component.html',
  styleUrls: ['./managehospitaluser.component.css']
})
export class ManagehospitaluserComponent implements AfterViewInit, OnInit, OnDestroy{
  
  @ViewChild('manageHospitalUserTable', {static:false})
  hospitalTable:ElementRef;

  @ViewChild(DataTableDirective, { static: false })
  dtElement: DataTableDirective;

  dtHospitalUserOptions: DataTables.Settings = {};
  employeeData: Employee[] = [];
  dtTrigger: Subject<any> = new Subject<any>();

  
  userData : any;

  constructor(private renderer: Renderer2, private router: Router, private adminSvc: AdminService, private _snackBar: MatSnackBar) {
   }

  ngOnInit(): void {

    //fetch employee data
    this.adminSvc.getAllHospitalUsers().subscribe(
      response=>{
        console.log("hospital users data received "+response);
        this.employeeData = response.filter(x => x.roleId != 1);
        this.dtHospitalUserOptions.data = this.employeeData;
        this.dtTrigger.next();

      }
    )


    this.dtHospitalUserOptions = {
      ordering: true,
			searching: true,
			autoWidth: true,
			scrollX: true,
			scrollCollapse: true,
			paging: true,
      columns: [{
        title: 'Name',
        render : function(data, type, row){
          return row.firstName + " " + row.lastName;
        }
      }, {
        title: 'Email',
        data: 'emailId'
      },{
        title : 'Role',
        render : function(date, type, row){
          return row.roleId==2?"Physician":"Nurse";
        }
      }, {
        title: 'Unlock',
        render: function (data, type, row) {
          let isActive = row.user.active;
          //check the current lock status
          if (!isActive) {
            //if true, display the unlock button
            let emailId = row.user.emailId;
            return '<div><button id = "unlock-btn" class="waves-effect btn btn-secondary btn-sm" email-id="' + emailId + '">Unlock</button></div>';
          }
          return "";
        }
      }, {
        title: 'Reset Password',
        render: function (data: any, type: any, row: any) {
          let emailId = row.user.emailId;
          return '<div><button id = "reset-password-btn" class="waves-effect btn btn-secondary btn-sm" email-id="'+emailId+'">Reset</button></div>';
        }
      }
      // , {
      //   title: 'Update',
      //   render: function (data: any, type: any, row: any) {
      //     let userId = row.user.userId;
      //     return '<div><button id = "update-profile-btn" class="waves-effect btn btn-secondary btn-sm" user-id="' + userId +'">Update</button></div>';
      //   }
      // }
      , {
        title: 'Activate/Deactivate',
        render: function (data, type, row) {
          //for activate
          let emailId = row.user.emailId;
          if (row.delFlag) {
            return '<div><button id = "activate-btn" class="waves-effect btn btn-secondary btn-sm" email-id="' + emailId + '">Activate</button></div>';
          }
          //for deactivate
          else {
            return '<div><button id = "deactivate-btn" class="waves-effect btn btn-secondary btn-sm" email-id="' + emailId + '">Deactivate</button></div>';
          }
        }
      }]
    };
  }

  ngAfterViewInit(): void {
    this.renderer.listen(this.hospitalTable.nativeElement, 'click', (event) => {
      //check the button id
      if(event.target.id == "unlock-btn"){
        this.unlockHospitalUser(event.target.getAttribute("email-id"));
      }
      if(event.target.id == "reset-password-btn"){
        this.resetHospitalUserPassword(event.target.getAttribute("email-id"));
      }
      if(event.target.id == "activate-btn"){
        this.activateUser(event.target.getAttribute("email-id"));
      }
      if(event.target.id == "deactivate-btn"){
        this.deactivateUser(event.target.getAttribute("email-id"));
      }
      if(event.target.id == "update-profile-btn"){
        this.updateUser(event.target.getAttribute("email-id"));
      }
    });
  }

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();

      //fetch data again and set data again
      this.adminSvc.getAllHospitalUsers().subscribe(
        response => {

          console.log("inside observable" + response);

          this.employeeData = response.filter(x => x.roleId != 1);
          this.dtHospitalUserOptions.data = this.employeeData;

          // Call the dtTrigger to rerender again
          this.dtTrigger.next();
        })
    });
  }

  //function to unlock user
  unlockHospitalUser(emailId : string) : void{
    //add logic/service call for unlocking user
    console.log("ts -> managehospitaluser.component, function-> unlockHospitalUser, unlockEmployee -> "+emailId);

    this.adminSvc.unlockUser(emailId).subscribe(
      (response : ResponseMsg)=>{
        console.log("unlock patient response "+response);
        if(response.successFlag){
          this.rerender();
        }
       this.openSnackBar(response.msg, "close")
       
      }
    )
  }

  //function to reset user password
  resetHospitalUserPassword(emailId : string) : void{
    //add service call once service ready
    console.log("ts -> managehospitaluser.component, function-> resetHospitalUserPassword, resetEmployeePassword -> "+emailId);
    this.adminSvc.resetHospitalUserPassword(emailId).subscribe(
      (response:ResponseMsg)=>{
        if(response.successFlag){
          this.rerender();
        }
        this.openSnackBar(response.msg, "close");
      }
    );
  }

  //function to disable user
  deactivateUser(emailId : string) : void{
    //add service call for disabling user
    console.log("ts -> managehospitaluser.component, function-> deactivateUser, employeeId -> "+emailId);

    this.adminSvc.disableUser(emailId).subscribe(
      (response : ResponseMsg)=>{
        console.log("disable patient response "+response);
        if(response.successFlag){
          this.rerender();
        }
       this.openSnackBar(response.msg, "close")
       
      }
    )
  }

   //function to activate user
   activateUser(emailId : string) : void{
    //add service call for enabling user
    console.log("ts -> managehospitaluser.component, function-> activateUser, employeeId -> "+emailId);
    this.adminSvc.enableUser(emailId).subscribe(
      (response : ResponseMsg)=>{
        console.log("enable patient response "+response);
        if(response.successFlag){
          this.rerender();
        }
       this.openSnackBar(response.msg, "close")
       
      }
    )
  }

  //function to update employee profile
  updateUser(userId : number) : void{
    //navigate to appropriate route
    console.log("ts -> managehospitaluser.component, function-> updateUserProfile, employeeId -> "+userId)
    //this.router.navigate(["/person/" + event.target.getAttribute("view-person-id")]);
      
  }

  public openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }
}
