import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { Appointment } from 'src/app/Models/Appointment';
import { AuthService } from 'src/app/Services/auth.service';
import { CountService } from 'src/app/Services/count.service';
import { SchedulingService } from 'src/app/Services/scheduling.service';

@Component({
  selector: 'app-patientdashboard',
  templateUrl: './patientdashboard.component.html',
  styleUrls: ['./patientdashboard.component.css'],
  providers: [NgbCarouselConfig, DatePipe],
})

export class PatientdashboardComponent {

  isVisible: boolean = false;

  newAppointmentDate: String;
  appointmentTime: string;
  physicianName: string;
  appointmentSubject: string;
  appointmentDescription: string;
  public appointment: Appointment = new Appointment();

  numberOfAppointmentsTillDate: number;
  public error: string = "";

  constructor(config: NgbCarouselConfig, private authService: AuthService, private countService: CountService, private schedulingService: SchedulingService, public datepipe: DatePipe) {
    config.interval = 2000;
    config.keyboard = true;
    config.pauseOnHover = true;
  }

  ngOnInit(): void {

    this.numberOfAppointmentsTillDate = this.GetNumberOfAppointmentsTillDate();

    console.log("laveena : patient Id ; " + this.authService.PatientId);
    this.GetUpcomingAppointmentForPatient(this.authService.PatientId);
    
    //this.appointment = this.GetUpcomingAppointmentForPatient(this.authService.PatientId);
    // this.newAppointmentDate = this.convertDateToStandardFormat(new Date("2021-01-01"));
    // this.appointmentTime = "15:00";
    // this.doctorName = "Dr. Jackson Jacob";
    // this.appointmentSubject = "";
    // this.appointmentDescription = "";
  }

  GetNumberOfAppointmentsTillDate(): number {
    this.countService.getNumberOfAppointmentsTillDateForPatient(this.authService.PatientId).subscribe(
      (data: any) => {
        this.numberOfAppointmentsTillDate = data;
      },
      (error: any) => this.error = error.error
    );
    return this.numberOfAppointmentsTillDate;
  }

  //Get Patient Id from headers and pass it as a method param
  GetUpcomingAppointmentForPatient(patientId: number): Appointment {
    this.schedulingService.GetUpcomingAppointmentForPatient(patientId).subscribe(
      (data: any) => {
        console.log("laveena 2 patientId : "+ patientId);
        console.log("laveena 3 : appointment data " + JSON.stringify(data));
        this.appointment = data;
        if (null != this.appointment.physicianName){
          //this.appointment.physicianName = "No Upcoming Appointment."
          this.isVisible = true;
      this.newAppointmentDate = this.convertDateToStandardFormat(this.appointment.appointmentDate);
      this.appointmentTime = this.appointment.appointmentTime;
      this.physicianName = this.appointment.physicianName;
      this.appointmentSubject = this.appointment.appointmentTitle;
      this.appointmentDescription = this.appointment.appointmentDescription;
    }
      },
      (error: any) => this.error = error.error
    );
    return this.appointment;
  }

  convertDateToStandardFormat(inputDate: Date): String {
    this.newAppointmentDate = this.datepipe.transform(inputDate, 'yyyy-MM-dd');
    return this.newAppointmentDate;
  }

}
