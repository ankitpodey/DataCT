import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PatientdashboardComponent } from './patientdashboard/patientdashboard.component';
import { SharedMaterialModule } from 'src/app/Modules/shared-material/shared-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PatientprofileComponent } from 'src/app/Modules/patient/patientprofile/patientprofile.component';
import patientRoutes from './patient.routes';
import { PastvisitComponent } from './pastvisit/pastvisit.component';
import { DataTablesModule } from 'angular-datatables';
import {​​​​​​​​ FlexLayoutModule }​​​​​​​​ from'@angular/flex-layout';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [
    PatientdashboardComponent, 
    PatientprofileComponent, 
    PastvisitComponent],
  imports: [
    CommonModule,
    SharedMaterialModule,
    FormsModule,
    ReactiveFormsModule,
    patientRoutes,
    DataTablesModule,
    FlexLayoutModule,
    NgbModule

  ],
  exports: [ 
    PatientdashboardComponent,
     PatientprofileComponent,
     PastvisitComponent
  ]
})
export class PatientModule { }
