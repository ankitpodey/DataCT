import { RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/Guard/auth.guard';
import { ScheduleappointmentComponent } from '../scheduling/scheduleappointment/scheduleappointment.component';
import { ChangePasswordComponent } from '../user/change-password/change-password.component';
import { PastvisitComponent } from './pastvisit/pastvisit.component';
import { PatientdashboardComponent } from './patientdashboard/patientdashboard.component';
import { PatientprofileComponent } from './patientprofile/patientprofile.component';

const routes = [
    {
    path: '', 
    children: [
             { 
            path :'', 
            component : PatientdashboardComponent,
            canActivate: [AuthGuard]
            },
            { 
                path :'changepassword', 
                component :ChangePasswordComponent,
                canActivate: [AuthGuard]
            },
            { 
                path :'myprofile', 
                component : PatientprofileComponent,
                canActivate: [AuthGuard]
            }
             ,
             { 
                 path :'pastvisits', 
                 component : PastvisitComponent,
                 canActivate: [AuthGuard]
             }
        ]
    }
];

export default RouterModule.forChild(routes);