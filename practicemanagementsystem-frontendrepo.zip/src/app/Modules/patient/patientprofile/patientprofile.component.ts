import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators, AbstractControl, FormArray } from '@angular/forms';
import { Patient } from 'src/app/Models/Patient'
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { EmergencyContact } from 'src/app/Models/EmergencyContact';
import { Allergy } from 'src/app/Models/Allergy';
import { PatientService } from 'src/app/Services/patient.service';
import { AuthService } from 'src/app/Services/auth.service';
import { ResponseMsg } from 'src/app/Models/ResponseMsg';
import { MapdropdownService } from 'src/app/Services/mapdropdown.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-patientprofile',
  templateUrl: './patientprofile.component.html',
  styleUrls: ['./patientprofile.component.css']
})
export class PatientprofileComponent implements OnInit {
  maxDate = new Date();

  //for sending data initially to page
  public patientData: Patient = new Patient();
  public allergy: Allergy = new Allergy();
  public patientEmergencyContact: EmergencyContact = new EmergencyContact();
  public patientAllergy: Array<Allergy> = [];
  allAllergyType: any = new Map();
  patientId: number;
  //Defining form group
  public error: string = "";
  submitted = false;
  patientForm: FormGroup;
//  patientEmergencyContactForm : FormGroup;
  updatedPatientData :Patient = new Patient();
  updatedPatientEmergencyData :EmergencyContact = new EmergencyContact();
  
  constructor(private formBuilder: FormBuilder, private mapDropDownService: MapdropdownService, private _snackBar: MatSnackBar ,private patientService: PatientService, private authService: AuthService) {
   }

    ngOnInit(): void {

      this.FillAllergyDDL();

      this.patientForm = this.formBuilder.group({

      title: [this.patientData.title, [Validators.required]],  //check how to initialize for select element
      firstName: [this.patientData.firstName, [Validators.required, Validators.minLength(3), Validators.maxLength(20), Validators.pattern('^[a-zA-Z]+$')]],
      lastName: [this.patientData.lastName, [Validators.required, Validators.minLength(3), Validators.maxLength(20), Validators.pattern('^[a-zA-Z]+$')]],
      emailId: [this.patientData.emailId, [Validators.required, Validators.pattern('[A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+\\.[a-z]{2,3}')]],
      dateOfBirth: [this.patientData.dateOfBirth, [Validators.required, validateDateOfBirth]],
      contactNumber: [this.patientData.contactNumber, [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      gender: [this.patientData.gender, [Validators.required]],

      race: [this.patientData.race],
      ethinicity: [this.patientData.ethinicity],
      languagesKnown: [this.patientData.languagesKnown],
      addressLineOne: [this.patientData.addressLineOne],
      addressLineTwo: [this.patientData.addressLineTwo],
      addressStreet: [this.patientData.addressStreet],
      addressLandmark: [this.patientData.addressLandmark],
      addressCity: [this.patientData.addressCity],
      addressState: [this.patientData.addressState],
      addressCountry: [this.patientData.addressCountry],
      addressZipCode: [this.patientData.addressZipCode, [Validators.minLength(6), Validators.maxLength(6), Validators.pattern('^[0-9]+$')]],
      verificationFlag: [this.patientData.verificationFlag],

      emergencyfirstName: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20), Validators.pattern('^[a-zA-Z]+$')]],
      emergencylastName: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20), Validators.pattern('^[a-zA-Z]+$')]],
      emergencyrelationship: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20), Validators.pattern('^[a-zA-Z]+$')]],
      emergencyemailId: ['', [Validators.required, Validators.pattern('[A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+\\.[a-z]{2,3}')]],
      emergencycontactNumber: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      emergencyaddressLineOne: ['', Validators.required],
      emergencyaddressLineTwo: [''],
      emergencyaddressStreet: ['', [Validators.required]],
      emergencyaddressLandmark: ['', [Validators.required]],
      emergencyaddressCity: ['', Validators.required],
      emergencyaddressState: ['', Validators.required],
      emergencyaddressCountry: ['', Validators.required],
      emergencyaddressZipCode: ['', Validators.required],


      patientAllergy: this.formBuilder.group({
        allergyMasterId: [this.patientAllergy.length + 1, Validators.required],    //allergyMasterId  // Validators.required
        allergyClinicalInformation: [],
        allergyFatal: ['false', Validators.required]
      })
    })
    // getPatient;
    //updatePatientById;
    //this.patientId=4;
    this.patientService.getPatientById(this.authService.PatientId).subscribe(
      (data: any) => {
        //  this.patientData.patientId =2;
        this.patientData = data;
        console.log("dattaa" + JSON.stringify(data));
        this.populatePatientData(this.patientData);

        this.patientAllergy = this.patientData.patientAllergies;
      }
    );
  }



  addAllergyButton(): void {
    this.allergy = new Allergy();
    console.log("add allergy btn clicked ..");
    this.allergy.allergyMasterId = this.patientForm.controls['patientAllergy'].value.allergyMasterId;
    this.allergy.allergyName = this.allAllergyType.get(this.allergy.allergyMasterId);
    console.log("this.allergy.allergyName" + this.allergy.allergyName);
    this.allergy.patientId = this.patientId;
    this.allergy.allergyClinicalInformation = this.patientForm.controls['patientAllergy'].value.allergyClinicalInformation; //this.fg.value.emailId;
    this.allergy.allergyFatal = this.patientForm.controls['patientAllergy'].value.allergyFatal;
    this.patientAllergy.push(this.allergy);
    this.patientForm.controls['patientAllergy'].reset();
    console.log(this.patientAllergy);

  }
  populatePatientData(patientData: Patient) {
   

    this.patientForm.controls['title'].setValue(patientData.title);
    this.patientForm.controls['firstName'].setValue(patientData.firstName)
    this.patientForm.controls['lastName'].setValue(patientData.lastName)
    this.patientForm.controls['emailId'].setValue(patientData.emailId)
    this.patientForm.controls['dateOfBirth'].setValue(patientData.dateOfBirth)
    this.patientForm.controls['contactNumber'].setValue(patientData.contactNumber)
    this.patientForm.controls['gender'].setValue(patientData.gender)
    this.patientForm.controls['race'].setValue(patientData.race)
    this.patientForm.controls['ethinicity'].setValue(patientData.ethinicity)
    this.patientForm.controls['languagesKnown'].setValue(patientData.languagesKnown)
    this.patientForm.controls['addressLineOne'].setValue(patientData.addressLineOne)
    this.patientForm.controls['addressLineTwo'].setValue(patientData.addressLineTwo)
    this.patientForm.controls['addressStreet'].setValue(patientData.addressStreet)
    this.patientForm.controls['addressLandmark'].setValue(patientData.addressLandmark)
    this.patientForm.controls['addressCity'].setValue(patientData.addressCity)
    this.patientForm.controls['addressState'].setValue(patientData.addressState)
    this.patientForm.controls['addressCountry'].setValue(patientData.addressCountry)
    this.patientForm.controls['addressZipCode'].setValue(patientData.addressZipCode)

    if (patientData.patientEmergencyContact != null) {
      this.patientForm.controls['emergencyfirstName'].setValue(patientData.patientEmergencyContact.firstName)
      this.patientForm.controls['emergencylastName'].setValue(patientData.patientEmergencyContact.lastName)
      this.patientForm.controls['emergencyrelationship'].setValue(patientData.patientEmergencyContact.relationship)
      this.patientForm.controls['emergencyemailId'].setValue(patientData.patientEmergencyContact.emailId)
      this.patientForm.controls['emergencycontactNumber'].setValue(patientData.patientEmergencyContact.contactNumber)
      this.patientForm.controls['emergencyaddressLineOne'].setValue(patientData.patientEmergencyContact.addressLineOne)
      this.patientForm.controls['emergencyaddressLineTwo'].setValue(patientData.patientEmergencyContact.addressLineTwo)
      this.patientForm.controls['emergencyaddressStreet'].setValue(patientData.patientEmergencyContact.addressStreet)
      this.patientForm.controls['emergencyaddressLandmark'].setValue(patientData.patientEmergencyContact.addressLandmark)
      this.patientForm.controls['emergencyaddressCity'].setValue(patientData.patientEmergencyContact.addressCity)
      this.patientForm.controls['emergencyaddressState'].setValue(patientData.patientEmergencyContact.addressState)
      this.patientForm.controls['emergencyaddressCountry'].setValue(patientData.patientEmergencyContact.addressCountry)
      this.patientForm.controls['emergencyaddressZipCode'].setValue(patientData.patientEmergencyContact.addressZipCode)

      console.log("laveena "+ JSON.stringify(patientData.patientEmergencyContact));
      this.updatedPatientData.patientEmergencyContact = this.updatedPatientEmergencyData;
      this.updatedPatientData.patientEmergencyContact.patientEmergencyContactId = patientData.patientEmergencyContact.patientEmergencyContactId;
    }
  }


  Save(): void {
    this.updatedPatientData.patientId = this.patientData.patientId;
    this.updatedPatientData.title = this.patientForm.value.title;
    this.updatedPatientData.firstName = this.patientForm.value.firstName;
    this.updatedPatientData.lastName = this.patientForm.value.lastName;
    this.updatedPatientData.emailId = this.patientForm.value.emailId;
    this.updatedPatientData.dateOfBirth = this.patientForm.value.dateOfBirth;
    this.updatedPatientData.contactNumber = this.patientForm.value.contactNumber;
    this.updatedPatientData.gender = this.patientForm.value.gender;
    this.updatedPatientData.race = this.patientForm.value.race;
    this.updatedPatientData.ethinicity = this.patientForm.value.ethinicity;
    this.updatedPatientData.languagesKnown = this.patientForm.value.languagesKnown;
    this.updatedPatientData.addressLineOne = this.patientForm.value.addressLineOne;
    this.updatedPatientData.addressLineTwo = this.patientForm.value.addressLineTwo;
    this.updatedPatientData.addressStreet = this.patientForm.value.addressStreet;
    this.updatedPatientData.addressLandmark = this.patientForm.value.addressLandmark;
    this.updatedPatientData.addressCity = this.patientForm.value.addressCity;
    this.updatedPatientData.addressState = this.patientForm.value.addressState;
    this.updatedPatientData.addressCountry = this.patientForm.value.addressCountry;
    this.updatedPatientData.addressZipCode = this.patientForm.value.addressZipCode;
    //this.updatedPatientData.patientEmergencyContact= this.updatedPatientEmergencyData;



    this.updatedPatientEmergencyData.firstName = this.patientForm.value.emergencyfirstName;
    this.updatedPatientEmergencyData.lastName = this.patientForm.value.emergencylastName;
    this.updatedPatientEmergencyData.relationship = this.patientForm.value.emergencyrelationship;
    this.updatedPatientEmergencyData.emailId = this.patientForm.value.emergencyemailId;
    this.updatedPatientEmergencyData.contactNumber = this.patientForm.value.emergencycontactNumber;
    this.updatedPatientEmergencyData.addressLineOne = this.patientForm.value.emergencyaddressLineOne;
    this.updatedPatientEmergencyData.addressLineTwo = this.patientForm.value.emergencyaddressLineTwo;
    this.updatedPatientEmergencyData.addressStreet = this.patientForm.value.emergencyaddressStreet;
    this.updatedPatientEmergencyData.addressLandmark = this.patientForm.value.emergencyaddressLandmark; //emergencyaddressCity
    this.updatedPatientEmergencyData.addressCity = this.patientForm.value.emergencyaddressCity;
    this.updatedPatientEmergencyData.addressLandmark = this.patientForm.value.emergencyaddressLandmark;
    this.updatedPatientEmergencyData.addressCity = this.patientForm.value.emergencyaddressCity;
    this.updatedPatientEmergencyData.addressState = this.patientForm.value.emergencyaddressState;
    this.updatedPatientEmergencyData.addressCountry = this.patientForm.value.emergencyaddressCountry;  //emergencyaddressZipCode
    this.updatedPatientEmergencyData.addressZipCode = this.patientForm.value.emergencyaddressZipCode;  //emergencyaddressZipCode

    this.updatedPatientData.patientEmergencyContact = this.updatedPatientEmergencyData;

    this.updatedPatientData.patientAllergies = this.patientAllergy;
    console.log("Patient is beginning to save." + JSON.stringify(this.updatedPatientData));
    this.patientService.updatePatient(this.updatedPatientData).subscribe(
      (responseMsg: ResponseMsg) => {
        console.log("Patient Profile" + JSON.stringify(responseMsg));
        this.openSnackBar(responseMsg.msg, "Close");
      },
      (error: any) => this.error = error.error
    );
    this.submitted = true;
    // stop here if form is invalid
    // if (this.patientForm.invalid) {  //
    //     return;        //
    //   }              //
    // display form values on success
    // alert('SUCCESS!!');
  }
  public openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }

  public deleteAllergy(allergy:any):void{
    this.patientAllergy = this.patientAllergy.filter(x=>x.allergyMasterId != allergy.allergyMasterId);
  }

  FillAllergyDDL() {

    this.mapDropDownService.getMasterDetails().subscribe(
      (data: any) => {

        let stringifiedData: any;
        stringifiedData = JSON.stringify(data);
        console.log("stringified allAllergyType (data) :  " + stringifiedData);
        var jsonObject = JSON.parse(stringifiedData);
        var dataMap = new Map(Object.entries(jsonObject));
        this.allAllergyType = dataMap;
      },
      err => console.log(err), () => console.log('getAllergy completed')
    );
  }


}



function validateDateOfBirth(control: AbstractControl): { [key: string]: any } | null {
  const dob: Date = control.value;
  let today = new Date();
  if (dob > today) {
    return { "dobValidationError": true };
  } else {
    return null;
  }
}





