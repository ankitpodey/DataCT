import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PastvisitComponent } from './pastvisit.component';

describe('PastvisitComponent', () => {
  let component: PastvisitComponent;
  let fixture: ComponentFixture<PastvisitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PastvisitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PastvisitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
