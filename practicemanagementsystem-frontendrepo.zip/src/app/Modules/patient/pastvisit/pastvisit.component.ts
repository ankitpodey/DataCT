import { Router } from '@angular/router';
import { Component, OnInit, AfterViewInit, Renderer2 } from '@angular/core';
import { PatientService } from 'src/app/Services/patient.service';
import { AuthService } from 'src/app/Services/auth.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-pastvisit',
  templateUrl: './pastvisit.component.html',
  styleUrls: ['./pastvisit.component.css']
})
export class PastvisitComponent implements AfterViewInit, OnInit {

  dtOptions: any = {};
  userData: any;
  patientId: number;

  dtTrigger: Subject<any> = new Subject<any>();

  constructor(private renderer: Renderer2, private router: Router, private svc: PatientService,
    private authSvc: AuthService) { }


  ngOnInit(): void {

    //fetch id of logged patient
    this.patientId = this.authSvc.PatientId;
    console.log("patient id : " + this.patientId);
    this.svc.getPastVisitDetails(this.patientId).subscribe(response => {
      console.log("past visit response " + response);
      this.dtOptions.data = response;
      this.dtTrigger.next();
    });




    this.dtOptions = {
      autoWidth: true,
      scrollX: true,

      dom: 'Bfrtip',

      // Configure the buttons
      buttons: [

        'colvis',
        'excel',
        //  'copy',
        //  'print',
        //'columnsToggle',

      ],
      columns: [{
        title: 'Visit No',
        data: 'visitId',
        width: "50px"
      }, {
        title: 'Date Of Visit',
        data: 'dateCreated'
      }, {
        title: 'Physician Name',
        data: 'physicianName'
      }, {
        title: 'Nurse Name',
        data: 'nurseName'
      }, {
        title: 'Vital',
        render: function (data, type, row) {
          return "height(feet) => " + row.height + "<br/>" +
            "weight(kg) => " + row.weight + "<br/>" +
            "BloodPressure(mmHg) => " + row.bloodPressure + "<br/>" +
            "RespirationRate(bpm) => " + row.respirationRate + "<br/>" +
            "Temperature(C) => " + row.bodyTemperature + "<br/>";
        }
      },
      {
        title: 'Diagnosis',
        width: "150px",
        render: function (data, type, row) {
          let diagnosis = row.diagnosisdto;

          if (diagnosis != null) {
            let diagnosisString = "<ul>";
            for (let d of diagnosis) {
              diagnosisString = diagnosisString + "<li>" + d.diagnosisDescription + "</li>"
            }

            return diagnosisString + "</ul>";
          }
          return "";
        }
      }, {
        title: 'Medication',
        render: function (data, type, row) {
          let medication = row.medicationdto;
          if (medication != null) {
            let medicationString = "<ul>";
            for (let m of medication) {
              medicationString = medicationString + "<li>" + m.medicationName + " -- "
                + m.medicationStrength + " -- " + m.dosage + "</li>";
            }
            return medicationString + "</ul>";
          }
          return "";
        }
      }, {
        title: 'Procedure',
        width: "250px",
        render: function (data, type, row) {
          let procedure = row.proceduredto;
          if (procedure != null) {
            let procedureString = "<ul>";
            for (let p of procedure) {
              procedureString = procedureString + "<li>" + p.procedureDescription + " -- "
                + p.procedureApproach + "</li>";
            }
            return procedureString + "</ul>";
          }
          return "";
        }
      }
      ],
      responsive: true
    };
  }

  ngAfterViewInit(): void {
    this.renderer.listen('document', 'click', (event) => {
      if (event.target.hasAttribute("view-person-id")) {
        console.log("button click test")
        this.router.navigate(["/person/" + event.target.getAttribute("view-person-id")]);
      }
    });
  }

}
