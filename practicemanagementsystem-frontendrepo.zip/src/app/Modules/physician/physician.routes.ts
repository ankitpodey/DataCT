import { RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/Guard/auth.guard';
import { ChangePasswordComponent } from '../user/change-password/change-password.component';
import { ComposeMessagesComponent } from '../user/compose-messages/compose-messages.component';
import { HospitaluserprofileComponent } from '../user/hospitaluserprofile/hospitaluserprofile.component';
import { PhysicianinboxComponent } from './physicianinbox/physicianinbox.component';

const routes = [
    {
        path: '', 
        children: [
            { 
                path :'', 
                component : PhysicianinboxComponent,
                canActivate: [AuthGuard]
                },
                { 
                    path :'changepassword', 
                    component : ChangePasswordComponent,
                    canActivate: [AuthGuard]
                },
                { 
                    path :'myprofile', 
                    component : HospitaluserprofileComponent,
                    canActivate: [AuthGuard]
                },
                { 
                    path :'inbox', 
                    component : PhysicianinboxComponent,
                    canActivate: [AuthGuard]
                },
                { 
                    path :'compose-messages', 
                    component : ComposeMessagesComponent,
                    canActivate: [AuthGuard]
                }
            ]
        }
];

export default RouterModule.forChild(routes);