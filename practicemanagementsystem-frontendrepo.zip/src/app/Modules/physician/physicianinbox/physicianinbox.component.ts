import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, QueryList, Renderer2, ViewChild, ViewChildren } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { Appointment } from 'src/app/Models/Appointment';
import { SchedulingService } from 'src/app/Services/scheduling.service';
import { AuthService } from 'src/app/Services/auth.service';
import { ComposeMessage } from 'src/app/Models/composeMessage';
import { MessagesService } from 'src/app/Services/messages.service';

@Component({
  selector: 'app-physicianinbox',
  templateUrl: './physicianinbox.component.html',
  styleUrls: ['./physicianinbox.component.css']
})

export class PhysicianinboxComponent implements AfterViewInit, OnInit, OnDestroy {

  @ViewChild('appointmentDataTable', { static: false })
  appointmentTable: ElementRef;

  dtAppointmentOptions1: DataTables.Settings = {};
  dtTrigger1: Subject<any> = new Subject<any>();
  appointmentData: Appointment[] = [];

  @ViewChild('messagesDataTable', { static: false })
  messagesTable: ElementRef;

  @ViewChildren(DataTableDirective)
  dtElements: QueryList<DataTableDirective>;

  dtMessagesOptions2: DataTables.Settings = {};
  dtTrigger2: Subject<any> = new Subject<any>();
  messagesData: ComposeMessage[] = [];

  constructor(private authService: AuthService, private messagesService: MessagesService, private schedulingService: SchedulingService, private renderer: Renderer2, private router: Router, private _snackBar: MatSnackBar, private route: ActivatedRoute) { }

  ngOnInit() {

    //set employee Id here
    this.schedulingService.GetIncomingAppointment(this.authService.EmployeeId).subscribe(
      response => {

        console.log("inside ngoninit subscrive with response: " + JSON.stringify(response));

        this.appointmentData = response;
        this.dtAppointmentOptions1.data = this.appointmentData;
        this.dtTrigger1.next();
      })

    this.dtAppointmentOptions1 = {
      autoWidth: true,
      scrollX: true,
      columns: [
        {
          title: 'Appointment ID',
          data: 'appointmentId'
        },
        {
          title: 'Patient Name',
          data: 'patientName'
        },
        {
          title: 'Appointment Date',
          data: 'appointmentDate'
        },
        {
          title: 'Appointment Time',
          data: 'appointmentTime'
        },
        {
          title: 'Appointment Title',
          data: 'appointmentTitle'
        },
        {
          title: 'Appointment Description',
          data: 'appointmentDescription'
        },
        {
          title: 'Approve Appointment',
          render: function (data, type, row) {
            let appointmentId = row.appointmentId;
            return '<div><button id = "approve-btn" class="waves-effect btn btn-secondary btn-sm" appointment-id="' + appointmentId + '">Approve</button></div>';
          }
        },
        {
          title: 'Reject Appointment',
          render: function (data, type, row) {
            let appointmentId = row.appointmentId;
            return '<div><button id = "reject-btn" class="waves-effect btn btn-secondary btn-sm" appointment-id="' + appointmentId + '">Reject</button></div>';
          }
        }
      ]
    };

    this.messagesService.getMessagesByReceiverId(this.authService.EmployeeId).subscribe(
      response => {
        console.log("inside ngoninit subscrive with response: " + JSON.stringify(response));

        this.messagesData = response;
        this.dtMessagesOptions2.data = this.messagesData;
        this.dtTrigger2.next();
      })

    this.dtMessagesOptions2 = {
      autoWidth: true,
      scrollX: true,
      columns: [
        {
          title: 'Message Id',
          data: 'messageId'
        },
        {
          title: 'Sender Name',
          data: 'senderEmpName'
        },
        {
          title: 'Message Subject',
          data: 'messageSubject'
        },
        {
          title: 'Message Body',
          data: 'messageBody'
        },
        {
          title: 'Mark as Read ',
          render: function (data, type, row) {
            let messageId = row.messageId;
            return '<div><button id = "read-btn" class="waves-effect btn btn-secondary btn-sm" message-Id="' + messageId + '">Mark as Read</button></div>';
          }
        }
      ]
    };

  }

  ngAfterViewInit(): void {

    this.renderer.listen(this.appointmentTable.nativeElement, 'click', (event) => {

      if (event.target.id == "approve-btn") {
        this.approveAppointment(event.target.getAttribute("appointment-id"));
      }
      if (event.target.id == "reject-btn") {
        this.rejectAppointment(event.target.getAttribute("appointment-id"));
      }
    });

    this.renderer.listen(this.messagesTable.nativeElement, 'click', (event) => {

      if (event.target.id == "read-btn") {
        this.markMessageAsRead(event.target.getAttribute("message-id"));
      }
    });

  }

  approveAppointment(appointmentId: number): void {
    console.log("inside approveAppointemnt method, apptId is :  " + appointmentId)
    this.schedulingService.acceptAppointment(appointmentId).subscribe(
      (response) => {
        console.log("inside subscribe of acceptappointemnt, response from backend for aceptappointment :  " + JSON.stringify(response));
        //if(response.successFlag){
        this.rerender();
        //}
        this.openSnackBar("Approved Appointment.", "close")

      }
    )
  }

  rejectAppointment(appointmentId: number): void {
    console.log("ts -> managepatientuser.component, function-> deactivateUser, patientId -> " + appointmentId)
    this.schedulingService.rejectAppointment(appointmentId).subscribe(
      (response) => {
        console.log("inside subscribe of rejectAppointment, response from backend for aceptappointment :  " + JSON.stringify(response));

        this.rerender();
        this.openSnackBar("Rejected Appointment.", "close")

      }
    )
  }

  markMessageAsRead(messageId: number): void {
    console.log("Message-ID  to be marked as read is " + messageId)
    this.messagesService.markMessageAsRead(messageId).subscribe(
      (response) => {
        console.log("inside subscribe of markMessageAsRead :  " + JSON.stringify(response));
         this.rerender();
        this.openSnackBar("Message Marked as Read.", "Close")
      }
    )
  }

  ngOnDestroy(): void {
    this.dtTrigger1.unsubscribe();
    this.dtTrigger2.unsubscribe();
  }

  rerender(): void {
    this.dtElements.forEach((dtElement: DataTableDirective) => {
      if(dtElement.dtInstance)
        dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
          dtInstance.destroy();          
      });
    });
      //fetch data again and set data again
      this.schedulingService.GetIncomingAppointment(this.authService.EmployeeId).subscribe(
        response => {
          console.log("inside rerender : subscribe : response: " + JSON.stringify(response));
          this.appointmentData = response;
          this.dtAppointmentOptions1.data = this.appointmentData;
          this.dtTrigger1.next();
        });

        this.messagesService.getMessagesByReceiverId(this.authService.EmployeeId).subscribe(
          response => {
            console.log("inside rerender message : subscribe : response: " + JSON.stringify(response));
            this.messagesData = response;
            this.dtMessagesOptions2.data = this.messagesData;
            this.dtTrigger2.next();
          });
  }

  composeMessage(): void {
    console.log("Inside compose-messages method");
    //this.router.navigate(['compose-messages'], { relativeTo: this.route });
    this.router.navigate(['home/physician/compose-messages']);
    console.log("Outside compose-messages method");

  }

  public openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }
}