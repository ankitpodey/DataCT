import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PhysicianinboxComponent } from './physicianinbox.component';

describe('PhysicianinboxComponent', () => {
  let component: PhysicianinboxComponent;
  let fixture: ComponentFixture<PhysicianinboxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PhysicianinboxComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PhysicianinboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
