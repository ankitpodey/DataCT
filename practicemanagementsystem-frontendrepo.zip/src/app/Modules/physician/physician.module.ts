import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import physicianRoutes from './physician.routes';
import { PhysicianinboxComponent } from './physicianinbox/physicianinbox.component';
import { DataTablesModule } from 'angular-datatables';
import { SharedMaterialModule } from '../shared-material/shared-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [PhysicianinboxComponent],
  imports: [
    CommonModule,
    physicianRoutes,
    DataTablesModule,
    SharedMaterialModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [ PhysicianinboxComponent ]
})

export class PhysicianModule { }
