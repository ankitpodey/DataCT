import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Observable } from 'rxjs';
import { Appointment } from 'src/app/Models/Appointment';
import { ResponseMsg } from 'src/app/Models/ResponseMsg';
import { AuthService } from 'src/app/Services/auth.service';
import { MapdropdownService } from 'src/app/Services/mapdropdown.service';
import { SchedulingService } from 'src/app/Services/scheduling.service';

@Component({
  selector: 'app-scheduleappointment',
  templateUrl: './scheduleappointment.component.html',
  styleUrls: ['./scheduleappointment.component.css']
})
export class ScheduleappointmentComponent implements OnInit {

  minDate = new Date();
  allSpecialitys: any = new Map();
  specialityMasterId: number;
  allPhysicians: any = new Map();
  physicianId: number;
  allTimeSlots: string[];
  appointmentTime: string;

  public ob: Observable<any>;
  public error: string = "";
  public appointment: Appointment = new Appointment();
  fg: FormGroup;

  constructor(private authService: AuthService, private schedulingService: SchedulingService, private mapDropDownService: MapdropdownService, private formBuilder: FormBuilder, private _snackBar: MatSnackBar) { }

  FillSpecialityDDL() {

    this.mapDropDownService.getSpeciality().subscribe(
      (data: any) => {

        let stringifiedData: any;
        stringifiedData = JSON.stringify(data);
        console.log("stringified allSpecialitys (data) :  " + stringifiedData);
        var jsonObject = JSON.parse(stringifiedData);
        var dataMap = new Map(Object.entries(jsonObject));
        this.allSpecialitys = dataMap;
      },
      error => console.log(error), () => console.log('Some error occurred.')
    );
  }

  FillPhysicianDDL(): number {

    this.mapDropDownService.getPhysicianBySpeciality(this.fg.value.specialityMasterId).subscribe(
      (data: any) => {
        console.log("DATA :" + data);

        let stringifiedData: any;
        stringifiedData = JSON.stringify(data);
        console.log("stringified allSpecialitys (data) :  " + stringifiedData);
        var jsonObject = JSON.parse(stringifiedData);
        var dataMap = new Map(Object.entries(jsonObject));
        this.allPhysicians = dataMap;
      },
      error => console.log(error), () => console.log('some error occurred.')
    );
    console.log("this.allPhysicians.get()" + this.allPhysicians.value);
    return this.allPhysicians.value;
  }

  FillAppointmentTimeDDL() {
    console.log("this.fg.value.appointmentDate :" + this.fg.value.appointmentDate);
    if (this.fg.value.appointmentDate == "") {
      return;
    }

    this.mapDropDownService.getAppointmentTimeByAppointmentDate(this.fg.value.physicianId, this.fg.value.appointmentDate).subscribe(
      (data: string[]) => {
        console.log("TIMESLOT :" + data);
        this.allTimeSlots = data;
      },
      error => console.log(error), () => console.log('Some error occurred.')
    );

  }

  ngOnInit(): void {
    this.fg = this.formBuilder.group({
      physicianId: ['', [Validators.required]],
      appointmentDate: ['', [Validators.required]],
      appointmentTime: ['', [Validators.required]],
      appointmentTitle: [''],
      appointmentDescription: [''],
      specialityMasterId: ['', [Validators.required]]

    })

    this.FillSpecialityDDL();
  }

  //injectauth service to take patientId and send to backend
  ScheduleAppointment() {
    console.log("Appointment is started to get Booked!!!!!!!!!!!!");
    this.appointment.appointmentDate = this.fg.value.appointmentDate;
    this.appointment.appointmentDescription = this.fg.value.appointmentDescription;
    this.appointment.appointmentTitle = this.fg.value.appointmentTitle;
    this.appointment.physicianId = this.fg.value.physicianId;
    this.appointment.specialityMasterId = this.fg.value.specialityMasterId;
    this.appointment.appointmentTime = this.fg.value.appointmentTime;
    this.appointment.patientId = this.authService.PatientId;

    console.log("calling service...");

    try {
      this.schedulingService.scheduleAppointment(this.appointment).subscribe(
        (response: ResponseMsg) => {
          console.log("Processing Appointment request...");
          if (response.successFlag) {
            this.fg.reset();
          }
          this.openSnackBar(response.msg, "Close");
        },
        (error: any) => this.error = error.error
      );
    } catch (error) {
      console.log("Unable to book appointment : " + error);
      this.openSnackBar("Something went wrong!!! Please try again later.", "Close");
    }

  }

  public openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 10000,
    });
  }
}