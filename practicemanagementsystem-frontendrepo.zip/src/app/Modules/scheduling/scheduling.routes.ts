import { RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/Guard/auth.guard';
import { ScheduleappointmentComponent } from './scheduleappointment/scheduleappointment.component';
import { UpcomingappointmentComponent } from './upcomingappointment/upcomingappointment.component';


const routes = [
    {
    path: '', 
    children: [
            { 
                path : 'scheduleappointment', 
                component : ScheduleappointmentComponent,
                canActivate: [AuthGuard]
            },
            {​​​​​​​​ 
                path :'upcomingappointment', 
                component :UpcomingappointmentComponent,
                canActivate: [AuthGuard]
        }​​​​​​​​
        ]
    }
];

export default RouterModule.forChild(routes);