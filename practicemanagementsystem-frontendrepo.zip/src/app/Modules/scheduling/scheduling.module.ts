import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ScheduleappointmentComponent } from './scheduleappointment/scheduleappointment.component';
import schedulingRoutes from './scheduling.routes';
import { SharedMaterialModule } from '../shared-material/shared-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UpcomingappointmentComponent } from './upcomingappointment/upcomingappointment.component';
import { DemoUtilsComponent } from './demo-utils/demo-utils.component';
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';

@NgModule({
  declarations: [ScheduleappointmentComponent, UpcomingappointmentComponent, DemoUtilsComponent],
  imports: [
    CommonModule,
    schedulingRoutes,
    SharedMaterialModule,
    FormsModule,
    ReactiveFormsModule,
    CalendarModule,
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory,
    }),
  ],
  exports: [ScheduleappointmentComponent,
    UpcomingappointmentComponent,
    DemoUtilsComponent]
})
export class SchedulingModule { }
