import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CalendarEvent, CalendarView } from 'angular-calendar';
import { Appointment } from 'src/app/Models/Appointment';
import { AuthService } from 'src/app/Services/auth.service';
import { SchedulingService } from 'src/app/Services/scheduling.service';
import { colors } from '../color';

@Component({
  selector: 'app-upcomingappointment',
  templateUrl: './upcomingappointment.component.html',
  styleUrls: ['./upcomingappointment.component.css']
})
export class UpcomingappointmentComponent implements OnInit {
  data :any;
  constructor(private authService: AuthService, private SchedulingService :SchedulingService ) { }
  public meetings : Array<Appointment> = [];
  public calendarEvents = [];
  ngOnInit(): void { 
      this.SchedulingService.fetchTwoMonthsUpcomingAppointmnetForPhysician(this.authService.EmployeeId).subscribe(
        ( meetings:Appointment[])  =>
        {
          // iterate meeting
          console.log("meetings" +meetings);
          //In calender format i have to copy
          for(let m of meetings) {
              //calende event obj 
            console.log("m======================"+m.appointmentDate);  
              let event = {} ;
            //event['id'] =m.appointmentId;   
            event['title']=m.appointmentTitle;
            event['color'] = colors.yellow;
            event['start'] = new Date( m.appointmentDate);   
                 event['actions'] =  [
                          {   
                            label: `<h4> `+m.appointmentDescription+`</h4>`,
                            onClick: ({ event }: { event: CalendarEvent }): void => {
                              this.events = this.events.filter((iEvent) => iEvent !== event);
                              console.log('Event deleted', event);
                            },
                          },
                        ]
            this.calendarEvents.push(event);
            console.log("this.calendarEvents"+this.calendarEvents);
          }          
          }
      );
  }

  view: CalendarView = CalendarView.Month;
  viewDate: Date = new Date();
  events=this.calendarEvents;
}