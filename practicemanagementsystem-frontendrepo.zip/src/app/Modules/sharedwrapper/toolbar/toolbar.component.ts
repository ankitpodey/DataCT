import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';

@Component({
  selector: 'app-toolbar',
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.css']
})
export class ToolbarComponent implements OnInit {
  
  @Output()
  public toggle:EventEmitter<void> = new EventEmitter<void>();

  

  constructor(private router: Router, private svc: AuthService) { 
  
  
  }

 

  public Toggle(): void
  {
    this.toggle.emit();
  }

  logOut() {
    this.svc.IsAuthenticated = false;
    this.svc.AuthenticationToken = "";
    this.svc.UserRole = "";
    localStorage.removeItem('userToken');
    this.toggle.emit();
    this.router.navigate(['']);
  }

  ngOnInit(): void {
  }



}