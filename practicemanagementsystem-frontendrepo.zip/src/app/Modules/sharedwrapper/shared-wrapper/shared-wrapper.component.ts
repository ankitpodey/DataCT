import { Component, OnInit } from '@angular/core';
import { BreakpointObserver, BreakpointState } from '@angular/cdk/layout';

import { AuthService } from 'src/app/Services/auth.service';
import { ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

const SMALL_SCREEN_SIZE = 720;

@Component({
  selector: 'app-shared-wrapper',
  templateUrl: './shared-wrapper.component.html',
  styleUrls: ['./shared-wrapper.component.css']
})
export class SharedWrapperComponent implements OnInit {

  public isScreenSmall: boolean;
  public selectedoption: string = "";
  public name :string;

  @ViewChild('x')
  public matselection: any;
  constructor(private breakpointobserver: BreakpointObserver, public svc: AuthService, 
    private router: Router, private route: ActivatedRoute) 
    { 
      
      if(svc.UserRole=="patient") {
        this.name = svc.PatientName;
      } else {
        this.name = svc.EmployeeName;
      }
      
    }

  ngOnInit(): void 
  {
    this.breakpointobserver.observe(
      [`(max-width: ${SMALL_SCREEN_SIZE}px)`]
    )
    .subscribe((state: BreakpointState) => {
      this.isScreenSmall = state.matches;
    });
  }

  DoSomething(eventsource: any): void
  {
    console.log(this.matselection.selectedOptions.selected[0]?.value);
    if(this.matselection.selectedOptions.selected[0]?.value == "inbox")
    {
      this.router.navigate(['inbox'],{ relativeTo: this.route });
    }
    if(this.matselection.selectedOptions.selected[0]?.value == "notification")
    {
      this.router.navigate(['notification']);
    }
  }

  AddHospitalUser(): void {
    console.log("Inside AddHospitalUser method");
    this.router.navigate(['admin/addhospitaluser'],{relativeTo: this.route});
    console.log("inside if of method");
  }

  ChangePassword():void{
    console.log("Inside ChangePassword method");
    this.router.navigate(['changepassword'],{relativeTo: this.route});
    console.log("inside if of method");
  }

  MyProfile(UserRole): void{
    if(UserRole == 'patient'){
    console.log("Inside Patient Profile method");
    this.router.navigate(['patient/myprofile'],{relativeTo: this.route});
    console.log("Outside Patient Profile method");
  } else if (UserRole == 'nurse'){
    console.log("Inside Nurse Profile method");
    this.router.navigate(['nurse/myprofile'],{relativeTo: this.route});
    console.log("Outside Nurse Profile method");
  } else if (UserRole == 'physician'){
    console.log("Inside Physician Profile method");
    this.router.navigate(['physician/myprofile'],{relativeTo: this.route});
    console.log("Outside Physician Profile method");
  } else if (UserRole == 'admin'){
    console.log("Inside Admin Profile method");
    this.router.navigate(['admin/myprofile'],{relativeTo: this.route});
    console.log("Outside Admin Profile method");
  }
}

GoToDashBoard(UserRole): void {
  if (UserRole == 'nurse'){
    console.log("Inside Nurse Dashboard method");
    this.router.navigate(['nurse/inbox'],{relativeTo: this.route});
    console.log("Outside Nurse Dashboard method");
  } else if (UserRole == 'physician'){
    console.log("Inside Physician Dashboard method");
    this.router.navigate(['physician/inbox'],{relativeTo: this.route});
    console.log("Outside Physician Dashboard method");
  } else if (UserRole == 'admin'){
    console.log("Inside Admin Dashboard method");
    this.router.navigate(['admin/'],{relativeTo: this.route});
    console.log("Outside Admin Dashboard method");
  } else if (UserRole == 'patient'){
    console.log("Inside Patient Dashboard method");
    this.router.navigate(['patient/'],{relativeTo: this.route});
    console.log("Outside Patient Dashboard method");
  } 
}

  manageHospitalUser() : void{
    console.log("Indise manage hospital user");
    this.router.navigate(['admin/managehospitaluser'],{relativeTo: this.route});
  }

  managePatientUser() : void{
    console.log("Indise manage patient user");
    this.router.navigate(['admin/managepatientuser'],{relativeTo : this.route});

  }

  ScheduleAppointment(): void{
    console.log("Inside Schedule Appointment method");
    this.router.navigate(['scheduling/scheduleappointment'],{relativeTo: this.route});
    console.log("Outside Schedule Appointment method");
  }

  CapturePatientVisitDetails(): void{
    console.log("Inside CapturePatientVisitDetails method");
    this.router.navigate(['visit/confirmedvisitlist'],{relativeTo: this.route});
    console.log("Outside CapturePatientVisitDetails method");
  }

  PastVisit() :void {
    
    console.log("Inside Past Visit method");
      this.router.navigate(['patient/pastvisits'],{relativeTo: this.route});
      
  }
  
  UpcomingAppointments() :void {
    
    console.log("Inside Upcoming Appointments method");
      this.router.navigate(['scheduling/upcomingappointment'],{relativeTo: this.route});

  }

  }