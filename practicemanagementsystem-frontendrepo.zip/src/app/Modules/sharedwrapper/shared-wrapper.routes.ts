import { RouterModule } from '@angular/router';

const routes = [
    { 
        path: "patient",
    loadChildren: () => import('src/app/Modules/patient/patient.module').then(m => m.PatientModule)
    },
    { 
        path: "admin",
    loadChildren: () => import('src/app/Modules/admin/admin.module').then(m => m.AdminModule)
    }
    ,
    { 
        path: "physician",
    loadChildren: () => import('src/app/Modules/physician/physician.module').then(m => m.PhysicianModule)
    },
     { 
         path: "nurse",
     loadChildren: () => import('src/app/Modules/nurse/nurse.module').then(m => m.NurseModule)
     },
     { 
        path: "scheduling",
    loadChildren: () => import('src/app/Modules/scheduling/scheduling.module').then(m => m.SchedulingModule)
    },
    { 
       path: "visit",
   loadChildren: () => import('src/app/Modules/visit/visit.module').then(m => m.VisitModule)
   }
    ];
export default RouterModule.forChild(routes);

