import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToolbarComponent } from './toolbar/toolbar.component';
import { FooterComponent } from './footer/footer.component';
import { SharedWrapperComponent } from './shared-wrapper/shared-wrapper.component';
import sharedwrapperroutes from './shared-wrapper.routes';
import { SharedMaterialModule } from '../shared-material/shared-material.module';
import { PatientModule } from '../patient/patient.module';
import patientRoutes from '../patient/patient.routes';
import adminRoutes from '../admin/admin.routes';
import { AdminModule } from '../admin/admin.module';
import nurseRoutes from '../nurse/nurse.routes';
import { NurseModule } from '../nurse/nurse.module';
import { SchedulingModule } from '../scheduling/scheduling.module';
import schedulingRoutes from '../scheduling/scheduling.routes';
import { VisitModule } from '../visit/visit.module';
import physicianRoutes from '../physician/physician.routes';
import { PhysicianModule } from '../physician/physician.module';
import visitRoutes from '../visit/visit.routes';

@NgModule({
  declarations: [ToolbarComponent, FooterComponent, SharedWrapperComponent],
  imports: [
    CommonModule,
    SharedMaterialModule,
    sharedwrapperroutes,
    patientRoutes,
    PatientModule,
    adminRoutes,
    AdminModule,
    SchedulingModule,
    schedulingRoutes,
    VisitModule,
    visitRoutes,
    nurseRoutes,
    NurseModule,
    physicianRoutes,
    PhysicianModule
  ],
  exports: [SharedWrapperComponent, ToolbarComponent, FooterComponent]
})
export class SharedwrapperModule { }
