import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { DiagnosisMaster } from 'src/app/Models/DiagnosisMaster';
import { MedicationMaster } from 'src/app/Models/MedicationMaster';
import { PatientDiagnosis } from 'src/app/Models/PatientDiagnosis';
import { PatientMedication } from 'src/app/Models/PatientMedication';
import { PatientProcedure } from 'src/app/Models/PatientProcedure';
import { ProcedureMaster } from 'src/app/Models/ProcedureMaster';
import { Visit } from 'src/app/Models/Visit';
import { AuthService } from 'src/app/Services/auth.service';
import { MasterService } from 'src/app/Services/master.service';
import { VisitService } from 'src/app/Services/visit.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-capturepatientvisitdetails',
  templateUrl: './capturepatientvisitdetails.component.html',
  styleUrls: ['./capturepatientvisitdetails.component.css']
})

export class CapturepatientvisitdetailsComponent implements OnInit {

  closeResult = '';
  @ViewChild('content', { static: false })
  modal: ElementRef;
  medicationDosage: string = "";

  public patientDiagnosisList: PatientDiagnosis[] = [];
  public patientProcedureList: PatientProcedure[] = [];
  public patientMedicationList: PatientMedication[] = [];

  public ob: Observable<any>;
  public error: string = "";

  public visit: Visit = new Visit();

  public patientDiagnosis: PatientDiagnosis = new PatientDiagnosis();
  public patientProcedure: PatientProcedure = new PatientProcedure();
  public patientMedication: PatientMedication = new PatientMedication();
  dtUserOptions1: DataTables.Settings = {};
  dtUserOptions2: DataTables.Settings = {};
  dtUserOptions3: DataTables.Settings = {};
  private sub: any;
  appointmentId: number;
  visitId: number;
  patientId: number;
  nurseId: number;
  physicianId: number;

  @ViewChild('masterDiagonsis', { static: false })
  appointmentTable: ElementRef;

  @ViewChild('masterProcedure', { static: false })
  appointmentTable1: ElementRef;

  @ViewChild('masterMedication', { static: false })
  appointmentTable2: ElementRef;

  diagnosisData: DiagnosisMaster[] = [];
  procedureData: ProcedureMaster[] = [];
  medicationData: MedicationMaster[] = [];

  dtTrigger1: Subject<any> = new Subject<any>();
  dtTrigger2: Subject<any> = new Subject<any>();
  dtTrigger3: Subject<any> = new Subject<any>();

  fgDosage: FormGroup = new FormGroup({
  });


  fgVitals: FormGroup = new FormGroup(
    {
      height: new FormControl(),
      weight: new FormControl(),
      bloodPressure: new FormControl(),
      bodyTemperature: new FormControl(),
      respirationRate: new FormControl()
    }
  );

  fgDiagnosis: FormGroup = new FormGroup(
    {
      diagnosisMasterId: new FormControl(),
      diagnosisDescription: new FormControl(),
    }
  );

  fgProcedure: FormGroup = new FormGroup(
    {
      procedureMasterId: new FormControl(),
      procedureDescription: new FormControl()
    }
  );

  fgMedication: FormGroup = new FormGroup(
    {
      medicationMasterId: new FormControl(),
      dosage: new FormControl(),
      medicationDescription: new FormControl(),
      fcDosage: new FormControl()
    }
  );

  constructor(public svc: AuthService, private visitService: VisitService, private masterService: MasterService, private _snackBar: MatSnackBar,
    private formBuilder: FormBuilder, private route: ActivatedRoute, private router: Router, public dialog: MatDialog,
    private modalService: NgbModal) {
  }

  public CaptureVisitDetails(): void {
    console.log("Capturing Vitals");

    this.visit.patientId = this.patientId;
    this.visit.visitId = this.visitId;
    this.visit.appointmentId = this.appointmentId;

    //Visit Model Fields
    this.visit.height = this.fgVitals.value.height;
    this.visit.weight = this.fgVitals.value.weight;
    this.visit.bloodPressure = this.fgVitals.value.bloodPressure;
    this.visit.bodyTemperature = this.fgVitals.value.bodyTemperature;
    this.visit.respirationRate = this.fgVitals.value.respirationRate;

    this.visit.diagnosisdto = this.patientDiagnosisList;
    this.visit.medicationdto = this.patientMedicationList;
    this.visit.proceduredto = this.patientProcedureList;

    //check role and set nurseid and patient id
    if (this.svc.UserRole == "physician") {
      this.visit.physicianId = this.svc.EmployeeId;
      this.visit.nurseId = this.nurseId;
    } else {
      console.log("Nurse Id : "+this.svc.EmployeeId);
      this.visit.nurseId = this.svc.EmployeeId;
      this.visit.physicianId = this.physicianId;

    }

    //service call yo save visit object details
    this.visitService.addVisit(this.visit).subscribe(
      (response) => {
        console.log("repsonse " + JSON.stringify(response));
        this.openSnackBar(response.msg, "Close");
      },
      (error: any) => {
        console.log("coming to error")
        this.openSnackBar("Something went wrong please try again", "Close");
      }
    );
  }

  ngOnInit(): void {

    this.masterService.GetDiagnosisMasterData().subscribe(
      response => {
        this.diagnosisData = response;
        this.dtUserOptions1.data = this.diagnosisData;
        this.dtTrigger1.next();
      });

    this.dtUserOptions1 = {

      autoWidth: true,
      scrollX: true,

      columns: [{
        title: 'Diagnosis Master Id',
        data: 'diagnosisMasterId'
      },
      {
        title: "Diagnosis Code",
        data: 'diagnosisCode'
      },
      {
        title: 'Diagnosis Description',
        data: 'diagnosisDescription'

      },
      {
        title: 'Diagnosis Type',
        data: 'diagnosisType'

      }, {
        title: 'Diagnosis Depricated Flag',
        data: 'diagnosisDepricatedFlag'
      }],
      rowCallback: (row: Node, data: any[] | Object, index: number) => {
        const self = this;
        $('td', row).off('click');
        $('td', row).on('click', () => {
          self.pushDiagnosisToList(data);
          console.log("hello " + JSON.stringify(data));
        });
        return row;
      }
    };

    this.masterService.GetProcedureMasterData().subscribe(
      response => {

        this.procedureData = response;
        //console.log("this.procedureData " + JSON.stringify(this.procedureData));

        this.dtUserOptions2.data = this.procedureData;

        this.dtTrigger2.next();
      });

    this.dtUserOptions2 = {

      autoWidth: true,
      scrollX: true,

      columns: [{
        title: 'Procedure Master Id',
        data: 'procedureMasterId'
      },
      {
        title: "Procedure Code",
        data: 'procedureCode'

      },
      {
        title: 'Procedure Description',
        data: 'procedureDescription'

      },
      {
        title: 'Procedure Approach',
        data: 'procedureApproach'

      }, {
        title: 'Procedure Depricated Flag',
        data: 'procedureDepricatedFlag'
      }],
      rowCallback: (row: Node, data: any[] | Object, index: number) => {
        const self = this;
        $('td', row).off('click');
        $('td', row).on('click', () => {
          self.pushProcedureToList(data);
        });
        return row;
      }
    };
    //medicationData
    this.masterService.GetMedicationMasterData().subscribe(
      response => {

        // console.log("inside ngoninit subscrive with response in get procedure: " + JSON.stringify(response));

        this.medicationData = response;
        //console.log("this.medicationData " + JSON.stringify(this.medicationData));

        this.dtUserOptions3.data = this.medicationData;

        this.dtTrigger3.next();
      });

    this.dtUserOptions3 = {

      autoWidth: true,
      scrollX: true,

      columns: [{
        title: 'Medication Master Id',
        data: 'medicationMasterId'
      },
      {
        title: "Medication Name",
        data: 'medicationName'

      },
      {
        title: 'Medication GenericName',
        data: 'medicationGenericName'

      }, {
        title: 'Medication Form',
        data: 'medicationForm'
      },
      {
        title: 'Medication Strength',
        data: 'medicationStrength'
      }],
      rowCallback: (row: Node, data: any[] | Object, index: number) => {
        const self = this;
        $('td', row).off('click');
        $('td', row).on('click', () => {
          //self.pushMedicationToList(data);
          self.open(this.modal, data);
        });
        return row;
      }
    };

    this.sub = this.route.params.subscribe(params => {

      this.appointmentId = +params['appointmentId']; // (+) converts string 'id' to a number
      console.log(" capture apteintvisit appointmentId" + this.appointmentId);

      //In a real app: dispatch action to load the details here.

    });

    this.fgVitals = this.formBuilder.group({
      patientId: [this.visit.patientId, [Validators.required]],
      height: [this.visit.height, [Validators.required]],
      weight: [this.visit.weight, [Validators.required, Validators.pattern('^[0-9]+$')]],
      bloodPressure: [this.visit.bloodPressure, [Validators.required]],
      bodyTemperature: [this.visit.bodyTemperature, [Validators.required, Validators.pattern('^[0-9]+$')]],
      respirationRate: [this.visit.respirationRate, [Validators.required, Validators.pattern('^[0-9]+$')]]
    })
    this.fgDiagnosis = this.formBuilder.group({
      diagnosisMasterId: ['', [Validators.required]],
      diagnosisDescription: ['', [Validators.required]]
    })
    this.fgProcedure = this.formBuilder.group({
      procedureMasterId: ['', [Validators.required]],
      procedureDescription: ['', [Validators.required]]
    })
    this.fgMedication = this.formBuilder.group({
      medicationMasterId: ['', [Validators.required]],
      dosage: ['', [Validators.required]],
      medicationDescription: ['', [Validators.required]]
    })
    
    //code for getting visit details for appointrmnt ID
    this.visitService.GetPatientVisitDetails(this.appointmentId).subscribe(
      response => {

        if (response == null) {
          //calling to fetch appointment details, to get patient id etc
          this.visitService.fetchAppointment(this.appointmentId).subscribe(
            (response) => {
              this.patientId = response.patientId;
              console.log("patient id set : " + this.patientId)
            }
          );
        } else {
          this.visitId = response.visitId;
          this.patientId = response.patientId;

          this.nurseId = response.nurseId == null ? "" : response.nurseId;
          this.physicianId = response.physicianId == null ? "" : response.physicianId;

          this.fgVitals.controls['height'].setValue(JSON.stringify(response.height));
          this.fgVitals.controls['weight'].setValue(JSON.stringify(response.weight));
          this.fgVitals.controls['bloodPressure'].setValue(JSON.stringify(response.bloodPressure));
          this.fgVitals.controls['bodyTemperature'].setValue(JSON.stringify(response.bodyTemperature));
          this.fgVitals.controls['respirationRate'].setValue(JSON.stringify(response.respirationRate));

          //for populating table data
          this.patientDiagnosisList = response.patientDiagnosis;
          this.patientMedicationList = response.patientMedication;
          this.patientProcedureList = response.patientProcedure;
        }
      },
      (error: any) => {
        console.log("coming to error" + JSON.stringify(error));
      }
    );
    // this.fgVitals.value.height = JSON.stringify(response.height);
  }

  //function to push diagnosis to list
  pushDiagnosisToList(data: any): void {
    console.log("in pushDiagnosisToList() " + JSON.stringify(data));
    this.patientDiagnosis = new PatientDiagnosis();
    this.patientDiagnosis.diagnosisCode = data.diagnosisCode;
    this.patientDiagnosis.diagnosisDescription = data.diagnosisDescription;
    this.patientDiagnosis.diagnosisMasterId = data.diagnosisMasterId;

    this.patientDiagnosisList.push(this.patientDiagnosis);
  }

  deleteDiagnosis(pd: any): void {
    console.log("delete diagnosis " + pd);
    this.patientDiagnosisList = this.patientDiagnosisList.filter(x => x.diagnosisMasterId != pd.diagnosisMasterId)
  }

  pushProcedureToList(data: any): void {
    console.log("in pushProcedureToList() " + JSON.stringify(data));
    this.patientProcedure = new PatientProcedure();
    this.patientProcedure.procedureMasterId = data.procedureMasterId;
    this.patientProcedure.procedureApproach = data.procedureApproach;
    this.patientProcedure.procedureDescription = data.procedureDescription;

    this.patientProcedureList.push(this.patientProcedure);
  }

  deleteProcedure(pp: any): void {
    this.patientProcedureList = this.patientProcedureList.filter(x => x.procedureMasterId != pp.procedureMasterId)
  }

  pushMedicationToList(data: any, dosage: string): void {
    console.log("in pushMedicationToList() " + JSON.stringify(data));
    this.patientMedication = new PatientMedication();
    this.patientMedication.medicationMasterId = data.medicationMasterId;
    this.patientMedication.medicationForm = data.medicationForm;
    this.patientMedication.medicationName = data.medicationName;
    this.patientMedication.medicationStrength = data.medicationStrength;
    this.patientMedication.dosage = dosage;
    this.medicationDosage = "";

    this.patientMedicationList.push(this.patientMedication);
  }

  deleteMedicatoin(pm: any): void {
    this.patientMedicationList = this.patientMedicationList.filter(x => x.medicationMasterId != pm.medicationMasterId)
  }

  public openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }

  open(content, data) {
    //console.log("bchbsjhdcb" + JSON.stringify(content));
    this.modalService.open(content,
      { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
        console.log(result);
        console.log("dosage " + this.medicationDosage);
        this.pushMedicationToList(data, this.medicationDosage);
        this.closeResult = `Closed with: ${result}`;
      }, (reason) => {
        this.closeResult =
          `Dismissed ${this.getDismissReason(reason)}`;
      });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

}

