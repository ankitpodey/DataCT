import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CapturepatientvisitdetailsComponent } from './capturepatientvisitdetails.component';

describe('CapturepatientvisitdetailsComponent', () => {
  let component: CapturepatientvisitdetailsComponent;
  let fixture: ComponentFixture<CapturepatientvisitdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CapturepatientvisitdetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CapturepatientvisitdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
