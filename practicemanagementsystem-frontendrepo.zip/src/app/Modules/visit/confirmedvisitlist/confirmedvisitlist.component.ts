import { Component, OnInit, AfterViewInit, Renderer2 ,OnDestroy, ViewChild, ElementRef} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { SchedulingService } from 'src/app/Services/scheduling.service';
import { Appointment } from 'src/app/Models/Appointment';
import { AuthService } from 'src/app/Services/auth.service';

@Component({
  selector: 'app-confirmedvisitlist',
  templateUrl: './confirmedvisitlist.component.html',
  styleUrls: ['./confirmedvisitlist.component.css']
})
export class ConfirmedvisitlistComponent implements AfterViewInit, OnInit ,OnDestroy {
 
  @ViewChild ('manageConfirmVisitTable ' ,{static:false})
  appointmentTable :ElementRef;
   
  //@ViewChild(DataTableDirective, { static: false })
  //dtElement: DataTableDirective;

  dtUserOptions: DataTables.Settings = {};
  appointmentData: Appointment[] = [];
  dtTrigger: Subject<any> = new Subject<any>();

  constructor(private renderer: Renderer2, private router: Router ,private schedulingService :SchedulingService ,
    private route: ActivatedRoute, private authSvc : AuthService) { }

  ngOnInit(): void {

    if(this.authSvc.UserRole == "Physician" || this.authSvc.UserRole == "physician"){
      this.schedulingService.fetchTodaysUpcomingAppointmentForPhysician(this.authSvc.EmployeeId).subscribe(
        response => {

          console.log("inside observable" + response);
  
          this.appointmentData = response;
          this.dtUserOptions.data=this.appointmentData;
          this.dtTrigger.next();
        }
      )
  } else {
    this.schedulingService.fetchTodaysUpcomingAppointmentForNurse(this.authSvc.EmployeeId).subscribe(
      response => {

        console.log("inside observable" + response);

        this.appointmentData = response;
        this.dtUserOptions.data=this.appointmentData;
        this.dtTrigger.next();
      }
    )
  }

    this.dtUserOptions = {

      autoWidth: true,
      scrollX: true,
     
      columns: [{
        title: 'Appointment ID',
        data: 'appointmentId'
      }, 
      {
        title: "Patient Name",
       data: 'patientName'
        
      },
      {
        title: 'Appointment Description',
        data : 'appointmentDescription'
        
      }, {
        title: 'Appointment Title',
        data: 'appointmentTitle'
      }, {
        title: 'Apointment Date',
        data : 'appointmentDate'
      }, {
        title: 'Appointment Time',
        data : 'appointmentTime'
      },{
        title : 'Action',
        render : function(data, type, row){     
          let appointmentId=row.appointmentId;                                                            //row.appointmentId
          return '<div><button id = "start-btn"  class="waves-effect btn btn-secondary btn-sm" appointment-Id="'+ appointmentId+'">Start</button></div>';
        }
      }]
    };
  }

ngAfterViewInit(): void {
  
  this.renderer.listen(this.appointmentTable.nativeElement, 'click', (event) => {
    console.log("Inside ng start afteview INit");
    
    if (event.target.id == "start-btn") {
      this.startCaptureVisit(event.target.getAttribute("appointment-id"));
    }
   
  });
 
}
  startCaptureVisit(appointmentId: number) {
    console.log("inside start method" +appointmentId);
    
    this.router.navigate(['capturepatientvisitdetails/',appointmentId],{relativeTo: this.route});
  }

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }

}
