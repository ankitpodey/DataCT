import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmedvisitlistComponent } from './confirmedvisitlist.component';

describe('ConfirmedvisitlistComponent', () => {
  let component: ConfirmedvisitlistComponent;
  let fixture: ComponentFixture<ConfirmedvisitlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmedvisitlistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmedvisitlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
