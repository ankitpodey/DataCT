import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import visitRoutes from './visit.routes';
import { SharedMaterialModule } from '../shared-material/shared-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CapturepatientvisitdetailsComponent } from './capturepatientvisitdetails/capturepatientvisitdetails.component';
import { ConfirmedvisitlistComponent } from './confirmedvisitlist/confirmedvisitlist.component';
import { DataTablesModule } from 'angular-datatables';
import {MatDialogModule} from '@angular/material/dialog';


@NgModule({
  declarations: [CapturepatientvisitdetailsComponent, ConfirmedvisitlistComponent],
  imports: [
    CommonModule,
    visitRoutes,
    SharedMaterialModule,
    ReactiveFormsModule,
    FormsModule,
    DataTablesModule,
    MatDialogModule
  ],
  exports: [CapturepatientvisitdetailsComponent, ConfirmedvisitlistComponent]
})

export class VisitModule { }
