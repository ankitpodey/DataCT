import { RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/Guard/auth.guard';
import { CapturepatientvisitdetailsComponent } from './capturepatientvisitdetails/capturepatientvisitdetails.component';
import { ConfirmedvisitlistComponent } from './confirmedvisitlist/confirmedvisitlist.component';

const routes = [
    {
    path: '', 
    children: [
            { 
                path :'confirmedvisitlist/capturepatientvisitdetails/:appointmentId', 
                component : CapturepatientvisitdetailsComponent,
                canActivate: [AuthGuard]
            },
            {
                path : 'confirmedvisitlist',
                component : ConfirmedvisitlistComponent,
                canActivate : [AuthGuard]
            }
        ]
    }
];

export default RouterModule.forChild(routes);