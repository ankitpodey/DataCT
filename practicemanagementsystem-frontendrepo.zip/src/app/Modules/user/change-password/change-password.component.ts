import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MustMatch } from 'src/app/Custom-validation/must-match.validator';
import { ResponseMsg } from 'src/app/Models/ResponseMsg';
import { User } from 'src/app/Models/User';
import { AuthService } from 'src/app/Services/auth.service';
import { PasswordService } from 'src/app/Services/password.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {


  public user: User = new User();


  constructor(private authService: AuthService, private passwordService: PasswordService, private formBuilder: FormBuilder, private _snackBar: MatSnackBar) { }


  ngOnInit(): void {
    this.changePasswordFg = this.formBuilder.group({
      oldPassword: ['', [Validators.required]],

      newPassword: new FormControl(),
      confirmPassword: new FormControl()
      //newPassword: 

    }
      ,
      {
        validator: MustMatch('newPassword', 'confirmPassword')
      }
    );
  }

  changePasswordFg: FormGroup = new FormGroup(
    {
      oldPassword: new FormControl(),
      newPassword: new FormControl(),
      confirmPassword: new FormControl()
    }
  );

  public changePassword(): void {
    //set data received from page, 1
    this.user.userId = this.authService.UserId;
    //should be set from the user data who has curretly logged in
    this.user.emailId = "";

    this.user.oldPassword = this.changePasswordFg.value.oldPassword;
    this.user.newPassword = this.changePasswordFg.value.newPassword;
    //
    this.passwordService.changePassword(this.user).subscribe(
      (response: ResponseMsg) => {
        console.log("pass update status " + response);
        if (response.successFlag) {
          this.changePasswordFg.reset();
        }
        this.openSnackBar(response.msg, "Close");
      },
    );

  }
  public openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }

  get f() {
    return this.changePasswordFg.controls;
  }

}
