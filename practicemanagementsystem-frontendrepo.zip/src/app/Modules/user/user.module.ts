import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RegisterPatientComponent } from './register-patient/register-patient.component';
import { SharedMaterialModule } from '../shared-material/shared-material.module';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { HospitaluserprofileComponent } from './hospitaluserprofile/hospitaluserprofile.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { ComposeMessagesComponent } from './compose-messages/compose-messages.component';

//import { app.routes } from '';

@NgModule({
  declarations: [LoginComponent, RegisterPatientComponent, ChangePasswordComponent, HospitaluserprofileComponent, ForgotpasswordComponent, ComposeMessagesComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    SharedMaterialModule,
    FlexLayoutModule
  ],
  exports : [ LoginComponent, RegisterPatientComponent, ChangePasswordComponent,ComposeMessagesComponent]
})
export class UserModule { }
