import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ComposeMessage } from 'src/app/Models/composeMessage';
import { ResponseMsg } from 'src/app/Models/ResponseMsg';
import { AuthService } from 'src/app/Services/auth.service';
import { MapdropdownService } from 'src/app/Services/mapdropdown.service';
import { MessagesService } from 'src/app/Services/messages.service';

@Component({
  selector: 'app-compose-messages',
  templateUrl: './compose-messages.component.html',
  styleUrls: ['./compose-messages.component.css']
})
export class ComposeMessagesComponent implements OnInit {
  submitted = false;
  compsemessagefg: FormGroup;
  allEmployees :any=new Map();
  employeeId:number;
  public error: string = "";

  constructor(private authService: AuthService, private mapDropDownService: MapdropdownService, private messagesService: MessagesService,private _snackBar: MatSnackBar, private formBuilder: FormBuilder ) { }
  public composeMessage :ComposeMessage =new ComposeMessage();
  //public patient:Patient = new Patient();
  FillEmployeeDDL() {

    this.mapDropDownService.getEmployees().subscribe(
      (data: any) => {
        console.log("DATA :" + data);

        let stringifiedData: any;
        stringifiedData = JSON.stringify(data);
        console.log("stringified allEmployees  (data) :  " + stringifiedData);
        var jsonObject = JSON.parse(stringifiedData);
        console.log("json object " + jsonObject);
        var dataMap = new Map(Object.entries(jsonObject));
        this.allEmployees  = dataMap;
        // var resultKeyMap = new Map();
        // var resultValueMap = new Map();
        // let value: any;
        for (const key of dataMap.keys()) {
          console.log("key : " + key);
          console.log("value : " + dataMap.get(key));
        }

      },
      error => console.log(error), () => console.log('Some error occured.')
    );

  }
  ngOnInit(): void {
    this.compsemessagefg=this.formBuilder.group({
      employeeId:['',[Validators.required]],
      subject:['',[Validators.required]],
      body:['',[Validators.required]]
    })
    this.FillEmployeeDDL();

  }
  Message():void{
    console.log("Compose msg start");

    //this.patient.firstName = this.fg.value.firstName;
    this.composeMessage.receiverEmpId=this.compsemessagefg.value.employeeId;
    this.composeMessage.messageSubject=this.compsemessagefg.value.subject;
    this.composeMessage.messageBody=this.compsemessagefg.value.body;
    this.composeMessage.senderEmpId = this.authService.EmployeeId;

    this.messagesService.saveMessage(this.composeMessage).subscribe(
      (responseMsg: ResponseMsg) => {
            console.log("compose msg send" + JSON.stringify(responseMsg))
            this.openSnackBar(responseMsg.msg, "Close");
            this.compsemessagefg.reset();
          },
          (error: any) => this.error = error.error
        );
        this.submitted = true;
        // stop here if form is invalid
        if (this.compsemessagefg.invalid) {
          return;
        }
  }
  onReset() {
    this.submitted = false;
    this.compsemessagefg.reset();
  }

  public openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }

}
