import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ResponseMsg } from 'src/app/Models/ResponseMsg';
import { User } from 'src/app/Models/User';
import { AuthService } from 'src/app/Services/auth.service';
import { PasswordService } from 'src/app/Services/password.service';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {


  public ob: Observable<any>;
  public result: User[] = new Array<User>();
  public loginStatus: string = "";
  public error: string = "";
  public user: User = new User();
  public isVisible: number = -1;

  fg: FormGroup = new FormGroup(
    {
      emailId: new FormControl(),
      password: new FormControl()
    }
  );

  constructor(private passwordService: PasswordService, private router: Router, private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
  }

  public ForgotPassword(): void {
    this.router.navigate(['/forgotpassword']);
    this.user.emailId = this.fg.value.emailId;
    try {
      this.passwordService.resetPassword(this.user.emailId).subscribe(
        (response: ResponseMsg) => {
          console.log(response);
          if (response.successFlag) {
            this.fg.reset();
            this.router.navigate(['']);
          }
          this.openSnackBar(response.msg, "Close");
        },
        (error: any) => {
          error = error.error;
          this.openSnackBar("Something went wrong. ", "Close");
        }
      );
    } catch (error) {
      console.log("password reset error : " + error);
      this.openSnackBar("Something went wrong!!!", "Close");
    }
  }

  public openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }

  public login(): void {
    console.log("Back to login page from forgot password.");
    this.router.navigate(['']);
  }

}