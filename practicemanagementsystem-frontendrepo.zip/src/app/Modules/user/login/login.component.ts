import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { FormGroup, FormControl } from '@angular/forms';
import { User } from 'src/app/Models/User';
import { AuthService } from 'src/app/Services/auth.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Login } from 'src/app/Models/Login';
import { HttpHeaders, HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

 
  public ob: Observable<any>;
  public result: User[] = new Array<User>();
  public loginStatus : string = "";
  public error: string = "";
  public user:User = new User();
  public loginModel:Login = new Login();
  
   fg : FormGroup=new FormGroup(
  {
  emailId : new FormControl(),
  password : new FormControl()
  }
  );
  
  constructor(private authService : AuthService, private router : Router, private _snackBar: MatSnackBar) { }
  
   ngOnInit(): void {
  }

  // public login(): void
  //   {
  //     this.user.emailId = this.fg.value.emailId;
  //     this.user.password = this.fg.value.password;
  //       this.authService.Login(this.user).subscribe(
  //         (data: any) => 
  //         {
  //           this.authService.AuthenticationToken = data.token;
  //           this.authService.IsAuthenticated = true;
  //           this.authService.UserRole = data.role;
  //         //  this.authService.UserfirstName= data.firstName;
  //         //  this.authService.UserlastName=data.lastName;
  //         //  this.authService.Name=data.firstName + " " + data.lastName;
  //           console.log(data.role);
  //           //console.log(data.firstName);
            
  //           console.log(data.firstName + " " + data.lastName);
            
            
  //           // this.router.navigate(['/authenticated']);
  //           //this.router.navigate(['/home']);
  //           if (data.role == "patient"){
  //             this.router.navigate(['/home/patient']);
  //             console.log("Patient logged in...");
  //           } else if (data.role == "admin") {
  //             console.log("Admin logged in...");
  //             this.router.navigate(['/home/admin']);
  //           } else if (data.role == "physician") {
  //             console.log("Doctor logged in...");
  //             this.router.navigate(['/home/physician']);
  //           } else {
  //             console.log("Nurse logged in...");
  //             this.router.navigate(['/home/nurse']);
  //           }
           
  //         },
  //         (error: any) => this.error = error.error
  //       );
  //   }
  
  
  //main login
  public login(): void
    {
      this.loginModel.emailId = this.fg.value.emailId;
      this.loginModel.password = this.fg.value.password;
        this.authService.getConfigResponse(this.loginModel).subscribe(
          (data: HttpResponse<any>) => 
          {
            console.log(data);
            //console.log(data.headers.keys.length);
            //console.log("new"+data.headers.get(""))
            const keys = data.headers.keys();
           console.log(data.headers.get("token"));
           
             this.authService.AuthenticationToken = data.headers.get("token");
             this.authService.IsAuthenticated = true;
             this.authService.UserRole = data.headers.get("role");
             this.authService.UserId = parseInt(data.headers.get("userId"));
             this.authService.EmailId = data.headers.get("emailId");
             this.authService.EmployeeId = parseInt(data.headers.get("employeeId"));
             this.authService.EmployeeName = data.headers.get("employeeName");
             this.authService.PatientId = parseInt(data.headers.get("patientId"));
             this.authService.PatientName = data.headers.get("patientName");
            
            if (this.authService.UserRole == "patient"){
              this.router.navigate(['/home/patient']);
              console.log("Patient logged in...");
            } else if (this.authService.UserRole == "admin") {
              console.log("Admin logged in...");
              this.router.navigate(['/home/admin']);
            } else if (this.authService.UserRole == "physician") {
              console.log("Doctor logged in...");
              this.router.navigate(['/home/physician']);
            } else {
              console.log("Nurse logged in...");
              this.router.navigate(['/home/nurse']);
            }
           
          },
          (error: any) => {this.error = error.error
          this.openSnackBar("Invalid credentials.", "Close")
          }
        );
    }
  
  public ForgotPassword(): void {
    this.router.navigate(['/forgotpassword']);
  }
  
   public openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }
  
   public RegisterPatient() : void
   {
     this.router.navigate(['/register'])
   }
  
  }