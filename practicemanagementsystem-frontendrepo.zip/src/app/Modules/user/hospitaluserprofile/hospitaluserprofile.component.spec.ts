import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HospitaluserprofileComponent } from './hospitaluserprofile.component';

describe('HospitaluserprofileComponent', () => {
  let component: HospitaluserprofileComponent;
  let fixture: ComponentFixture<HospitaluserprofileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HospitaluserprofileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HospitaluserprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
