import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Employee } from 'src/app/Models/Employee';
import { AuthService } from 'src/app/Services/auth.service';
import { HospitaluserService } from 'src/app/Services/hospitaluser.service';

@Component({
  selector: 'app-hospitaluserprofile',
  templateUrl: './hospitaluserprofile.component.html',
  styleUrls: ['./hospitaluserprofile.component.css']
})
export class HospitaluserprofileComponent implements OnInit {

  userRole: number;

  maxDate = new Date();

  //for sending data initially to page
  public hospitaluserData: Employee = new Employee();
  public existingHospitalUserProfile: Employee = new Employee();
  public updatedHospitalUserData: Employee = new Employee();

  public error: string = "";

  public roleName: any = "";
  public returnedRoleId: number;
  public allRoles: any = new Map();

  public specialityName: any = "";
  public returnedSpecialityMasterId: number;
  public allSpecialities: any = new Map();

  constructor(private authService: AuthService, private formBuilder: FormBuilder, private hospitaluserService: HospitaluserService, private _snackBar: MatSnackBar) { 

  }

  //formgroups
  hospitaluserFg: FormGroup = new FormGroup({
    title: new FormControl(this.hospitaluserData.title),
    firstName: new FormControl(this.hospitaluserData.firstName),
    lastName: new FormControl(this.hospitaluserData.lastName),
    emailId: new FormControl(this.hospitaluserData.emailId),
    dateOfBirth: new FormControl(this.hospitaluserData.dateOfBirth),
    contactNumber: new FormControl(this.hospitaluserData.contactNumber),

    role: new FormControl(this.hospitaluserData.role),
    speciality: new FormControl(this.hospitaluserData.speciality),

    addressLineOne: new FormControl(this.hospitaluserData.addressLineOne),
    addressLineTwo: new FormControl(this.hospitaluserData.addressLineTwo),
    addressStreet: new FormControl(this.hospitaluserData.addressStreet),
    addressLandmark: new FormControl(this.hospitaluserData.addressLandmark),
    addressCity: new FormControl(this.hospitaluserData.addressCity),
    addressState: new FormControl(this.hospitaluserData.addressState),
    addressCountry: new FormControl(this.hospitaluserData.addressCountry),
    addressZipCode: new FormControl(this.hospitaluserData.lastName)

  })

  ngOnInit(): void {

    this.userRole = this.authService.UserRole == 'admin'?1:0;
    
    this.hospitaluserFg = this.formBuilder.group({

      title: [this.hospitaluserData.title, [Validators.required]],
      firstName: [this.hospitaluserData.firstName, [Validators.required, Validators.minLength(3), Validators.maxLength(20), Validators.pattern('^[a-zA-Z]+$')]],
      lastName: [this.hospitaluserData.lastName, [Validators.required, Validators.minLength(3), Validators.maxLength(20), Validators.pattern('^[a-zA-Z]+$')]],
      emailId: [this.hospitaluserData.emailId, [Validators.required, Validators.pattern('[A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+\\.[a-z]{2,3}')]],
      dateOfBirth: [this.hospitaluserData.dateOfBirth, [Validators.required, validateDateOfBirth]],
      contactNumber: [this.hospitaluserData.contactNumber, [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],

      role: [this.hospitaluserData.role],
      speciality: [this.hospitaluserData.speciality],

      addressLineOne: [this.hospitaluserData.addressLineOne],
      addressLineTwo: [this.hospitaluserData.addressLineTwo],
      addressStreet: [this.hospitaluserData.addressStreet],
      addressLandmark: [this.hospitaluserData.addressLandmark],
      addressCity: [this.hospitaluserData.addressCity],
      addressState: [this.hospitaluserData.addressState],
      addressCountry: [this.hospitaluserData.addressCountry],
      addressZipCode: [this.hospitaluserData.addressZipCode, [Validators.minLength(6), Validators.maxLength(6), Validators.pattern('^[0-9]+$')]]
    })

    //get existing profile details --** pass emploeeId instead of hardcoded value
    this.getHospitalUserProfile(this.authService.EmployeeId);

  }

  getHospitalUserProfile(employeeId: number) {
    this.hospitaluserService.getHospitalUserProfile(employeeId).subscribe(
      (existingHospitalUserProfile: Employee) => {
        console.log("Employee profile details are " + JSON.stringify(existingHospitalUserProfile));
        this.populateFormGroupValues(existingHospitalUserProfile);
      },
      (error: any) => this.error = error.error
    );
  }

  populateFormGroupValues(existingHospitalUserProfile) {

    console.log("populating form group values ...");

    this.hospitaluserFg.controls['title'].setValue(existingHospitalUserProfile.title);
    this.hospitaluserFg.controls['firstName'].setValue(existingHospitalUserProfile.firstName);
    this.hospitaluserFg.controls['lastName'].setValue(existingHospitalUserProfile.lastName);
    this.hospitaluserFg.controls['emailId'].setValue(existingHospitalUserProfile.emailId);
    this.hospitaluserFg.controls['contactNumber'].setValue(existingHospitalUserProfile.contactNumber);
    this.hospitaluserFg.controls['dateOfBirth'].setValue(existingHospitalUserProfile.dateOfBirth);

    console.log("setting address line fields..  ");
    this.hospitaluserFg.controls['addressLineOne'].setValue(existingHospitalUserProfile.addressLineOne);
    this.hospitaluserFg.controls['addressLineTwo'].setValue(existingHospitalUserProfile.addressLineTwo);
    this.hospitaluserFg.controls['addressStreet'].setValue(existingHospitalUserProfile.addressStreet);
    this.hospitaluserFg.controls['addressLandmark'].setValue(existingHospitalUserProfile.addressLandmark);
    this.hospitaluserFg.controls['addressCity'].setValue(existingHospitalUserProfile.addressCity);
    this.hospitaluserFg.controls['addressState'].setValue(existingHospitalUserProfile.addressState);
    this.hospitaluserFg.controls['addressCountry'].setValue(existingHospitalUserProfile.addressCountry);
    this.hospitaluserFg.controls['addressZipCode'].setValue(existingHospitalUserProfile.addressZipCode);

    this.returnedSpecialityMasterId = existingHospitalUserProfile.specialityMasterId;
    console.log("this.returnedSpecialityMasterId " + this.returnedSpecialityMasterId);
    this.hospitaluserFg.controls['speciality'].setValue(this.getHospitalUserSpeciality(this.returnedSpecialityMasterId));

    this.returnedRoleId = existingHospitalUserProfile.roleId;
    this.hospitaluserFg.controls['role'].setValue(this.getHospitalUserRole(this.returnedRoleId));
  }

  updateHospitalUserProfile() {

    console.log("updating hospital user profile...");

    //this.updatedHospitalUserData.employeeId = 2;
    this.updatedHospitalUserData.employeeId = this.authService.EmployeeId;
    this.updatedHospitalUserData.title = this.hospitaluserFg.value.title;
    this.updatedHospitalUserData.firstName = this.hospitaluserFg.value.firstName;
    this.updatedHospitalUserData.lastName = this.hospitaluserFg.value.lastName;
    this.updatedHospitalUserData.emailId = this.hospitaluserFg.value.emailId;
    this.updatedHospitalUserData.contactNumber = this.hospitaluserFg.value.contactNumber;
    this.updatedHospitalUserData.dateOfBirth = this.hospitaluserFg.value.dateOfBirth;

    this.updatedHospitalUserData.addressLineOne = this.hospitaluserFg.value.addressLineOne;
    this.updatedHospitalUserData.addressLineTwo = this.hospitaluserFg.value.addressLineTwo;
    this.updatedHospitalUserData.addressStreet = this.hospitaluserFg.value.addressStreet;
    this.updatedHospitalUserData.addressLandmark = this.hospitaluserFg.value.addressLandmark;
    this.updatedHospitalUserData.addressCity = this.hospitaluserFg.value.addressCity;
    this.updatedHospitalUserData.addressState = this.hospitaluserFg.value.addressState;
    this.updatedHospitalUserData.addressCountry = this.hospitaluserFg.value.addressCountry;
    this.updatedHospitalUserData.addressZipCode = this.hospitaluserFg.value.addressZipCode;

    this.hospitaluserService.updateHospitalUserProfile(this.updatedHospitalUserData).subscribe(
      (updatedHospitalUserProfile: Employee) => {
        console.log("Updated Employee profile details are " + JSON.stringify(updatedHospitalUserProfile));
        this.populateFormGroupValues(updatedHospitalUserProfile);
        this.openSnackBar("Profile Updated Successfully. ", "Close");
      },
      (error: any) => {
        this.error = error.error;
        this.openSnackBar("Something went wrong. Please try again later. ", "Close")
      }
    );
  }

  getHospitalUserRole(roleId: number): string {

    console.log("inside getHospitalUserRole method...roleMasterId" + roleId);

    this.hospitaluserService.getHospitalUserRoleName().subscribe(
      (returnedRoleNameMap: any) => {

        let stringifiedData: any;
        stringifiedData = JSON.stringify(returnedRoleNameMap);
        console.log("stringified allSpecialitys (data) :  " + stringifiedData);
        var jsonObject = JSON.parse(stringifiedData);
        var dataMap = new Map(Object.entries(jsonObject));
        this.allRoles = dataMap;
        this.roleName = this.allRoles.get(JSON.stringify(roleId));
        console.log("inside rough... roleName " + this.roleName);
        this.hospitaluserFg.controls['role'].setValue(this.roleName);
      },
      (error: any) => {
        this.error = error.error;
        console.log("error" + JSON.stringify(error));
      }
    );
    return this.roleName;
  }

  getHospitalUserSpeciality(specialityMasterId: number): any {

    console.log("inside getHospitalUserSpeciality method...specialityMasterId" + specialityMasterId);

    this.hospitaluserService.getHospitalUserSpeciality().subscribe(
      (returnedSpecialityNameMap: any) => {

        let stringifiedData: any;
        stringifiedData = JSON.stringify(returnedSpecialityNameMap);
        console.log("stringified allSpecialitys (data) :  " + stringifiedData);
        var jsonObject = JSON.parse(stringifiedData);
        var dataMap = new Map(Object.entries(jsonObject));
        this.allSpecialities = dataMap;
        this.specialityName = this.allSpecialities.get(JSON.stringify(specialityMasterId));
        console.log("inside rough... specialityName " + this.specialityName);
        this.hospitaluserFg.controls['speciality'].setValue(this.specialityName);
      },
      (error: any) => {
        this.error = error.error;
        console.log("error" + JSON.stringify(error));
      }
    );
    return this.specialityName;
  }

  public openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }

}

function validateDateOfBirth(control: AbstractControl): { [key: string]: any } | null {
  const dob: Date = control.value;

  let today = new Date();
  if (dob > today) {
    return { "dobValidationError": true };
  } else {
    return null;
  }
}
