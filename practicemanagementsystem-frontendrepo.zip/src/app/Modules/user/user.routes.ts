// import { RouterModule } from '@angular/router';
// import { AuthGuard } from 'src/app/Guard/auth.guard';
// import { PhysicianinboxComponent } from '../physician/physicianinbox/physicianinbox.component';
// import { ComposeMessagesComponent } from './compose-messages/compose-messages.component';

// const routes = [
//     {
//         path: '', 
//         children: [
//                 { 
//                 path :'', 
//                 component : PhysicianinboxComponent,
//                 canActivate: [AuthGuard]
//                 }
                
//             ]
//         }
// ];

// export default RouterModule.forChild(routes);