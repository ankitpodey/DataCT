import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MustMatch } from 'src/app/Custom-validation/must-match.validator';
import { Patient } from 'src/app/Models/Patient';
import { ResponseMsg } from 'src/app/Models/ResponseMsg';
import { RegisterService } from 'src/app/Services/register.service';


@Component({
  selector: 'app-register-patient',
  templateUrl: './register-patient.component.html',
  styleUrls: ['./register-patient.component.css']
})
export class RegisterPatientComponent implements OnInit {
  submitted = false;
  maxDate = new Date();

  constructor(private registerService: RegisterService, private router: Router, private _snackBar: MatSnackBar, private formBuilder: FormBuilder) { }
  public patient: Patient = new Patient();
  public ob: Observable<any>;
  public result: Patient[] = new Array<Patient>();

  public error: string = "";
  fg: FormGroup = new FormGroup(
    {
      title: new FormControl(),
      firstName: new FormControl(),
      lastName: new FormControl(),
      emailId: new FormControl(),
      //  gender: new FormControl(),
      contactNumber: new FormControl(),
      dateOfBirth: new FormControl(),
      password: new FormControl(),
      confirmPassword: new FormControl()
    }
  );
  ngOnInit(): void {
    this.fg = this.formBuilder.group({
      title: ['', [Validators.required]],
      firstName: ['', [Validators.required, Validators.pattern('^[a-zA-Z]+$')]],
      lastName: ['', [Validators.required, Validators.pattern('^[a-zA-Z]+$')]],
      emailId: ['', [Validators.required, Validators.pattern('[A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+\\.[a-z]{2,3}')]],
      contactNumber: ['', [Validators.required, Validators.pattern('^[0-9]+$'), Validators.maxLength(10)]],
      dateOfBirth: ['', [Validators.required, validateDateOfBirth]],
      password: new FormControl(),
      confirmPassword: new FormControl()
    },
      {
        validator: MustMatch('password', 'confirmPassword')
      }
    );

  }
  RegisterPatient(): void {
    console.log("Patient is beginning to register.");

    this.patient.title = this.fg.value.title;
    this.patient.firstName = this.fg.value.firstName;
    this.patient.lastName = this.fg.value.lastName;
    this.patient.emailId = this.fg.value.emailId;
    //  this.patient.gender=this.fg.value.gender;
    this.patient.contactNumber = this.fg.value.contactNumber;
    this.patient.dateOfBirth = this.fg.value.dateOfBirth;
    this.patient.password = this.fg.value.password;
    this.patient.confirmPassword = this.fg.value.confirmPassword;

    this.registerService.registerPatient(this.patient).subscribe(
      (responseMsg: ResponseMsg) => {
        console.log("Patient is Registering" + JSON.stringify(responseMsg));
        if(responseMsg.successFlag){
        this.openSnackBar(responseMsg.msg, "Close");
        this.fg.reset();
        this.router.navigate(['']);
        }
      },
      (error: any) => { 
        error = error.error;
        this.openSnackBar(error.details, "Close");
      }
    );
    this.submitted = true;
    // stop here if form is invalid
    if (this.fg.invalid) {
      return;
    }
    // display form values on success
    //alert('SUCCESS!!');
  }
  onReset() {
    this.submitted = false;
    this.fg.reset();
  }

  public openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }
  
  get f() { return this.fg.controls; }

}
function validateDateOfBirth(control: AbstractControl): { [key: string]: any } | null {
  const dob: Date = control.value;

  let today = new Date();
  if (dob > today) {

    return { "dobValidationError": true };
  } else {

    return null;
  }
}
