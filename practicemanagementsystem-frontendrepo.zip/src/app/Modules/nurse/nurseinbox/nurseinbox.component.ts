import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, QueryList, Renderer2, ViewChild, ViewChildren } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { Appointment } from 'src/app/Models/Appointment';
import { SchedulingService } from 'src/app/Services/scheduling.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';
import { ComposeMessage } from 'src/app/Models/composeMessage';
import { MessagesService } from 'src/app/Services/messages.service';

@Component({
  selector: 'app-nurseinbox',
  templateUrl: './nurseinbox.component.html',
  styleUrls: ['./nurseinbox.component.css']
})

export class NurseinboxComponent implements OnInit, AfterViewInit, OnDestroy {
  public name: string;

  @ViewChild('appointmentDataTable', { static: false })
  appointmentTable: ElementRef;

  dtAppointmentOptions1: DataTables.Settings = {};
  dtTrigger1: Subject<any> = new Subject<any>();
  appointmentData: Appointment[] = [];

  @ViewChild('messagesDataTable', { static: false })
  messagesTable: ElementRef;

  @ViewChildren(DataTableDirective)
  dtElements: QueryList<DataTableDirective>;

  dtMessagesOptions2: DataTables.Settings = {};
  dtTrigger2: Subject<any> = new Subject<any>();
  messagesData: ComposeMessage[] = [];

  constructor(private authService: AuthService, private messagesService: MessagesService, private schedulingService: SchedulingService, private renderer: Renderer2, private router: Router, private _snackBar: MatSnackBar, private route: ActivatedRoute) { }

  ngOnInit() {

    //set employee Id here
    this.schedulingService.GetUpcomingAppointmentForNurse(this.authService.EmployeeId).subscribe(
      response => {

        console.log("inside ngoninit subscrive with response: " + JSON.stringify(response));

        this.appointmentData = response;
        this.dtAppointmentOptions1.data = this.appointmentData;
        this.dtTrigger1.next();
      })

    this.dtAppointmentOptions1 = {
      autoWidth: true,
      scrollX: true,
      columns: [
        {
          title: 'Appointment ID',
          data: 'appointmentId'
        },
        {
          title: 'Patient Name',
          data: 'patientName'
        },
        {
          title: 'Appointment Date',
          data: 'appointmentDate'
        },
        {
          title: 'Appointment Time',
          data: 'appointmentTime'
        },
        {
          title: 'Appointment Title',
          data: 'appointmentTitle'
        },
        {
          title: 'Appointment Description',
          data: 'appointmentDescription'
        }
      ]
    };

    this.messagesService.getMessagesByReceiverId(this.authService.EmployeeId).subscribe(
      response => {
        console.log("inside ngoninit subscrive with response: " + JSON.stringify(response));

        this.messagesData = response;
        this.dtMessagesOptions2.data = this.messagesData;
        this.dtTrigger2.next();
      })

    this.dtMessagesOptions2 = {
      autoWidth: true,
      scrollX: true,
      columns: [
        {
          title: 'Message Id',
          data: 'messageId'
        },
        {
          title: 'Sender Name',
          data: 'senderEmpName'
        },
        {
          title: 'Message Subject',
          data: 'messageSubject'
        },
        {
          title: 'Message Body',
          data: 'messageBody'
        },
        {
          title: 'Mark as Read ',
          render: function (data, type, row) {
            let messageId = row.messageId;
            return '<div><button id = "read-btn" class="waves-effect btn btn-secondary btn-sm" message-Id="' + messageId + '">Mark as Read</button></div>';
          }
        }
      ]
    };

  }

  ngAfterViewInit(): void {

    this.renderer.listen(this.messagesTable.nativeElement, 'click', (event) => {

      if (event.target.id == "read-btn") {
        this.markMessageAsRead(event.target.getAttribute("message-id"));
      }
    });

  }
  
  markMessageAsRead(messageId: number): void {
    console.log("Message-ID  to be marked as read is " + messageId)
    this.messagesService.markMessageAsRead(messageId).subscribe(
      (response) => {
        console.log("inside subscribe of markMessageAsRead :  " + JSON.stringify(response));
        this.rerenderMessage();
        this.openSnackBar("Message Marked as Read.", "Close")

      }
    )
  }

  rerenderMessage(): void {
    this.dtElements.forEach((dtElement: DataTableDirective) => {
      if(dtElement.dtInstance)
        dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
          dtInstance.destroy();          
      });
    });

    this.schedulingService.GetUpcomingAppointmentForNurse(this.authService.EmployeeId).subscribe(
      response => {
        console.log("inside ngoninit subscrive with response: " + JSON.stringify(response));
        this.appointmentData = response;
        this.dtAppointmentOptions1.data = this.appointmentData;
        this.dtTrigger1.next();
      })

      //fetch data again and set data again
      this.messagesService.getMessagesByReceiverId(this.authService.EmployeeId).subscribe(
        response => {
          this.messagesData = response;
          this.dtMessagesOptions2.data = this.messagesData;
          this.dtTrigger2.next();
        })
  }

  ngOnDestroy(): void {
    this.dtTrigger1.unsubscribe();
    this.dtTrigger2.unsubscribe();
  }

  composeMessage(): void {
    console.log("Inside compose-messages method");
    //this.router.navigate(['compose-messages'], { relativeTo: this.route });
    this.router.navigate(['home/nurse/compose-messages']);
    console.log("Outside compose-messages method");
  }

  public openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }
}



