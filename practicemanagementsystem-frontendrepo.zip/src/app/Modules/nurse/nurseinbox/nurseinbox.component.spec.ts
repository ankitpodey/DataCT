import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NurseinboxComponent } from './nurseinbox.component';

describe('NurseinboxComponent', () => {
  let component: NurseinboxComponent;
  let fixture: ComponentFixture<NurseinboxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NurseinboxComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NurseinboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
