import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import nurseRoutes from './nurse.routes';
import { DataTablesModule } from 'angular-datatables';
import { SharedMaterialModule } from '../shared-material/shared-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NurseinboxComponent } from './nurseinbox/nurseinbox.component';

@NgModule({
  declarations: [NurseinboxComponent],
  imports: [
    CommonModule,
    nurseRoutes,
    DataTablesModule,
    SharedMaterialModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [ NurseinboxComponent ]
})
export class NurseModule { }
