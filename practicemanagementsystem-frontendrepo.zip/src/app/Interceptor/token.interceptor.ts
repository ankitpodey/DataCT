import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from '../Services/auth.service';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {

  constructor(private svc :AuthService) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    
    console.log("TokenInterceptor");
    console.log("Request method: " +request.method);
    
    if(request.method == "GET")
    {
      let clonedrequest = request.clone({
        setHeaders: {
          Authorization: `Bearer ${this.svc.AuthenticationToken}`
        }
      });
      return next.handle(clonedrequest);
    }
    
    return next.handle(request);
  }
}
